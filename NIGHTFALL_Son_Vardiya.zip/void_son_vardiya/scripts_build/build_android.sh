#!/usr/bin/env bash
# NIGHTFALL: SON VARDİYA — Godot 4.3 Android APK derleme betiği.
# Kullanım: bash scripts_build/build_android.sh [debug|release]
set -Eeuo pipefail

MODE="${1:-debug}"
if [[ "$MODE" != "debug" && "$MODE" != "release" ]]; then
  echo "Hata: mod 'debug' veya 'release' olmalı." >&2
  exit 2
fi

GODOT="${GODOT:-godot}"
ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$ANDROID_HOME" || ! -d "$ANDROID_HOME" ]]; then
  echo "Hata: ANDROID_HOME veya ANDROID_SDK_ROOT geçerli bir Android SDK klasörünü göstermeli." >&2
  exit 2
fi
if ! command -v "$GODOT" >/dev/null 2>&1 && [[ ! -x "$GODOT" ]]; then
  echo "Hata: Godot çalıştırılabilir dosyası bulunamadı: $GODOT (GODOT değişkenini ayarla)." >&2
  exit 2
fi
if ! command -v java >/dev/null 2>&1 || ! command -v keytool >/dev/null 2>&1; then
  echo "Hata: JDK 17+ gerekli; java ve keytool PATH içinde olmalı." >&2
  exit 2
fi

GODOT_VERSION="$($GODOT --version 2>/dev/null | head -n 1)"
if [[ "$GODOT_VERSION" != 4.3* ]]; then
  echo "Hata: Bu proje Godot 4.3 için yapılandırıldı; bulunan sürüm: ${GODOT_VERSION:-bilinmiyor}." >&2
  exit 2
fi

JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")}"
export JAVA_HOME ANDROID_HOME
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"
mkdir -p build

# Android dışa aktarma için gerekli resmi Godot şablonlarını doğrula.
TEMPLATE_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/godot/export_templates/4.3.stable"
for template in android_debug.apk android_release.apk; do
  if [[ ! -s "$TEMPLATE_DIR/$template" ]]; then
    echo "Hata: Godot export şablonu bulunamadı: $TEMPLATE_DIR/$template" >&2
    echo "Godot 4.3 export templates paketini kurup yeniden dene." >&2
    exit 2
  fi
done

# Debug keystore: yalnızca yerel test APK'sı içindir.
DEBUG_KS="$HOME/.android/debug.keystore"
if [[ ! -f "$DEBUG_KS" ]]; then
  mkdir -p "$HOME/.android"
  keytool -genkeypair -noprompt -keystore "$DEBUG_KS" -storepass android \
    -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
    -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi

# Godot CLI'nin Android SDK/JDK yollarını bulabilmesi için editör ayarları.
SETTINGS_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/godot"
mkdir -p "$SETTINGS_DIR"
cat > "$SETTINGS_DIR/editor_settings-4.3.tres" <<EOS
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
export/android/debug_keystore = "$DEBUG_KS"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOS

# Import hatalarını gizleme: başarısızsa işlem burada durmalı.
"$GODOT" --headless --editor --path "$PROJECT_DIR" --quit --import

if [[ "$MODE" == "release" ]]; then
  : "${RELEASE_KEYSTORE:?Release için RELEASE_KEYSTORE (imzalama anahtarı yolu) gerekli}"
  : "${RELEASE_KEYSTORE_USER:?Release için RELEASE_KEYSTORE_USER gerekli}"
  : "${RELEASE_KEYSTORE_PASSWORD:?Release için RELEASE_KEYSTORE_PASSWORD gerekli}"
  export GODOT_ANDROID_KEYSTORE_RELEASE_PATH="$RELEASE_KEYSTORE"
  export GODOT_ANDROID_KEYSTORE_RELEASE_USER="$RELEASE_KEYSTORE_USER"
  export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD="$RELEASE_KEYSTORE_PASSWORD"
  "$GODOT" --headless --path "$PROJECT_DIR" --export-release "Android Release" build/void_son_vardiya_release.apk
  APK_PATH="build/void_son_vardiya_release.apk"
else
  "$GODOT" --headless --path "$PROJECT_DIR" --export-debug "Android Debug" build/NIGHTFALL_Son_Vardiya.apk
  APK_PATH="build/NIGHTFALL_Son_Vardiya.apk"
fi

if [[ ! -s "$APK_PATH" ]]; then
  echo "Hata: Godot komutu tamamlandı ancak APK dosyası oluşmadı: $APK_PATH" >&2
  exit 1
fi
echo "Başarılı: $PROJECT_DIR/$APK_PATH"
