NIGHTFALL: SON VARDIYA marka gorseli. nightfall_concept_poster.png tanitim konseptidir; otomatik olarak oyun ici doku olarak kullanilmaz. Uygulama simgesi icon.svg dosyasidir.
