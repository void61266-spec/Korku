# NIGHTFALL: SON VARDİYA

Godot 4.3 (GDScript, Mobile Renderer) ile yazılmış mobil 3D korku / hayatta kalma oyunu.
Dünya geometrisi GDScript ile üretilir; zemin, duvar, metal, ahşap ve ambalaj yüzeyleri için projeye dahil edilmiş önceden hazırlanmış doku ve normal haritaları kullanılır.

## Durum

| Sistem | Durum |
|---|---|
| Ana menü (3D arka plan, Tek/Çok oyunculu, Ayarlar, Çıkış) | Hazır |
| 3D market + bodrum + laboratuvar + dış alan | Hazır |
| Oyuncu: yürü / koş / eğil / fener / etkileşim / saklanma | Hazır |
| Dokunmatik kontroller (joystick, bakış, butonlar) | Hazır |
| Envanter, fener pili, görev sistemi (18 adım) | Hazır |
| Yaratık AI (devriye, ses/görüş, kovalama, arama, kaybetme) | Hazır |
| Hikâye (kesinti, kameralar, gizli geçit, final) | Hazır |
| Kayıt sistemi, Ayarlar, prosedürel ses | Hazır |
| Çok oyunculu (ENet host/client + oda kodu) | **Henüz yok** (menüde pasif) |
| İmzalı APK | Aşağıdaki betikle üretilir |

## Çalıştırma (PC, test)
Godot 4.3 ile `project.godot` dosyasını aç. WASD, fare, E (etkileşim), F (fener), C (eğil), Shift (koş), I (envanter).
Dokunmatik arayüzü PC'de görmek için `NIGHTFALL_TOUCH=1` ortam değişkeni.

## Test
`godot --headless --path . res://tests/smoke.tscn` → hikâyenin tamamını otomatik oynatır (yol grafı, görevler, kayıt, yaratık).

## APK
1. Godot 4.3 + export şablonları, JDK 17+, Android SDK (`platforms;android-34`, `build-tools;34.0.0`, `platform-tools`, `cmdline-tools;latest`).
2. `export ANDROID_HOME=...; export GODOT=/yol/godot`
3. `bash scripts_build/build_android.sh debug` → `build/NIGHTFALL_Son_Vardiya.apk`. Betik Godot 4.3, Android export şablonları, JDK ve SDK yollarını önceden doğrular; import hatalarını gizlemez.
4. Release: `RELEASE_KEYSTORE=... RELEASE_KEYSTORE_USER=... RELEASE_KEYSTORE_PASSWORD=... bash scripts_build/build_android.sh release` (dağıtım imzalama anahtarını repoya yükleme).
5. GitHub'a yüklersen `.github/workflows/android.yml` APK'yı otomatik üretir (Actions → Artifacts).

Android API 34 SDK/build-tools ve JDK 17 kullanılır. APK arm64 + armeabi-v7a mimarilerini hedefler. Godot 4.3 şablonunun varsayılan Min/Target SDK değerleri kullanılır. İzinler: VIBRATE, INTERNET, ACCESS_NETWORK_STATE.

## Klasörler
`scripts/autoload` (Settings, GameManager, SaveSystem, AudioManager) · `scripts/player` · `scripts/game` (yaratık, görev, yönetmen) · `scripts/world` (harita, kapı, eşya) · `scripts/inventory` · `scripts/ui` · `tests`

## NIGHTFALL görsel ve performans revizyonu

- Zemin, sıva, beton, asfalt, tavan, ahşap, metal, karton ve ürün ambalajları için önceden hazırlanmış albedo/normal haritaları kullanılır. Bilinen materyaller oyun açılırken GDScript ile piksel piksel üretilmez.
- Market ön cephesine vitrin camları, metal doğramalar, kırmızı marka tabelası ve giriş saçağı eklendi.
- Otopark araçları gövde, cam, tampon, lastik ve far detaylarıyla yeniden kuruldu.
- Raf tahtaları, fiyat şeritleri ve dikey destekler MultiMesh ile gruplanarak raf başına çizim çağrısı azaltıldı.
- Tavan panelleri ve ızgaraları MultiMesh olarak çizilir; ürün renkleri daha ölçülü bir palete alındı.
- Soğutucular boş kutular yerine iç raflara ve içecek modellerine sahip içi boş dolaplar olarak oluşturuldu.
- Oyuncu feneri ve iki ana lamba için gölge desteği etkin; diğer yerel ışıkların gölgeleri kapalı tutularak mobil maliyet sınırlandı.
- Modern Android GPU'ları için Godot Mobile renderer seçildi. Konsept afişi, testler ve derleme betikleri APK dışa aktarımına dahil edilmez.

Bu kaynak revizyonu Godot 4.3 üzerinde derlenerek veya gerçek cihazlarda performans testi yapılarak doğrulanmış değildir. Android Vulkan uyumluluğu ve performansın hedef cihazda ayrıca sınanması gerekir. Çok oyunculu ağ sistemi hâlâ uygulanmış değildir.

## NIGHTFALL visual/performance pass

The project now includes pre-baked 512px albedo/normal maps for floor, concrete, painted wall, refrigerated steel, crates and creature materials. The shelf frame is an imported PBR GLB with perforated backing, folded metal trays, rails, rivets and foot plates; the shopping cart uses round wire rods, tapered basket, lower rack and real wheels. A custom creature core model replaces the smooth capsule-only torso/head silhouette while retaining animated limbs. The menu has a dedicated transparent NIGHTFALL wordmark. The exterior has glazing, frames, entrance sign and multi-part car silhouettes; indoor dressing includes ceiling service lines, CCTV, checkout terminals, wet patches, scuff decals and shelf signage.

Rendering cost is bounded by batching repeated shelf products/ceiling geometry with MultiMesh, turning off shadow casting on small decorative parts, and reserving real-time shadows for the High graphics profile. Low/Medium disable most dynamic shadows to reduce mobile GPU cost. The app defaults to a 45 FPS cap.

This remains an ambitious prototype rather than a finished commercial release. The store architecture, remaining room props and limbs still use procedural geometry; online multiplayer is not implemented. A Godot runtime was unavailable in this editing environment, so the revised source could be statically inspected but not launched, rendered, exported to APK, or benchmarked on an actual phone. Confirm the result in GitHub Actions and on the target device before treating it as a tested build.
