extends Node3D
## Ana menü: karanlık market koridoru arka planı + menü butonları.

var _cam: Camera3D
var _t := 0.0
var _ui_root: Control
var _box: VBoxContainer
var _lights: Array[FlickerLight] = []


func _ready() -> void:
	AudioManager.start_ambient()
	_build_backdrop()
	_build_ui()
	_show_main()


func _build_backdrop() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color.BLACK
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.08, 0.09, 0.12)
	env.ambient_light_energy = 0.36
	env.fog_enabled = true
	env.fog_light_color = Color(0.04, 0.045, 0.05)
	env.fog_density = 0.065
	we.environment = env
	add_child(we)
	var floor_mat := Props.tex_mat("floor_tile", Color(0.62, 0.62, 0.58), 0.05, 2, 4, Color(0.28, 0.28, 0.27), 0.5, 0.55)
	var wall_mat := Props.tex_mat("wall", Color(0.58, 0.6, 0.55), 0.07, 3, 0, Color.BLACK, 0.4)
	Props.box(self, Vector3(0, -0.1, 0), Vector3(9, 0.2, 60), floor_mat, 1, false)
	Props.box(self, Vector3(0, 3.1, 0), Vector3(9, 0.2, 60), wall_mat, 1, false)
	Props.box(self, Vector3(-4.5, 1.5, 0), Vector3(0.2, 3, 60), wall_mat, 1, false)
	Props.box(self, Vector3(4.5, 1.5, 0), Vector3(0.2, 3, 60), wall_mat, 1, false)
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for i in 8:
		var z := 8.0 - i * 4.8
		Props.shelf(self, Vector3(-2.6, 0, z), PI * 0.5, 4.4, rng)
		Props.shelf(self, Vector3(2.6, 0, z), PI * 0.5, 4.4, rng)
	for i in 5:
		var l := FlickerLight.new()
		l.position = Vector3(0, 2.75, 6.0 - i * 9.0)
		l.base_energy = 1.0
		l.omni_range = 11.0
		l.mode = 2 if i == 1 else (1 if i % 2 == 0 else 0)
		add_child(l)
		_lights.append(l)
	_build_menu_stalker()
	_cam = Camera3D.new()
	_cam.position = Vector3(0, 1.55, 10)
	_cam.fov = 70.0
	add_child(_cam)
	_cam.current = true


func _build_menu_stalker() -> void:
	# A distant silhouette at the vanishing point creates a recognizable horror hook.
	# It is decorative only: no physics, no AI and no real-time shadow cost.
	var stalker := Node3D.new()
	stalker.name = "VanishingPointStalker"
	stalker.position = Vector3(0.0, 0.0, -17.5)
	stalker.rotation.y = PI
	add_child(stalker)
	var skin := Props.tex_mat("creature_skin", Color(0.025, 0.022, 0.025), 0.12, 61, 0, Color.BLACK, 0.65, 0.98)
	var rag := Props.tex_mat("creature_cloth", Color(0.015, 0.017, 0.02), 0.08, 71, 0, Color.BLACK, 0.45, 0.99)
	var eyes := Props.color_mat("menu_stalker_eyes", Color(0.66, 0.012, 0.008), 0.28, 2.2)
	var torso := CapsuleMesh.new()
	torso.radius = 0.25
	torso.height = 1.55
	var torso_node := MeshInstance3D.new()
	torso_node.mesh = torso
	torso_node.material_override = rag
	torso_node.position = Vector3(0.0, 1.1, 0.0)
	torso_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	stalker.add_child(torso_node)
	var skull := SphereMesh.new()
	skull.radius = 0.2
	skull.height = 0.44
	var head_node := MeshInstance3D.new()
	head_node.mesh = skull
	head_node.material_override = skin
	head_node.position = Vector3(0.0, 2.0, -0.04)
	head_node.scale = Vector3(0.9, 1.12, 0.88)
	stalker.add_child(head_node)
	for side in [-1.0, 1.0]:
		var arm := CapsuleMesh.new()
		arm.radius = 0.065
		arm.height = 1.18
		var arm_node := MeshInstance3D.new()
		arm_node.mesh = arm
		arm_node.material_override = skin
		arm_node.position = Vector3(side * 0.36, 0.94, 0.0)
		arm_node.rotation.z = side * -0.22
		arm_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		stalker.add_child(arm_node)
		var eye := SphereMesh.new()
		eye.radius = 0.022
		eye.height = 0.03
		var eye_node := MeshInstance3D.new()
		eye_node.mesh = eye
		eye_node.material_override = eyes
		eye_node.position = Vector3(side * 0.075, 2.02, -0.205)
		stalker.add_child(eye_node)
	var foot := BoxMesh.new()
	foot.size = Vector3(0.17, 0.15, 0.32)
	for side in [-1.0, 1.0]:
		var foot_node := MeshInstance3D.new()
		foot_node.mesh = foot
		foot_node.material_override = rag
		foot_node.position = Vector3(side * 0.16, 0.075, -0.055)
		stalker.add_child(foot_node)
	var eye_light := OmniLight3D.new()
	eye_light.light_color = Color(0.7, 0.012, 0.008)
	eye_light.light_energy = 0.12
	eye_light.omni_range = 1.4
	eye_light.position = Vector3(0.0, 2.0, -0.16)
	eye_light.shadow_enabled = false
	stalker.add_child(eye_light)


func _process(delta: float) -> void:
	_t += delta
	var z := 10.0 - fmod(_t * 0.5, 30.0)
	_cam.position = Vector3(sin(_t * 0.2) * 0.4, 1.55 + sin(_t * 0.9) * 0.02, z)
	_cam.rotation = Vector3(sin(_t * 0.31) * 0.02, sin(_t * 0.17) * 0.06, 0.0)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_ui_root = Control.new()
	_ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(_ui_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui_root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui_root.add_child(center)
	_box = VBoxContainer.new()
	_box.custom_minimum_size = Vector2(420, 0)
	_box.add_theme_constant_override("separation", 14)
	center.add_child(_box)


func _clear() -> void:
	for c in _box.get_children():
		c.queue_free()


func _title() -> void:
	var logo := TextureRect.new()
	logo.name = "NightfallLogo"
	logo.texture = load("res://assets/textures/nightfall_logo.png") as Texture2D
	logo.custom_minimum_size = Vector2(420, 112)
	logo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	logo.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_box.add_child(logo)
	var s := UIStyle.label("SON VARDİYA", 30, Color(0.9, 0.9, 0.85))
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(s)
	var tagline := UIStyle.label("BAZI VARDİYALAR ASLA BİTMEMELİYDİ", 13, Color(0.57, 0.59, 0.6))
	tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(tagline)
	var divider := ColorRect.new()
	divider.color = Color(0.46, 0.035, 0.04, 0.88)
	divider.custom_minimum_size = Vector2(180, 2)
	divider.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_box.add_child(divider)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 6)
	_box.add_child(gap)

func _btn(text: String, cb: Callable, accent: bool = true) -> Button:
	var b := Button.new()
	b.text = text
	UIStyle.style_button(b, 30, accent)
	b.pressed.connect(func() -> void:
		AudioManager.play(&"click", -4.0)
		cb.call())
	_box.add_child(b)
	return b


func _show_main() -> void:
	_clear()
	_title()
	_btn("TEK OYUNCULU", _show_single)
	_btn("ÇOK OYUNCULU", _show_multi)
	_btn("AYARLAR", func() -> void: add_child(SettingsMenu.new()), false)
	_btn("ÇIKIŞ", func() -> void: get_tree().quit(), false)


func _show_single() -> void:
	_clear()
	_title()
	var cont := _btn("DEVAM ET", func() -> void: GameManager.start_single(true))
	cont.disabled = not SaveSystem.has_save()
	_btn("YENİ OYUN", func() -> void: GameManager.start_single(false))
	_btn("GERİ", _show_main, false)


func _show_multi() -> void:
	_clear()
	_title()
	var info := UIStyle.label("Çok oyunculu mod internet bağlantısı gerektirir.\nBu sürümde henüz etkin değil; tek oyunculu mod tamamen çevrimdışı çalışır.", 22, Color(0.85, 0.8, 0.6))
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(info)
	var b1 := _btn("ODA OLUŞTUR", func() -> void: pass)
	b1.disabled = true
	var b2 := _btn("ODAYA KATIL", func() -> void: pass)
	b2.disabled = true
	_btn("GERİ", _show_main, false)
