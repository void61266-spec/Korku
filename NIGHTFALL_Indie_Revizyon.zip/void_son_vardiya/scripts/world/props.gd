class_name Props
extends RefCounted
## Prosedürel materyal ve prop üreticileri (harici asset gerektirmez).
## Collision katmanları: 1 = dünya, 2 = kapılar, 4 = etkileşim, 16 = oyuncu

static var _mats: Dictionary = {}
static var _package_cache: Texture2D
static var _shelf_scene: PackedScene

const PRODUCT_COLORS: Array[Color] = [
	Color(0.82, 0.78, 0.68), Color(0.67, 0.73, 0.61), Color(0.73, 0.57, 0.48),
	Color(0.62, 0.68, 0.73), Color(0.85, 0.82, 0.74), Color(0.67, 0.61, 0.48),
	Color(0.76, 0.69, 0.55), Color(0.65, 0.62, 0.67),
]


static func _make_tex(base: Color, amt: float, seed_: int, grid: int, grout: Color) -> ImageTexture:
	var size := 128
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var n := FastNoiseLite.new()
	n.seed = seed_
	n.frequency = 0.045
	var fine := FastNoiseLite.new()
	fine.seed = seed_ * 31 + 7
	fine.frequency = 0.22
	var stains := FastNoiseLite.new()
	stains.seed = seed_ * 13 + 91
	stains.frequency = 0.018
	for y in size:
		for x in size:
			var broad: float = n.get_noise_2d(x, y) * amt
			var detail: float = fine.get_noise_2d(x, y) * amt * 0.28
			var stain: float = maxf(0.0, stains.get_noise_2d(x, y) - 0.28) * amt * 0.8
			var v: float = broad + detail - stain
			var c := Color(clampf(base.r + v, 0.0, 1.0), clampf(base.g + v, 0.0, 1.0), clampf(base.b + v, 0.0, 1.0))
			if grid > 0:
				var cell: int = size / grid
				var edge_x: int = x % cell
				var edge_y: int = y % cell
				if edge_x < 2 or edge_y < 2:
					c = grout
				elif edge_x < 4 or edge_y < 4:
					c = c.darkened(0.10)
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


static func _make_normal(seed_: int) -> ImageTexture:
	var size := 128
	var height_img := Image.create(size, size, false, Image.FORMAT_RF)
	var n := FastNoiseLite.new()
	n.seed = seed_ * 17 + 3
	n.frequency = 0.13
	for y in size:
		for x in size:
			height_img.set_pixel(x, y, Color(0.5 + n.get_noise_2d(x, y) * 0.14, 0, 0))
	var normal_img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in size:
		for x in size:
			var left: float = height_img.get_pixel(maxi(0, x - 1), y).r
			var right: float = height_img.get_pixel(mini(size - 1, x + 1), y).r
			var up: float = height_img.get_pixel(x, maxi(0, y - 1)).r
			var down: float = height_img.get_pixel(x, mini(size - 1, y + 1)).r
			var normal := Vector3((left - right) * 3.0, (up - down) * 3.0, 1.0).normalized()
			normal_img.set_pixel(x, y, Color(normal.x * 0.5 + 0.5, normal.y * 0.5 + 0.5, normal.z * 0.5 + 0.5))
	normal_img.generate_mipmaps()
	return ImageTexture.create_from_image(normal_img)


static func _make_package_texture() -> Texture2D:
	if _package_cache != null:
		return _package_cache
	if ResourceLoader.exists("res://assets/textures/package.png"):
		_package_cache = load("res://assets/textures/package.png") as Texture2D
		return _package_cache
	var size := 128
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in size:
		for x in size:
			var c := Color(0.82, 0.79, 0.68)
			if y < 18 or y > 108:
				c = Color(0.12, 0.13, 0.14)
			elif y > 34 and y < 76:
				c = Color(0.68, 0.12, 0.08) if x < 64 else Color(0.08, 0.20, 0.24)
			elif y > 84 and x % 13 < 4:
				c = Color(0.12, 0.12, 0.11)
			if (x + y) % 17 == 0:
				c = c.darkened(0.06)
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	_package_cache = ImageTexture.create_from_image(img)
	return _package_cache


static func tex_mat(key: String, base: Color, amt: float = 0.06, seed_: int = 1, grid: int = 0,
		grout: Color = Color(0.05, 0.05, 0.05), tile: float = 0.5, rough: float = 0.9) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	var albedo_path := "res://assets/textures/%s.png" % key
	var normal_path := "res://assets/textures/%s_normal.png" % key
	if ResourceLoader.exists(albedo_path):
		m.albedo_texture = load(albedo_path) as Texture2D
	else:
		# Fallback for materials introduced by mods or new rooms.
		m.albedo_texture = _make_tex(base, amt, seed_, grid, grout)
	if ResourceLoader.exists(normal_path):
		m.normal_enabled = true
		m.normal_texture = load(normal_path) as Texture2D
		m.normal_scale = 0.32
	else:
		m.normal_enabled = true
		m.normal_texture = _make_normal(seed_)
		m.normal_scale = 0.22
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(tile, tile, tile)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	m.roughness = rough
	_mats[key] = m
	return m


static func color_mat(key: String, color: Color, rough: float = 0.8, emission: float = 0.0) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	_mats[key] = m
	return m


static func box(parent: Node, center: Vector3, size: Vector3, material: Material,
		layer: int = 1, collide: bool = true) -> Node3D:
	var bm := BoxMesh.new()
	bm.size = size
	if not collide:
		# Decorative geometry does not need an empty StaticBody in the physics server.
		# A plain MeshInstance saves many nodes and disables costly shadow casting on mobile.
		var visual := MeshInstance3D.new()
		visual.position = center
		visual.mesh = bm
		visual.material_override = material
		visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(visual)
		return visual
	var body := StaticBody3D.new()
	body.position = center
	body.collision_layer = layer
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = material
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	parent.add_child(body)
	return body


static func cylinder(parent: Node, center: Vector3, radius: float, height: float,
		material: Material, collide: bool = true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = center
	body.collision_layer = 1 if collide else 0
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 12
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = material
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = radius
		shape.height = height
		cs.shape = shape
		body.add_child(cs)
	parent.add_child(body)
	return body


## Çift taraflı market rafı. Uzunluk x ekseni boyunca; yaw ile döndürülür.
static func shelf(parent: Node, pos: Vector3, yaw: float, length: float, rng: RandomNumberGenerator) -> Node3D:
	var metal := color_mat("shelf_metal", Color(0.32, 0.34, 0.37), 0.5)
	var depth := 0.9
	var height := 2.0
	var levels := [0.12, 0.62, 1.12, 1.62, 1.98]
	var root := StaticBody3D.new()
	root.position = pos
	root.rotation.y = yaw
	root.collision_layer = 1
	root.collision_mask = 0
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(length, height, depth)
	cs.shape = shape
	cs.position.y = height * 0.5
	root.add_child(cs)

	# The shelf body is imported from a hand-authored, five-material GLB.  It has
	# folded steel shelves, upright posts, rivets and perforated back panels.
	# A primitive fallback remains for projects where the imported asset is absent.
	if _shelf_scene == null and ResourceLoader.exists("res://assets/models/supermarket_shelf.glb"):
		_shelf_scene = load("res://assets/models/supermarket_shelf.glb") as PackedScene
	if _shelf_scene != null:
		var detailed_rack := _shelf_scene.instantiate()
		detailed_rack.name = "DetailedMetalRack"
		root.add_child(detailed_rack)
	else:
		# Raf iskeleti: tekrar eden parçalar MultiMesh ile gruplanır; mobilde draw-call sayısı düşer.
		var back := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(length, height, 0.04)
		back.mesh = bm
		back.material_override = metal
		back.position.y = height * 0.5
		back.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(back)
		var plank_multi := MultiMesh.new()
		plank_multi.transform_format = MultiMesh.TRANSFORM_3D
		var plank_mesh := BoxMesh.new()
		plank_mesh.size = Vector3(length, 0.04, depth)
		plank_multi.mesh = plank_mesh
		plank_multi.instance_count = levels.size()
		for i in levels.size():
			plank_multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(0.0, float(levels[i]), 0.0)))
		var planks := MultiMeshInstance3D.new()
		planks.multimesh = plank_multi
		planks.material_override = metal
		planks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(planks)
		var supports_multi := MultiMesh.new()
		supports_multi.transform_format = MultiMesh.TRANSFORM_3D
		var support_mesh := BoxMesh.new()
		support_mesh.size = Vector3(0.055, height, 0.075)
		supports_multi.mesh = support_mesh
		var support_positions: Array[Vector3] = []
		for px in [-length * 0.5 + 0.035, 0.0, length * 0.5 - 0.035]:
			for pz in [-depth * 0.5 + 0.025, depth * 0.5 - 0.025]:
				support_positions.append(Vector3(px, height * 0.5, pz))
		supports_multi.instance_count = support_positions.size()
		for i in support_positions.size():
			supports_multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, support_positions[i]))
		var supports := MultiMeshInstance3D.new()
		supports.multimesh = supports_multi
		supports.material_override = metal
		supports.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(supports)

	# Ürünler: tek MultiMesh (tek draw call).
	var per_row: int = int(length / 0.26)
	var count: int = 4 * per_row * 2
	var can_count: int = int(ceil(float(count) / 4.0))
	var box_count: int = count - can_count
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var prod := BoxMesh.new()
	prod.size = Vector3(0.2, 0.3, 0.2)
	mm.mesh = prod
	mm.instance_count = box_count
	var cans := MultiMesh.new()
	cans.transform_format = MultiMesh.TRANSFORM_3D
	cans.use_colors = true
	var can_mesh := CylinderMesh.new()
	can_mesh.top_radius = 0.085
	can_mesh.bottom_radius = 0.085
	can_mesh.height = 0.28
	can_mesh.radial_segments = 10
	cans.mesh = can_mesh
	cans.instance_count = can_count
	var box_idx := 0
	var can_idx := 0
	var global_idx := 0
	for li in 4:
		var base_y: float = float(levels[li]) + 0.02 + 0.15
		for side in [-1, 1]:
			for i in per_row:
				var x: float = -length * 0.5 + 0.18 + i * 0.26
				var is_can := global_idx % 4 == 0
				var scale_box := Vector3(rng.randf_range(0.8, 1.15), rng.randf_range(0.7, 1.2), rng.randf_range(0.8, 1.1))
				var p := Vector3(x, base_y, float(side) * 0.22)
				var product_color := PRODUCT_COLORS[rng.randi() % PRODUCT_COLORS.size()]
				if is_can:
					cans.set_instance_transform(can_idx, Transform3D(Basis.from_scale(Vector3(rng.randf_range(0.9, 1.08), rng.randf_range(0.85, 1.15), 1.0)), p))
					cans.set_instance_color(can_idx, product_color)
					can_idx += 1
				else:
					mm.set_instance_transform(box_idx, Transform3D(Basis.from_scale(scale_box), p))
					mm.set_instance_color(box_idx, product_color)
					box_idx += 1
				global_idx += 1
	var package_mat := StandardMaterial3D.new()
	package_mat.albedo_texture = _make_package_texture()
	package_mat.vertex_color_use_as_albedo = true
	package_mat.roughness = 0.82
	package_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = package_mat
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mmi)
	var can_mmi := MultiMeshInstance3D.new()
	can_mmi.multimesh = cans
	can_mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var can_mat := StandardMaterial3D.new()
	can_mat.albedo_texture = load("res://assets/textures/can_label.png") as Texture2D
	can_mat.vertex_color_use_as_albedo = true
	can_mat.roughness = 0.56
	can_mat.metallic = 0.18
	can_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	can_mmi.material_override = can_mat
	can_mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(can_mmi)

	# Tek MultiMesh fiyat rayları: raf başına sekiz ayrı draw call yerine bir tane.
	var price_mat := color_mat("price_strip", Color(0.68, 0.66, 0.59), 0.88)
	var price_multi := MultiMesh.new()
	price_multi.transform_format = MultiMesh.TRANSFORM_3D
	var price_mesh := BoxMesh.new()
	price_mesh.size = Vector3(length, 0.055, 0.025)
	price_multi.mesh = price_mesh
	var price_positions: Array[Vector3] = []
	for li in 4:
		for side in [-1.0, 1.0]:
			price_positions.append(Vector3(0.0, float(levels[li]) + 0.055, side * (depth * 0.5 + 0.015)))
	price_multi.instance_count = price_positions.size()
	for i in price_positions.size():
		price_multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, price_positions[i]))
	var prices := MultiMeshInstance3D.new()
	prices.multimesh = price_multi
	prices.material_override = price_mat
	prices.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(prices)

	parent.add_child(root)
	return root


static func make_label3d(text: String, pos: Vector3, size: float, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.pixel_size = size
	l.modulate = color
	l.outline_size = 5
	l.outline_modulate = Color(0.015, 0.018, 0.02, 0.96)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.no_depth_test = false
	return l
