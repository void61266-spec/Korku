class_name Creature
extends CharacterBody3D
## Yaratık yapay zekâsı: devriye, ses/görüş algısı, kovalama, arama, kaybetme.
## Yol bulma: MarketBuilder waypoint'lerinden çalışma anında kurulan AStar3D grafı.

signal caught
signal state_changed(new_state: int)

enum State { DORMANT, PATROL, INVESTIGATE, CHASE, SEARCH }

const PATROL_SPEED := 1.9
const INVESTIGATE_SPEED := 2.8
const SEARCH_SPEED := 2.4
const GRAVITY := 18.0

var chase_speed := 4.5
var state: State = State.DORMANT
var active := false                 # Hikâye yaratığı serbest bıraktı mı?
var allow_underground := false
var allow_outdoors := false
var rage := false                   # Final: dinlenme yok, daha hızlı

var player: Player
var builder: MarketBuilder
var astar := AStar3D.new()
var graph_ready := false

var _path: Array[Vector3] = []
var _path_i := 0
var _repath_t := 0.0
var _perceive_t := 0.0
var _last_known := Vector3.ZERO
var _lost_t := 0.0
var _wait_t := 0.0
var _lull_t := 0.0
var _investigate_pos := Vector3.ZERO
var _search_spots: Array[HidingSpot] = []
var _search_t := 0.0
var _known_spot: HidingSpot = null
var _last_seen_time := -100.0
var _step_dist := 0.0
var _door_t := 0.0
var _voice: AudioStreamPlayer3D
var _steps: AudioStreamPlayer3D
var _growl_t := 0.0
var _vis: Node3D
var _arm_left: Node3D
var _arm_right: Node3D
var _leg_left: Node3D
var _leg_right: Node3D
var _visual_clock := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1
	add_to_group("creature")
	_build_visual()
	_voice = AudioStreamPlayer3D.new()
	_voice.bus = "SFX"
	_voice.unit_size = 6.0
	_voice.max_distance = 40.0
	add_child(_voice)
	_steps = AudioStreamPlayer3D.new()
	_steps.bus = "SFX"
	_steps.unit_size = 5.0
	_steps.max_distance = 30.0
	_steps.stream = AudioManager.get_stream(&"step")
	_steps.volume_db = 4.0
	add_child(_steps)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 2.0
	cs.shape = cap
	cs.position.y = 1.0
	add_child(cs)
	_set_visible(false)


func _add_creature_mesh(parent: Node3D, mesh: Mesh, material: Material, pos: Vector3,
		scl: Vector3 = Vector3.ONE, rot: Vector3 = Vector3.ZERO, cast_shadow: bool = false) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = pos
	instance.scale = scl
	instance.rotation = rot
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(instance)
	return instance


func _build_visual() -> void:
	_vis = Node3D.new()
	add_child(_vis)
	var skin := Props.tex_mat("creature_skin", Color(0.055, 0.045, 0.05), 0.12, 61, 0, Color.BLACK, 0.65, 0.94)
	skin.normal_scale = 0.24
	var cloth := Props.tex_mat("creature_cloth", Color(0.035, 0.04, 0.045), 0.08, 71, 0, Color.BLACK, 0.45, 0.98)
	var bone := Props.color_mat("creature_bone", Color(0.28, 0.25, 0.21), 0.88)
	var sinew := Props.color_mat("creature_sinew", Color(0.12, 0.035, 0.038), 0.92)
	var mouth_mat := Props.color_mat("creature_mouth", Color(0.006, 0.004, 0.006), 0.99)
	var socket_mat := Props.color_mat("creature_socket", Color(0.012, 0.008, 0.01), 0.9)
	var eye_mat := Props.color_mat("creature_eye", Color(0.75, 0.025, 0.018), 0.28, 3.0)
	var foot_mat := Props.color_mat("creature_feet", Color(0.024, 0.022, 0.025), 0.98)

	# Prefer the custom textured mesh core: its irregular body, fitted jaw,
	# inset eye sockets, rib geometry and torn apron read more organically than primitives.
	var custom_core_loaded := false
	if ResourceLoader.exists("res://assets/models/night_guard_core.glb"):
		var core_scene := load("res://assets/models/night_guard_core.glb") as PackedScene
		if core_scene != null:
			var core_instance := core_scene.instantiate()
			core_instance.name = "NightGuardCore"
			_vis.add_child(core_instance)
			custom_core_loaded = true
	if not custom_core_loaded:
		# Gaunt, hunched silhouette; layered forms catch the flashlight differently.
		var body_mesh := CapsuleMesh.new()
		body_mesh.radius = 0.33
		body_mesh.height = 1.92
		_add_creature_mesh(_vis, body_mesh, skin, Vector3(0.0, 1.04, 0.015), Vector3(1.0, 1.0, 0.82), Vector3.ZERO, true)
		var chest_mesh := SphereMesh.new()
		chest_mesh.radius = 0.36
		chest_mesh.height = 0.8
		_add_creature_mesh(_vis, chest_mesh, skin, Vector3(0.0, 1.42, -0.035), Vector3(1.03, 0.88, 0.75), Vector3.ZERO, true)
		var pelvis_mesh := SphereMesh.new()
		pelvis_mesh.radius = 0.245
		pelvis_mesh.height = 0.42
		_add_creature_mesh(_vis, pelvis_mesh, skin, Vector3(0.0, 0.73, 0.035), Vector3(1.1, 0.8, 0.9))
		var neck_mesh := CylinderMesh.new()
		neck_mesh.top_radius = 0.11
		neck_mesh.bottom_radius = 0.19
		neck_mesh.height = 0.34
		neck_mesh.radial_segments = 9
		_add_creature_mesh(_vis, neck_mesh, skin, Vector3(0.0, 1.88, -0.01), Vector3.ONE, Vector3.ZERO, true)

		# Long skull, recessed sockets, narrow red eyes and a torn-open jaw.
		var skull := SphereMesh.new()
		skull.radius = 0.245
		skull.height = 0.57
		_add_creature_mesh(_vis, skull, skin, Vector3(0.0, 2.12, -0.075), Vector3(0.96, 1.12, 0.86), Vector3.ZERO, true)
		var socket_mesh := SphereMesh.new()
		socket_mesh.radius = 0.065
		socket_mesh.height = 0.075
		for side in [-1.0, 1.0]:
			_add_creature_mesh(_vis, socket_mesh, socket_mat, Vector3(side * 0.094, 2.165, -0.278), Vector3(1.12, 1.0, 0.58))
			var eye_mesh := SphereMesh.new()
			eye_mesh.radius = 0.025
			eye_mesh.height = 0.043
			_add_creature_mesh(_vis, eye_mesh, eye_mat, Vector3(side * 0.096, 2.165, -0.315), Vector3(1.0, 0.94, 0.72))
			var brow_mesh := CapsuleMesh.new()
			brow_mesh.radius = 0.032
			brow_mesh.height = 0.18
			_add_creature_mesh(_vis, brow_mesh, skin, Vector3(side * 0.12, 2.235, -0.285), Vector3(1.0, 0.78, 0.68), Vector3(0.0, 0.0, -side * 0.48))
		var mouth_mesh := SphereMesh.new()
		mouth_mesh.radius = 0.16
		mouth_mesh.height = 0.25
		_add_creature_mesh(_vis, mouth_mesh, mouth_mat, Vector3(0.0, 2.015, -0.292), Vector3(1.0, 0.82, 0.36))
		var jaw_mesh := SphereMesh.new()
		jaw_mesh.radius = 0.17
		jaw_mesh.height = 0.14
		_add_creature_mesh(_vis, jaw_mesh, sinew, Vector3(0.0, 1.935, -0.285), Vector3(1.25, 0.72, 0.56))
		# Four upper and four lower uneven teeth, tiny meshes and no physics.
		var tooth_mesh := CylinderMesh.new()
		tooth_mesh.top_radius = 0.004
		tooth_mesh.bottom_radius = 0.022
		tooth_mesh.height = 0.07
		tooth_mesh.radial_segments = 5
		for i in 4:
			var tx := -0.09 + float(i) * 0.06
			_add_creature_mesh(_vis, tooth_mesh, bone, Vector3(tx, 2.045, -0.342), Vector3.ONE, Vector3(0.0, 0.0, PI))
			_add_creature_mesh(_vis, tooth_mesh, bone, Vector3(tx + 0.012, 1.98, -0.34), Vector3(0.8, 0.8, 0.9))
		# Exposed, worn rib shapes interrupt the smooth capsule silhouette.
		var rib_mesh := BoxMesh.new()
		rib_mesh.size = Vector3(0.31, 0.035, 0.026)
		for i in 5:
			var ry := 1.54 - float(i) * 0.115
			_add_creature_mesh(_vis, rib_mesh, bone, Vector3(0.0, ry, -0.286), Vector3(1.0, 1.0, 0.78), Vector3(0.0, 0.0, sin(float(i) * 1.7) * 0.045))
		# One dark, uneven work-apron with torn strips, hinting at the old night guard.
		var apron_mesh := BoxMesh.new()
		apron_mesh.size = Vector3(0.48, 0.24, 0.28)
		_add_creature_mesh(_vis, apron_mesh, cloth, Vector3(0.0, 0.74, -0.025), Vector3(1.0, 1.0, 0.9))
		var rag_mesh := BoxMesh.new()
		rag_mesh.size = Vector3(0.13, 0.34, 0.045)
		for i in 4:
			var rx := -0.2 + float(i) * 0.13
			_add_creature_mesh(_vis, rag_mesh, cloth, Vector3(rx, 0.51 - float(i % 2) * 0.055, -0.18), Vector3(1.0, 1.0 + float(i % 2) * 0.18, 1.0), Vector3(0.0, 0.0, float(i - 1) * 0.055))
		# Bone spurs break the shoulder outline in silhouette.
		var spur_mesh := CylinderMesh.new()
		spur_mesh.top_radius = 0.006
		spur_mesh.bottom_radius = 0.06
		spur_mesh.height = 0.24
		spur_mesh.radial_segments = 6
		for side in [-1.0, 1.0]:
			_add_creature_mesh(_vis, spur_mesh, bone, Vector3(side * 0.41, 1.57, 0.015), Vector3.ONE, Vector3(0.0, 0.0, -side * PI * 0.32))

	# Articulated arms swing during patrol/chase; arms and finger claws follow one parent each.
	_arm_left = Node3D.new()
	_arm_left.position = Vector3(-0.39, 1.48, -0.025)
	_vis.add_child(_arm_left)
	_arm_right = Node3D.new()
	_arm_right.position = Vector3(0.39, 1.48, -0.025)
	_vis.add_child(_arm_right)
	for side in [-1.0, 1.0]:
		var arm_root := _arm_left if side < 0.0 else _arm_right
		var upper := CapsuleMesh.new()
		upper.radius = 0.095
		upper.height = 0.74
		_add_creature_mesh(arm_root, upper, skin, Vector3(side * 0.025, -0.28, 0.0), Vector3(1.0, 1.0, 0.92))
		var forearm := CapsuleMesh.new()
		forearm.radius = 0.068
		forearm.height = 0.68
		_add_creature_mesh(arm_root, forearm, skin, Vector3(side * 0.065, -0.78, -0.075), Vector3.ONE, Vector3(0.0, 0.0, side * -0.1))
		var hand_mesh := SphereMesh.new()
		hand_mesh.radius = 0.09
		hand_mesh.height = 0.18
		_add_creature_mesh(arm_root, hand_mesh, skin, Vector3(side * 0.08, -1.105, -0.095), Vector3(0.8, 1.0, 0.72))
		var claw_mesh := CylinderMesh.new()
		claw_mesh.top_radius = 0.004
		claw_mesh.bottom_radius = 0.021
		claw_mesh.height = 0.17
		claw_mesh.radial_segments = 5
		for fi in 4:
			var fx := side * 0.08 + (float(fi) - 1.5) * 0.043
			_add_creature_mesh(arm_root, claw_mesh, bone, Vector3(fx, -1.205, -0.135), Vector3(0.72, 1.0, 0.72), Vector3(0.0, 0.0, PI))

	# Long uneven legs and broken-looking feet.
	_leg_left = Node3D.new()
	_leg_left.position = Vector3(-0.155, 0.82, 0.035)
	_vis.add_child(_leg_left)
	_leg_right = Node3D.new()
	_leg_right.position = Vector3(0.155, 0.82, 0.035)
	_vis.add_child(_leg_right)
	for side in [-1.0, 1.0]:
		var leg_root := _leg_left if side < 0.0 else _leg_right
		var leg_mesh := CapsuleMesh.new()
		leg_mesh.radius = 0.13
		leg_mesh.height = 0.86
		_add_creature_mesh(leg_root, leg_mesh, skin, Vector3(0.0, -0.28, 0.0), Vector3(1.0, 1.0, 0.95))
		var foot_mesh := BoxMesh.new()
		foot_mesh.size = Vector3(0.24, 0.12, 0.37)
		_add_creature_mesh(leg_root, foot_mesh, foot_mat, Vector3(0.0, -0.68, -0.105))

	var eye_glow := OmniLight3D.new()
	eye_glow.light_color = Color(0.85, 0.02, 0.012)
	eye_glow.light_energy = 0.12
	eye_glow.omni_range = 1.8
	eye_glow.position = Vector3(0.0, 2.17, -0.24)
	eye_glow.shadow_enabled = false
	_vis.add_child(eye_glow)


func _set_visible(v: bool) -> void:
	_vis.visible = v
	set_physics_process(true)


# --------------------------------------------------------------------------
# Kurulum
# --------------------------------------------------------------------------

func build_graph() -> void:
	astar.clear()
	var wps := builder.waypoints
	for i in wps.size():
		astar.add_point(i, wps[i])
	var space := get_world_3d().direct_space_state
	for i in wps.size():
		for j in range(i + 1, wps.size()):
			if wps[i].distance_to(wps[j]) <= 13.0 and _clear(space, wps[i], wps[j]):
				astar.connect_points(i, j)
	graph_ready = true


func _clear(space: PhysicsDirectSpaceState3D, a: Vector3, b: Vector3) -> bool:
	var dir := (b - a)
	var perp := dir.cross(Vector3.UP)
	perp = perp.normalized() * 0.35 if perp.length() > 0.01 else Vector3.RIGHT * 0.35
	for off in [-1.0, 0.0, 1.0]:
		var q := PhysicsRayQueryParameters3D.create(a + perp * off + Vector3.UP * 0.9,
			b + perp * off + Vector3.UP * 0.9, 1)
		if not space.intersect_ray(q).is_empty():
			return false
	return true


func activate(spawn_pos: Vector3) -> void:
	active = true
	_spawn(spawn_pos)


func deactivate() -> void:
	active = false
	_to_dormant(0.0)


func _spawn(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	_set_visible(true)
	_set_state(State.PATROL)
	_pick_patrol()


func _to_dormant(lull: float) -> void:
	_set_visible(false)
	global_position = Vector3(0, -50, 0)
	velocity = Vector3.ZERO
	_lull_t = lull
	_set_state(State.DORMANT)


func _set_state(s: State) -> void:
	if state == s:
		return
	state = s
	state_changed.emit(int(s))


func alert(pos: Vector3) -> void:
	if not active:
		return
	_investigate_pos = pos
	_set_state(State.INVESTIGATE)
	_wait_t = 0.0
	_set_goal(pos)


## Kamera sahnesi için: yapay zekâsız, sadece görünür figür.
func show_static(pos: Vector3, yaw: float) -> void:
	global_position = pos
	rotation.y = yaw
	_vis.visible = true


func hide_static() -> void:
	if not active:
		_vis.visible = false
		global_position = Vector3(0, -50, 0)


func is_visible_now() -> bool:
	return _vis.visible


func distance_to_player() -> float:
	if not _vis.visible or player == null:
		return 999.0
	return global_position.distance_to(player.global_position)


# --------------------------------------------------------------------------
# Algı
# --------------------------------------------------------------------------

func hear(pos: Vector3, radius: float) -> void:
	if not active or state == State.DORMANT or state == State.CHASE:
		return
	if global_position.distance_to(pos) <= radius:
		_investigate_pos = pos
		_set_state(State.INVESTIGATE)
		_wait_t = 0.0
		_set_goal(pos)


func on_player_hide_changed(hiding: bool) -> void:
	if hiding and state == State.CHASE and Time.get_ticks_msec() / 1000.0 - _last_seen_time < 1.2 \
			and distance_to_player() < 12.0:
		_known_spot = player.hiding_in


func _can_see_player() -> bool:
	if player == null or player.is_hidden() or player.dead:
		return false
	var eye := global_position + Vector3(0, 1.7, 0)
	var tgt := player.head_position()
	var to := tgt - eye
	var dist := to.length()
	var rng_ := 18.0 if player.flashlight_on else 9.0
	if player.crouching:
		rng_ *= 0.6
	if state == State.CHASE:
		rng_ *= 1.4
	if dist > rng_:
		return false
	var fwd := -global_transform.basis.z
	if dist > 3.0 and fwd.dot(to.normalized()) < cos(deg_to_rad(65.0)):
		return false
	var q := PhysicsRayQueryParameters3D.create(eye, tgt, 1 | 2)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


# --------------------------------------------------------------------------
# Yol bulma
# --------------------------------------------------------------------------

func _nearest_wp(pos: Vector3) -> int:
	var space := get_world_3d().direct_space_state
	var best := -1
	var best_d := INF
	var best_any := -1
	var best_any_d := INF
	for i in builder.waypoints.size():
		var d := pos.distance_to(builder.waypoints[i])
		if d < best_any_d:
			best_any_d = d
			best_any = i
		if d < best_d and d < 14.0 and _clear(space, pos, builder.waypoints[i]):
			best_d = d
			best = i
	return best if best != -1 else best_any


func _set_goal(pos: Vector3) -> void:
	_path.clear()
	_path_i = 0
	if not graph_ready:
		_path.append(pos)
		return
	var s := _nearest_wp(global_position)
	var e := _nearest_wp(pos)
	if s == -1 or e == -1:
		_path.append(pos)
		return
	for p in astar.get_point_path(s, e):
		_path.append(p)
	_path.append(pos)


func _follow_path(speed: float, delta: float) -> bool:
	## Hedefe ulaştıysa true döner.
	if _path_i >= _path.size():
		return true
	var target := _path[_path_i]
	var flat := Vector3(target.x - global_position.x, 0.0, target.z - global_position.z)
	var thresh := 0.7 if _path_i < _path.size() - 1 else 0.9
	if flat.length() < thresh and absf(target.y - global_position.y) < 2.5:
		_path_i += 1
		return _path_i >= _path.size()
	_steer(flat.normalized(), speed, delta)
	return false


func _steer(dir: Vector3, speed: float, delta: float) -> void:
	velocity.x = move_toward(velocity.x, dir.x * speed, 18.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * speed, 18.0 * delta)
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()
	if dir.length() > 0.01:
		var yaw := atan2(-dir.x, -dir.z)
		rotation.y = lerp_angle(rotation.y, yaw, minf(1.0, delta * 8.0))
	_step_dist += Vector2(velocity.x, velocity.z).length() * delta
	if _step_dist > (1.2 if speed > 3.5 else 1.9):
		_step_dist = 0.0
		_steps.pitch_scale = randf_range(0.6, 0.8)
		_steps.play()


func _pick_patrol() -> void:
	var ids: Array[int] = []
	for i in builder.waypoints.size():
		var w := builder.waypoints[i]
		var underground := w.y < -0.5 or w.z > 25.5
		var outdoors := (w.x < 0.5 or w.z < 0.5) and not underground
		if underground and not allow_underground:
			continue
		if outdoors and not allow_outdoors:
			continue
		if w.distance_to(global_position) > 7.0:
			ids.append(i)
	if ids.is_empty():
		return
	var pick: int = ids[randi() % ids.size()]
	if randf() < 0.25 and player != null:
		# Merak: oyuncunun bulunduğu bölgeye yakın bir noktaya yönel (ama oyuncuyu bilmeden).
		var best_d := INF
		for i in ids:
			var d := builder.waypoints[i].distance_to(player.global_position)
			if d < best_d:
				best_d = d
				pick = i
	_set_goal(builder.waypoints[pick])
	_wait_t = 0.0


# --------------------------------------------------------------------------
# Ana döngü
# --------------------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if player == null or builder == null:
		return
	if state == State.DORMANT:
		if active and _lull_t > 0.0:
			_lull_t -= delta
			if _lull_t <= 0.0:
				_respawn_far()
		return

	_door_t -= delta
	if _door_t <= 0.0:
		_door_t = 0.2
		_open_nearby_doors()

	_perceive_t -= delta
	if _perceive_t <= 0.0:
		_perceive_t = 0.12
		if _can_see_player():
			_last_known = player.global_position
			_last_seen_time = Time.get_ticks_msec() / 1000.0
			_lost_t = 0.0
			if state != State.CHASE:
				_begin_chase()

	_growl_t -= delta
	if state == State.CHASE and _growl_t <= 0.0:
		_growl_t = randf_range(3.0, 6.0)
		_growl()

	match state:
		State.PATROL: _tick_patrol(delta)
		State.INVESTIGATE: _tick_investigate(delta)
		State.CHASE: _tick_chase(delta)
		State.SEARCH: _tick_search(delta)

	# Yakalama
	if not player.dead and not player.is_hidden() and state == State.CHASE:
		var d := Vector2(global_position.x - player.global_position.x,
			global_position.z - player.global_position.z).length()
		if d < 1.3 and absf(global_position.y - player.global_position.y) < 2.0:
			_kill()


func _begin_chase() -> void:
	_set_state(State.CHASE)
	_known_spot = null
	_repath_t = 0.0
	_growl_t = 0.0


func _growl() -> void:
	_voice.stream = AudioManager.get_stream(&"growl")
	_voice.pitch_scale = randf_range(0.85, 1.1)
	_voice.volume_db = 6.0
	_voice.play()


func _kill() -> void:
	if player.dead:
		return
	caught.emit()


func _tick_patrol(delta: float) -> void:
	if _follow_path(PATROL_SPEED, delta):
		_wait_t += delta
		velocity.x = move_toward(velocity.x, 0.0, 10.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 10.0 * delta)
		if _wait_t > randf_range(2.5, 5.5):
			_pick_patrol()


func _tick_investigate(delta: float) -> void:
	if _follow_path(INVESTIGATE_SPEED, delta):
		_wait_t += delta
		if _wait_t > 3.0:
			_last_known = _investigate_pos
			_begin_search()


func _tick_chase(delta: float) -> void:
	var speed := chase_speed + (0.5 if rage else 0.0)
	var to_p := player.global_position - global_position
	_repath_t -= delta
	if _lost_t == 0.0 and Time.get_ticks_msec() / 1000.0 - _last_seen_time < 0.4:
		# Oyuncuyu görüyor.
		if to_p.length() < 6.0 and _clear(get_world_3d().direct_space_state, global_position, player.global_position):
			var flat := Vector3(to_p.x, 0.0, to_p.z).normalized()
			_steer(flat, speed, delta)
			return
		if _repath_t <= 0.0:
			_repath_t = 0.4
			_set_goal(player.global_position)
		_follow_path(speed, delta)
		return
	# Görüş kaybı
	_lost_t += delta
	if _known_spot != null:
		_set_goal(_known_spot.exit_position)
		_known_spot = null
	if _follow_path(speed, delta) or _lost_t > 5.0:
		_begin_search()
	if _lost_t == 0.0:
		_lost_t = 0.001


func _begin_search() -> void:
	_set_state(State.SEARCH)
	_search_spots.clear()
	var all: Array[HidingSpot] = []
	for n in get_tree().get_nodes_in_group("hiding_spots"):
		var h := n as HidingSpot
		if h != null and h.global_position.distance_to(_last_known) < 16.0:
			all.append(h)
	all.sort_custom(func(a: HidingSpot, b: HidingSpot) -> bool:
		return a.global_position.distance_to(_last_known) < b.global_position.distance_to(_last_known))
	for i in mini(3, all.size()):
		_search_spots.append(all[i])
	_search_t = 22.0
	_wait_t = 0.0
	_set_goal(_last_known)


func _tick_search(delta: float) -> void:
	_search_t -= delta
	if _search_t <= 0.0:
		_end_search()
		return
	if _follow_path(SEARCH_SPEED, delta):
		_wait_t += delta
		if _wait_t < 1.5:
			return
		_wait_t = 0.0
		if not _search_spots.is_empty():
			var spot: HidingSpot = _search_spots.pop_front()
			_set_goal(spot.exit_position if spot.exit_position != Vector3.ZERO else spot.global_position)
			_check_spot_after_arrival(spot)
		else:
			_end_search()


var _pending_spot: HidingSpot = null


func _check_spot_after_arrival(spot: HidingSpot) -> void:
	_pending_spot = spot


func _end_search() -> void:
	_pending_spot = null
	if rage:
		_set_state(State.PATROL)
		_pick_patrol()
		return
	# Uzun kovalama sonrası yaratık bir süre kaybolur: gerilim ve belirsizlik.
	if randf() < 0.7:
		_to_dormant(randf_range(25.0, 45.0))
	else:
		_set_state(State.PATROL)
		_pick_patrol()


func _process(delta: float) -> void:
	_visual_clock += delta
	if _vis != null and _vis.visible and _arm_left != null and _arm_right != null:
		var motion := Vector2(velocity.x, velocity.z).length()
		var gait_speed := 8.5 if state == State.CHASE else 4.8
		var gait := sin(_visual_clock * gait_speed) * clampf(motion / maxf(chase_speed, 1.0), 0.0, 1.0)
		_vis.position.y = sin(_visual_clock * 2.5) * 0.012 + absf(gait) * 0.018
		_arm_left.rotation.z = -0.12 + gait * 0.34
		_arm_right.rotation.z = 0.12 - gait * 0.34
		if _leg_left != null and _leg_right != null:
			_leg_left.rotation.z = gait * 0.16
			_leg_right.rotation.z = -gait * 0.16
	# Arama sırasında hedef saklanma noktasına varıldığında kontrol et.
	if state == State.SEARCH and _pending_spot != null:
		var target := _pending_spot.exit_position if _pending_spot.exit_position != Vector3.ZERO else _pending_spot.global_position
		if global_position.distance_to(target) < 1.4:
			var spot := _pending_spot
			_pending_spot = null
			if player != null and player.hiding_in == spot and not player.dead:
				if randf() < 0.45:
					_growl()
					_kill()
				else:
					_voice.stream = AudioManager.get_stream(&"growl")
					_voice.pitch_scale = 0.6
					_voice.volume_db = -2.0
					_voice.play()


func _respawn_far() -> void:
	var best := -1
	var best_d := 0.0
	for i in builder.waypoints.size():
		var w := builder.waypoints[i]
		var underground := w.y < -0.5 or w.z > 25.5
		var outdoors := (w.x < 0.5 or w.z < 0.5) and not underground
		if (underground and not allow_underground) or (outdoors and not allow_outdoors):
			continue
		var d := w.distance_to(player.global_position)
		if d > 22.0 and d > best_d * 0.0 and randf() < 0.3:
			best = i
			break
		if d > best_d:
			best_d = d
			best = i
	if best == -1:
		_lull_t = 5.0
		return
	_spawn(builder.waypoints[best])


func _open_nearby_doors() -> void:
	for n in get_tree().get_nodes_in_group("doors"):
		var d := n as Door
		if d == null or d.is_open:
			continue
		var center := d.global_position + d.global_transform.basis.x * d.width * 0.5
		if center.distance_to(global_position) < 1.8 and absf(center.y - global_position.y) < 3.0:
			d.force_open(true)
