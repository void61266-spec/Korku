extends Node
## Kullanıcı ayarları. Autoload: "Settings"

signal changed

const PATH := "user://settings.cfg"

var graphics_quality: int = 1   # 0 = düşük, 1 = orta, 2 = yüksek
var master_volume: float = 0.8
var music_volume: float = 0.6
var sfx_volume: float = 0.8
var sensitivity: float = 1.0
var vibration: bool = true
var fps_limit: int = 45
var control_scale: float = 1.0
var swap_hands: bool = false


func _ready() -> void:
	_register_inputs()
	_setup_buses()
	load_settings()
	apply()


func apply() -> void:
	Engine.max_fps = fps_limit
	_set_bus("Master", master_volume)
	_set_bus("Music", music_volume)
	_set_bus("SFX", sfx_volume)
	changed.emit()


func vibrate(ms: int) -> void:
	if vibration and (OS.has_feature("android") or OS.has_feature("ios")):
		Input.vibrate_handheld(ms)


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "graphics_quality", graphics_quality)
	cfg.set_value("game", "sensitivity", sensitivity)
	cfg.set_value("game", "vibration", vibration)
	cfg.set_value("game", "fps_limit", fps_limit)
	cfg.set_value("game", "control_scale", control_scale)
	cfg.set_value("game", "swap_hands", swap_hands)
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("audio", "music", music_volume)
	cfg.set_value("audio", "sfx", sfx_volume)
	cfg.save(PATH)


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	graphics_quality = clampi(int(cfg.get_value("game", "graphics_quality", graphics_quality)), 0, 2)
	sensitivity = clampf(float(cfg.get_value("game", "sensitivity", sensitivity)), 0.3, 3.0)
	vibration = bool(cfg.get_value("game", "vibration", vibration))
	fps_limit = int(cfg.get_value("game", "fps_limit", fps_limit))
	control_scale = clampf(float(cfg.get_value("game", "control_scale", control_scale)), 0.6, 1.6)
	swap_hands = bool(cfg.get_value("game", "swap_hands", swap_hands))
	master_volume = clampf(float(cfg.get_value("audio", "master", master_volume)), 0.0, 1.0)
	music_volume = clampf(float(cfg.get_value("audio", "music", music_volume)), 0.0, 1.0)
	sfx_volume = clampf(float(cfg.get_value("audio", "sfx", sfx_volume)), 0.0, 1.0)


func _set_bus(bus_name: String, value: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx < 0:
		return
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(value, 0.0001)))
	AudioServer.set_bus_mute(idx, value <= 0.001)


func _setup_buses() -> void:
	for bus_name in ["Music", "SFX"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var idx := AudioServer.bus_count - 1
			AudioServer.set_bus_name(idx, bus_name)
			AudioServer.set_bus_send(idx, "Master")


func _register_inputs() -> void:
	_add_key(&"move_forward", KEY_W)
	_add_key(&"move_back", KEY_S)
	_add_key(&"move_left", KEY_A)
	_add_key(&"move_right", KEY_D)
	_add_key(&"sprint", KEY_SHIFT)
	_add_key(&"crouch", KEY_C)
	_add_key(&"interact", KEY_E)
	_add_key(&"flashlight", KEY_F)
	_add_key(&"inventory", KEY_I)
	_add_key(&"inventory", KEY_TAB)
	_add_key(&"pause", KEY_ESCAPE)


func _add_key(action: StringName, keycode: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)
