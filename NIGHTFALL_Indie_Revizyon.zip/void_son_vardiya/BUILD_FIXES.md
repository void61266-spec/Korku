# Android APK derleme düzeltmeleri

Bu revizyonda oyun sahneleri ve mevcut GDScript oyun mantığı korunmuştur. Değişiklikler Android dışa aktarma ve CI derleme hattıyla sınırlıdır.

## Yapılan değişiklikler

- GitHub Actions iş akışı Android API 34 / Build Tools 34.0.0 ve JDK 17 kurulumunu açıkça yapar.
- Godot 4.3 resmi Linux çalıştırılabilir dosyası ve aynı sürümün Android export şablonları kurulup dosyaların varlığı kontrol edilir.
- Godot kaynak içe aktarma hataları artık `|| true` ile gizlenmez.
- Derleme betiği Godot sürümünü, Android SDK yolunu, Java araçlarını ve Android export şablonlarını APK dışa aktarmadan önce doğrular.
- APK'nın boş/oluşmamış olması hata sayılır; CI sonrasında APK arşivi doğrulanır.
- CI'da betik doğrudan `bash` ile çalıştırıldığı için ZIP/Git dosya izinlerine bağlı kalınmaz.

## Yerel derleme

Gerekli bileşenler: Godot 4.3, Godot 4.3 export templates, JDK 17+, Android SDK `platforms;android-34`, `build-tools;34.0.0` ve `platform-tools`.

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
export GODOT="/tam/yol/Godot_v4.3-stable_linux.x86_64"
bash scripts_build/build_android.sh debug
```

Başarılı olursa `build/NIGHTFALL_Son_Vardiya.apk` oluşur. Release APK için ayrı ve güvenli biçimde saklanan bir keystore gerekir; debug anahtarı yayın için kullanılmamalıdır.

## GitHub Actions ile derleme

Projeyi GitHub deposunun `main` dalına yükle veya Actions sekmesinde **Android APK** iş akışını **Run workflow** ile başlat. Başarılı çalışmadan sonra `NIGHTFALL-Son-Vardiya-APK` adlı artifact içinden APK'yı indir.

## NIGHTFALL görsel revizyonu

Bu ZIP sürümü `assets/models/` altına PBR raf ve alışveriş arabası modelleri ile dokulu bir yaratık gövde modeli ekler. Menü başlığı ayrı NIGHTFALL logo görseli kullanır. Yüzey dokuları ve normal haritaları `assets/textures/` altındadır. Tekrarlanan ürün ve tavan elemanları MultiMesh ile gruplanır; küçük dekoratif parçalarda gölge çizimi kapatılır.

## Doğrulama sınırı

Bu çalışma ortamında Godot, Android SDK ve internet erişimi bulunmadığından APK burada fiilen derlenemedi ve cihazda test edilmedi. Shell betiği sözdizimi (`bash -n`) ve projedeki açık `res://` dosya yolları kontrol edildi. Gerçek derleme sonucu GitHub Actions veya gerekli araçların kurulu olduğu bir makinede doğrulanmalıdır.
