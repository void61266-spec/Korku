extends Node
## Ölçüm sahnesi: godot --rendering-driver opengl3 res://tests/bench.tscn
## Ortam: BENCH_QUALITY=0|1|2. Görüş noktalarında draw call / nesne / kare süresi yazdırır.

var views := {
	"giris": [Vector3(14, 0.1, 3.5), PI],
	"market_orta": [Vector3(13.25, 0.1, 7.5), PI * 0.5],
	"market_uzun": [Vector3(1.4, 0.1, 7.5), -PI * 0.5],
	"koridor": [Vector3(2, 0.1, 15.5), -PI * 0.5],
	"depo": [Vector3(4, 0.1, 19), 0.0],
	"lab": [Vector3(4, -4.9, 41.5), 0.0],
	"otopark": [Vector3(14, 0.1, -3), PI * 0.5],
}


func _ready() -> void:
	var q := int(OS.get_environment("BENCH_QUALITY")) if OS.get_environment("BENCH_QUALITY") != "" else 1
	Settings.graphics_quality = q
	Settings.fps_limit = 0
	Engine.max_fps = 0
	var t0 := Time.get_ticks_msec()
	var g: Node = load("res://scenes/game.tscn").instantiate()
	get_tree().root.add_child.call_deferred(g)
	await get_tree().process_frame
	await get_tree().process_frame
	for i in 4:
		await get_tree().physics_frame
	var load_ms := Time.get_ticks_msec() - t0
	print("BENCH quality=%d load_ms=%d nodes=%d" % [q, load_ms, int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))])
	var player: Node3D = g.player
	var tot_dc := 0.0
	var tot_ft := 0.0
	var n_views := 0
	for k in views:
		player.global_position = views[k][0]
		player.rotation.y = views[k][1]
		for i in 6:
			await get_tree().process_frame
		var dc := 0.0
		var obj := 0.0
		var prim := 0.0
		var t := Time.get_ticks_usec()
		var frames := 15
		for i in frames:
			await get_tree().process_frame
			dc += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
			obj += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)
			prim += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
		var ft := float(Time.get_ticks_usec() - t) / frames / 1000.0
		print("VIEW %-12s drawcalls=%6.0f objects=%6.0f prims=%8.0f frame_ms=%6.2f script_ms=%5.2f" % [
			k, dc / frames, obj / frames, prim / frames, ft,
			(Performance.get_monitor(Performance.TIME_PROCESS) + Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)) * 1000.0])
		tot_dc += dc / frames
		tot_ft += ft
		n_views += 1
	print("MEM static_MB=%.1f texmem_MB=%.1f vidmem_MB=%.1f" % [
		Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
		Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED) / 1048576.0,
		Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0])
	print("AVG drawcalls=%.0f frame_ms=%.2f" % [tot_dc / n_views, tot_ft / n_views])
	get_tree().quit()
