extends Node
func _ready() -> void:
	Settings.graphics_quality = 1
	Engine.max_fps = 0
	var exp_name := OS.get_environment("EXP")
	var g: Node = load("res://scenes/game.tscn").instantiate()
	get_tree().root.add_child.call_deferred(g)
	for i in 8:
		await get_tree().physics_frame
	if exp_name == "no_occlusion":
		get_viewport().use_occlusion_culling = false
	if exp_name == "no_lowrack":
		for n in get_tree().get_nodes_in_group("rack_low"): n.visible = false
	if exp_name == "no_vr":
		for n in get_tree().get_nodes_in_group("product_mm"): (n as GeometryInstance3D).visibility_range_end = 0.0
		for n in get_tree().get_nodes_in_group("rack_high"): (n as GeometryInstance3D).visibility_range_end = 0.0
	if exp_name == "no_high":
		for n in get_tree().get_nodes_in_group("rack_high"): n.visible = false
	g.player.global_position = Vector3(14, 0.1, 3.5)
	g.player.rotation.y = PI
	for i in 25:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("/tmp/godot/exp_%s.png" % exp_name)
	get_tree().quit()
