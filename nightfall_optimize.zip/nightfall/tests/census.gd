extends Node
func _ready() -> void:
	var g: Node = load("res://scenes/game.tscn").instantiate()
	get_tree().root.add_child.call_deferred(g)
	for i in 8:
		await get_tree().process_frame
	var m: Node = g.market
	for i in m.shelves.size():
		var sh: Node3D = m.shelves[i]
		var kids := []
		for c in sh.get_children():
			var d := str(c.name)
			if c is MultiMeshInstance3D:
				var mm := (c as MultiMeshInstance3D).multimesh
				d += "[n=%d vr_end=%.0f]" % [mm.instance_count, (c as GeometryInstance3D).visibility_range_end]
			kids.append(d)
		print("SHELF ", i, " pos=", sh.position, " dyn=", not sh.has_meta("no_batch") and false, " kids=", kids)
	for c in m.get_children():
		if c is MultiMeshInstance3D:
			var mm := (c as MultiMeshInstance3D).multimesh
			print("BATCH ", c.name, " n=", mm.instance_count, " aabb=", (c as MultiMeshInstance3D).get_aabb().position.snapped(Vector3(0.1,0.1,0.1)), (c as MultiMeshInstance3D).get_aabb().size.snapped(Vector3(0.1,0.1,0.1)), " vr_end=", (c as GeometryInstance3D).visibility_range_end)
	get_tree().quit()
