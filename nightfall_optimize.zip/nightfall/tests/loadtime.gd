extends Node
func _ready() -> void:
	var runs := []
	for i in 3:
		var t := Time.get_ticks_msec()
		var m := MarketBuilder.new()
		add_child(m)
		m.build()
		runs.append(Time.get_ticks_msec() - t)
		m.queue_free()
		await get_tree().process_frame
	print("BUILD_MS ", runs)
	get_tree().quit()
