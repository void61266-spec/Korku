class_name StaticBatcher
extends RefCounted
## Hareket etmeyen MeshInstance3D'leri (duvar, zemin, raf iskeleti, dekor) bölge + materyal
## başına tek ArrayMesh'e birleştirir. Draw call sayısını ciddi biçimde düşürür.
## Birleştirilmeyenler: etkileşimli nesneler, kapılar, hareketli raflar ("no_batch" meta),
## yarı saydam materyaller, visibility range kullananlar.

const CELL := 10.0            # yatay bölge boyutu (m): culling ayrıntısı ile draw call arasında denge
const DETAIL_SIZE := 0.6      # bundan küçük parçalar "detay" grubuna gider (uzakta gizlenir)
const DETAIL_GROUP := &"detail_meshes"


static func batch(root: Node3D) -> Dictionary:
	var groups: Dictionary = {}
	var victims: Array[MeshInstance3D] = []
	_collect(root, root, groups, victims)
	var made := 0
	for key in groups:
		var g: Dictionary = groups[key]
		var am: ArrayMesh = (g.st as SurfaceTool).commit()
		if am == null or am.get_surface_count() == 0:
			continue
		var mi := MeshInstance3D.new()
		mi.name = "Batch_%d" % made
		mi.mesh = am
		if g.material != null:
			mi.material_override = g.material
		mi.cast_shadow = g.shadow
		root.add_child(mi)
		if g.detail:
			mi.add_to_group(DETAIL_GROUP)
		made += 1
	for v in victims:
		if is_instance_valid(v) and v.get_parent() != null:
			v.get_parent().remove_child(v)
			v.queue_free()
	return {"merged": victims.size(), "batches": made}


static func _skippable(n: Node) -> bool:
	return n is Interactable or n is Creature or n is Player or n is Light3D \
		or n is MultiMeshInstance3D or n.has_meta("no_batch")


static func _collect(node: Node, root: Node3D, groups: Dictionary, victims: Array[MeshInstance3D]) -> void:
	for c in node.get_children():
		if _skippable(c):
			continue
		if c is MeshInstance3D:
			_try_merge(c as MeshInstance3D, root, groups, victims)
		_collect(c, root, groups, victims)


## Yüzeyin hangi vertex dizilerini içerdiğini gösteren imza (aynı formatlılar birleştirilir).
static func _format_signature(mesh: Mesh, surface: int) -> String:
	var arrays := mesh.surface_get_arrays(surface)
	var sig := ""
	for i in Mesh.ARRAY_MAX:
		sig += "1" if (i < arrays.size() and arrays[i] != null) else "0"
	return sig


static func _rel_transform(n: Node3D, root: Node3D) -> Transform3D:
	var xf := Transform3D.IDENTITY
	var cur: Node = n
	while cur != null and cur != root:
		if cur is Node3D:
			xf = (cur as Node3D).transform * xf
		cur = cur.get_parent()
	return xf


static func _try_merge(mi: MeshInstance3D, root: Node3D, groups: Dictionary, victims: Array[MeshInstance3D]) -> void:
	var mesh := mi.mesh
	if mesh == null or not mi.visible or mi.layers != 1 or mi.visibility_range_end > 0.0 or mi.visibility_range_begin > 0.0:
		return
	if mi.skin != null:
		return
	var xf := _rel_transform(mi, root)
	var aabb := mesh.get_aabb()
	var sz := aabb.size * xf.basis.get_scale()
	var ext: float = maxf(sz.x, maxf(sz.y, sz.z))
	var detail := ext < DETAIL_SIZE
	var center := xf * aabb.get_center()
	var cell := Vector3i(floori(center.x / CELL), floori((center.y + 1.0) / 6.0), floori(center.z / CELL))
	var mats: Array = []
	for s in mesh.get_surface_count():
		if mesh is ArrayMesh and (mesh as ArrayMesh).surface_get_primitive_type(s) != Mesh.PRIMITIVE_TRIANGLES:
			return
		var mat: Material = mi.material_override
		if mat == null:
			mat = mi.get_surface_override_material(s)
		if mat == null:
			mat = mesh.surface_get_material(s)
		if mat is BaseMaterial3D and (mat as BaseMaterial3D).transparency != BaseMaterial3D.TRANSPARENCY_DISABLED:
			return
		mats.append(mat)
	for s in mesh.get_surface_count():
		var mat: Material = mats[s]
		var key := "%s|%d|%s|%d|%s" % [str(cell), mat.get_instance_id() if mat else 0,
			_format_signature(mesh, s), mi.cast_shadow, str(detail)]
		if not groups.has(key):
			var st := SurfaceTool.new()
			st.begin(Mesh.PRIMITIVE_TRIANGLES)
			groups[key] = {"st": st, "material": mat, "shadow": mi.cast_shadow, "detail": detail}
		(groups[key].st as SurfaceTool).append_from(mesh, s, xf)
	victims.append(mi)
