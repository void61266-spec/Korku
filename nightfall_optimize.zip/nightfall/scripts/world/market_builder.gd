class_name MarketBuilder
extends Node3D
## Süpermarketin tamamını (üst kat, yeraltı, dış alan) kodla üretir.
## Koordinatlar: x doğu, z güney (içeri), y yukarı. Birim = metre.

signal trigger_entered(trigger_id: String)

const WALL_H := 3.0
const WALL_T := 0.2
const DOOR_H := 2.3
## Kesintiden sonra yer değiştiren raflar (apply_changes); bunlar birleştirilmez.
const MOVING_SHELVES := [1, 5, 8, 10]

var rng := RandomNumberGenerator.new()
var doors: Dictionary = {}          # id -> Door
var points: Dictionary = {}         # id -> InteractPoint
var pickups: Array[Pickup] = []
var hiding_spots: Array[HidingSpot] = []
var shelves: Array[Node3D] = []
var lights: Array[FlickerLight] = []
var emergency_lights: Array[OmniLight3D] = []
var waypoints: Array[Vector3] = []
var cams: Array[Dictionary] = []
var player_spawn := Vector3(14.0, 0.1, 3.0)
var changes_applied := false
var batch_stats: Dictionary = {}

var _wall_mat: StandardMaterial3D
var _floor_mat: StandardMaterial3D
var _lamp_mat: StandardMaterial3D
var _fallen: Array[Node3D] = []


func build() -> void:
	rng.seed = 4821
	_wall_mat = Props.tex_mat("wall", Color(0.58, 0.6, 0.55), 0.07, 3, 0, Color.BLACK, 0.4)
	_floor_mat = Props.tex_mat("floor_tile", Color(0.62, 0.62, 0.58), 0.05, 2, 4, Color(0.28, 0.28, 0.27), 0.5, 0.55)
	_lamp_mat = Props.color_mat("lamp", Color(1, 0.96, 0.85), 0.3, 2.0)
	_build_surface_rooms()
	_build_walls()
	_build_underground()
	_build_outdoors()
	_build_main_store()
	_build_back_rooms()
	_build_security_office()
	_build_lab_props()
	_build_quality_details()
	_build_indie_dressing()
	for i in MOVING_SHELVES:
		if i < shelves.size():
			shelves[i].set_meta("no_batch", true)
	Props.flush_products(self)
	batch_stats = StaticBatcher.batch(self)
	_build_waypoints()
	_build_triggers()


# --------------------------------------------------------------------------
# Yardımcılar
# --------------------------------------------------------------------------

func _room(x1: float, z1: float, x2: float, z2: float, mat: Material, y: float = 0.0, ceil_h: float = WALL_H) -> void:
	var w := x2 - x1
	var d := z2 - z1
	Props.box(self, Vector3((x1 + x2) * 0.5, y - 0.1, (z1 + z2) * 0.5), Vector3(w, 0.2, d), mat)
	Props.box(self, Vector3((x1 + x2) * 0.5, y + ceil_h + 0.1, (z1 + z2) * 0.5), Vector3(w, 0.2, d),
		Props.tex_mat("ceiling", Color(0.45, 0.45, 0.43), 0.04, 9, 0, Color.BLACK, 0.5), 1, false)


## Duvar parçası + occlusion culling için görünmez occluder.
func _wall_box(center: Vector3, size: Vector3, mat: Material) -> void:
	Props.box(self, center, size, mat)
	if maxf(size.x, maxf(size.y, size.z)) >= 1.2 and minf(size.x, minf(size.y, size.z)) >= 0.15:
		var occ := OccluderInstance3D.new()
		var shape := BoxOccluder3D.new()
		shape.size = size
		occ.occluder = shape
		occ.position = center
		add_child(occ)


func wall_x(z: float, x1: float, x2: float, door_list: Array = [], y0: float = 0.0,
		h: float = WALL_H, mat: Material = null) -> void:
	var m: Material = mat if mat != null else _wall_mat
	var ds := door_list.duplicate()
	ds.sort_custom(func(a: Vector2, b: Vector2) -> bool: return a.x < b.x)
	var cursor := x1
	for d: Vector2 in ds:
		var left := d.x - d.y * 0.5
		var right := d.x + d.y * 0.5
		if left > cursor:
			_wall_box(Vector3((cursor + left) * 0.5, y0 + h * 0.5, z), Vector3(left - cursor, h, WALL_T), m)
		_wall_box(Vector3(d.x, y0 + DOOR_H + (h - DOOR_H) * 0.5, z), Vector3(d.y, h - DOOR_H, WALL_T), m)
		cursor = right
	if x2 > cursor:
		_wall_box(Vector3((cursor + x2) * 0.5, y0 + h * 0.5, z), Vector3(x2 - cursor, h, WALL_T), m)


func wall_z(x: float, z1: float, z2: float, door_list: Array = [], y0: float = 0.0,
		h: float = WALL_H, mat: Material = null) -> void:
	var m: Material = mat if mat != null else _wall_mat
	var ds := door_list.duplicate()
	ds.sort_custom(func(a: Vector2, b: Vector2) -> bool: return a.x < b.x)
	var cursor := z1
	for d: Vector2 in ds:
		var left := d.x - d.y * 0.5
		var right := d.x + d.y * 0.5
		if left > cursor:
			_wall_box(Vector3(x, y0 + h * 0.5, (cursor + left) * 0.5), Vector3(WALL_T, h, left - cursor), m)
		_wall_box(Vector3(x, y0 + DOOR_H + (h - DOOR_H) * 0.5, d.x), Vector3(WALL_T, h - DOOR_H, d.y), m)
		cursor = right
	if z2 > cursor:
		_wall_box(Vector3(x, y0 + h * 0.5, (cursor + z2) * 0.5), Vector3(WALL_T, h, z2 - cursor), m)


func _door(id: String, c: float, wall_pos: float, along_x: bool, width: float, locked: bool,
		req: String, msg: String, angle: float = -100.0) -> Door:
	var d := Door.new()
	d.door_id = id
	d.width = width
	d.locked = locked
	d.required_item = req
	d.locked_message = msg
	d.open_angle = angle
	if along_x:
		d.position = Vector3(c - width * 0.5, 0.0, wall_pos)
		d.base_yaw = 0.0
	else:
		d.position = Vector3(wall_pos, 0.0, c - width * 0.5)
		d.base_yaw = -PI * 0.5
	d.rotation.y = d.base_yaw
	add_child(d)
	doors[id] = d
	return d


func _light(pos: Vector3, energy: float, range_: float, color: Color = Color(1.0, 0.93, 0.8),
		mode: int = 0, lamp: bool = true, casts_shadow: bool = false) -> FlickerLight:
	var l := FlickerLight.new()
	l.position = pos
	l.base_energy = energy
	l.omni_range = range_
	l.light_color = color
	l.mode = mode
	l.wants_shadow = casts_shadow
	l.shadow_enabled = casts_shadow and Settings.graphics_quality >= 2
	add_child(l)
	lights.append(l)
	if lamp:
		var housing := MeshInstance3D.new()
		var housing_mesh := BoxMesh.new()
		housing_mesh.size = Vector3(1.42, 0.075, 0.48)
		housing.mesh = housing_mesh
		housing.material_override = Props.color_mat("lamp_housing", Color(0.23, 0.25, 0.25), 0.62)
		housing.position = pos + Vector3(0, 0.095, 0)
		housing.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(housing)
		var diffuser := MeshInstance3D.new()
		var diffuser_mesh := BoxMesh.new()
		diffuser_mesh.size = Vector3(1.22, 0.022, 0.31)
		diffuser.mesh = diffuser_mesh
		diffuser.material_override = _lamp_mat
		diffuser.position = pos + Vector3(0, 0.145, 0)
		diffuser.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(diffuser)
	return l


func _label(text: String, pos: Vector3, yaw: float, color: Color = Color(0.9, 0.9, 0.8)) -> void:
	var l := Props.make_label3d(text, pos, 0.006, color)
	l.rotation.y = yaw
	add_child(l)


func _point(id: String, event_id: String, pos: Vector3, size: Vector3, prompt: String,
		ok_msg: String, idle_msg: String = "Şimdilik buna gerek yok.", tag: bool = true) -> InteractPoint:
	var p := InteractPoint.new()
	p.point_id = id
	p.event_id = event_id
	p.position = pos
	p.hit_size = size
	p.prompt = prompt
	p.ok_message = ok_msg
	p.idle_message = idle_msg
	add_child(p)
	if tag:
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.16, 0.1, 0.03)
		mi.mesh = bm
		mi.material_override = Props.color_mat("tag", Color(1.0, 0.7, 0.15), 0.5, 1.6)
		p.add_child(mi)
	points[id] = p
	return p


func _pickup(id: String, item: String, pos: Vector3, avail: String = "", count: int = 1) -> Pickup:
	var p := Pickup.new()
	p.pickup_id = id
	p.item_id = item
	p.amount = count
	p.available_from = avail
	p.position = pos
	add_child(p)
	pickups.append(p)
	return p


func _hide(id: String, hit_pos: Vector3, hit_size: Vector3, hide_pos: Vector3, exit_pos: Vector3, yaw: float) -> HidingSpot:
	var h := HidingSpot.new()
	h.position = hit_pos
	h.hit_size = hit_size
	h.hide_position = hide_pos
	h.exit_position = exit_pos
	h.look_yaw = yaw
	h.name = id
	add_child(h)
	hiding_spots.append(h)
	return h


# --------------------------------------------------------------------------
# Yapı
# --------------------------------------------------------------------------

func _build_surface_rooms() -> void:
	var store_floor := _floor_mat
	var conc := Props.tex_mat("concrete", Color(0.42, 0.42, 0.4), 0.08, 12, 0, Color.BLACK, 0.4)
	var cold := Props.tex_mat("cold_floor", Color(0.5, 0.58, 0.62), 0.05, 13, 4, Color(0.2, 0.25, 0.28), 0.5)
	_room(0, 0, 28, 14, store_floor)
	_room(0, 14, 28, 17, conc)
	_room(0, 17, 8, 25, conc)       # depo
	_room(8, 17, 13, 25, cold)      # soğuk hava
	_room(13, 17, 19, 25, store_floor)   # personel
	_room(19, 17, 24, 25, conc)     # elektrik
	_room(24, 17, 28, 25, store_floor)   # tuvalet
	_room(28, 0, 34, 7, store_floor)     # güvenlik
	_room(28, 7, 34, 14, store_floor)    # ofis


func _build_walls() -> void:
	var dw := 1.2
	# Ana market dış duvarları
	wall_x(0.0, 0, 28, [Vector2(4.2, 3.8), Vector2(9.0, 3.8), Vector2(14.0, 1.6), Vector2(19.0, 3.8), Vector2(23.8, 3.8)])
	wall_z(0.0, 0, 14)
	wall_z(28.0, 0, 25, [Vector2(3.5, dw), Vector2(10.5, dw)])
	wall_x(14.0, 0, 28, [Vector2(20, dw)])
	# Arka koridor ve odalar
	wall_z(0.0, 14, 25, [Vector2(15.5, dw)])
	wall_x(17.0, 0, 28, [Vector2(4, dw), Vector2(10.5, dw), Vector2(16, dw), Vector2(21.5, dw), Vector2(26, dw)])
	for x in [8.0, 13.0, 19.0, 24.0]:
		wall_z(x, 17, 25)
	wall_x(25.0, 0, 28, [Vector2(4, 2.4)])
	# Güvenlik ve ofis
	wall_z(34.0, 0, 14)
	wall_x(0.0, 28, 34)
	wall_x(7.0, 28, 34)
	wall_x(14.0, 28, 34)

	# Kapılar
	_door("door_a", 20.0, 14.0, true, dw, false, "", "Kilitli.")
	_door("depo", 4.0, 17.0, true, dw, false, "", "Kilitli.")
	_door("cold", 10.5, 17.0, true, dw, true, "erisim_karti", "Soğuk hava deposu kilitli. Kart okuyucu var.")
	_door("personel", 16.0, 17.0, true, dw, false, "", "Kilitli.")
	_door("elektrik", 21.5, 17.0, true, dw, true, "personel_anahtari", "Elektrik odası kilitli.")
	_door("toilet", 26.0, 17.0, true, dw, false, "", "Kilitli.")
	_door("back", 15.5, 0.0, false, dw, true, "", "Arka kapı dışarıdan kilitli.")
	_door("security", 3.5, 28.0, false, dw, true, "personel_anahtari", "Güvenlik odası kilitli.")
	_door("office", 10.5, 28.0, false, dw, true, "ofis_anahtari", "Ofis kilitli.")

	# Gizli geçit: raf şeklinde kapı
	var hidden := _door("hidden", 4.0, 25.0, true, 2.4, true, "", "Raf sağlam görünüyor. Şimdi değil.", 100.0)
	hidden.thickness = 0.5
	hidden.skin = Props.color_mat("shelf_metal", Color(0.32, 0.34, 0.37), 0.5)
	hidden.closed_prompt = "Rafı çek"
	hidden.open_prompt = "Rafı kapat"

	# Ön kapı: kilitli cam kapı (açılmaz, sadece kontrol edilir)
	var glass := Props.color_mat("glass", Color(0.1, 0.14, 0.16, 0.5), 0.1)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	Props.box(self, Vector3(14, DOOR_H * 0.5, 0.0), Vector3(1.6, DOOR_H, 0.08), glass)
	_point("frontdoor", "frontdoor", Vector3(14, 1.2, 0.35), Vector3(1.8, 1.8, 0.6), "Ön kapıyı kontrol et",
		"Ön kapı sürgülü ve kilitli. Dışarıda sadece karanlık var.", "Ön kapı kilitli.")

	# Tabelalar
	_label("DEPO", Vector3(4, 2.6, 16.85), PI)
	_label("SOĞUK HAVA", Vector3(10.5, 2.6, 16.85), PI)
	_label("PERSONEL", Vector3(16, 2.6, 16.85), PI)
	_label("ELEKTRİK", Vector3(21.5, 2.6, 16.85), PI, Color(0.95, 0.8, 0.3))
	_label("WC", Vector3(26, 2.6, 16.85), PI)
	_label("GÜVENLİK", Vector3(27.85, 2.6, 3.5), -PI * 0.5)
	_label("OFİS", Vector3(27.85, 2.6, 10.5), -PI * 0.5)
	_label("ARKA KAPI", Vector3(0.15, 2.6, 15.5), PI * 0.5)


func _detail_box(parent: Node, pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var box_mesh := BoxMesh.new()
	box_mesh.size = size
	mesh_instance.mesh = box_mesh
	mesh_instance.material_override = material
	mesh_instance.position = pos
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mesh_instance)
	return mesh_instance


func _detail_cylinder(parent: Node, pos: Vector3, radius: float, height: float, material: Material,
		rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var cylinder_mesh := CylinderMesh.new()
	cylinder_mesh.top_radius = radius
	cylinder_mesh.bottom_radius = radius
	cylinder_mesh.height = height
	cylinder_mesh.radial_segments = 16
	mesh_instance.mesh = cylinder_mesh
	mesh_instance.material_override = material
	mesh_instance.position = pos
	mesh_instance.rotation = rot
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mesh_instance)
	return mesh_instance


func _multi_box(node_name: String, mesh_size: Vector3, positions: Array[Vector3], material: Material) -> MultiMeshInstance3D:
	if positions.is_empty():
		return null
	var multi := MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	var box_mesh := BoxMesh.new()
	box_mesh.size = mesh_size
	multi.mesh = box_mesh
	multi.instance_count = positions.size()
	for i in positions.size():
		multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, positions[i]))
	var instance := MultiMeshInstance3D.new()
	instance.name = node_name
	instance.multimesh = multi
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	return instance


func _car(pos: Vector3, yaw: float, paint: Color) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation.y = yaw
	add_child(root)
	var body_mat := Props.color_mat("car_paint_" + str(paint.to_html(false)), paint, 0.28)
	var rubber := Props.color_mat("car_rubber", Color(0.025, 0.028, 0.03), 0.94)
	var glass := Props.color_mat("car_glass", Color(0.035, 0.055, 0.065), 0.16)
	var chrome := Props.color_mat("car_chrome", Color(0.32, 0.34, 0.34), 0.26)
	var headlamp := Props.color_mat("car_headlamp", Color(0.86, 0.71, 0.42), 0.25, 0.4)
	var tail_lamp := Props.color_mat("car_tail_lamp", Color(0.55, 0.025, 0.018), 0.24, 0.65)
	var body := StaticBody3D.new()
	body.position.y = 0.58
	body.collision_layer = 1
	body.collision_mask = 0
	var body_mesh := MeshInstance3D.new()
	var chassis := BoxMesh.new()
	chassis.size = Vector3(4.0, 0.66, 1.78)
	body_mesh.mesh = chassis
	body_mesh.material_override = body_mat
	body.add_child(body_mesh)
	var body_shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3(4.0, 0.66, 1.78)
	body_shape.shape = box_shape
	body.add_child(body_shape)
	root.add_child(body)
	_detail_box(root, Vector3(-1.2, 0.94, 0), Vector3(1.18, 0.19, 1.68), body_mat)
	_detail_box(root, Vector3(1.48, 0.94, 0), Vector3(0.78, 0.19, 1.68), body_mat)
	_detail_box(root, Vector3(0.12, 1.16, 0), Vector3(1.85, 0.56, 1.39), body_mat)
	_detail_box(root, Vector3(0.12, 1.47, 0), Vector3(1.5, 0.08, 1.28), body_mat)
	# Front and rear windscreens are separate inset panels so the cabin reads as a car.
	var front_windscreen := _detail_box(root, Vector3(-0.68, 1.22, 0.0), Vector3(0.035, 0.34, 1.2), glass)
	front_windscreen.rotation.z = 0.22
	var rear_windscreen := _detail_box(root, Vector3(0.91, 1.21, 0.0), Vector3(0.035, 0.31, 1.1), glass)
	rear_windscreen.rotation.z = -0.18
	_detail_box(root, Vector3(-0.3, 1.12, 0.0), Vector3(0.5, 0.035, 1.12), glass)
	# Dark inset glass on both sides.
	for side in [-1.0, 1.0]:
		_detail_box(root, Vector3(-0.33, 1.2, side * 0.705), Vector3(0.72, 0.31, 0.026), glass)
		_detail_box(root, Vector3(0.55, 1.2, side * 0.705), Vector3(0.55, 0.31, 0.026), glass)
		_detail_box(root, Vector3(0.1, 0.82, side * 0.91), Vector3(2.55, 0.08, 0.09), chrome)
		for wx in [-1.22, 1.2]:
			_detail_cylinder(root, Vector3(wx, 0.34, side * 0.9), 0.37, 0.19, rubber, Vector3(PI * 0.5, 0.0, 0.0))
			_detail_cylinder(root, Vector3(wx, 0.34, side * 0.91), 0.17, 0.195, chrome, Vector3(PI * 0.5, 0.0, 0.0))
	_detail_box(root, Vector3(-2.02, 0.43, 0), Vector3(0.1, 0.18, 1.65), chrome)
	_detail_box(root, Vector3(2.02, 0.43, 0), Vector3(0.1, 0.18, 1.65), chrome)
	for side in [-1.0, 1.0]:
		_detail_box(root, Vector3(-2.075, 0.72, side * 0.57), Vector3(0.04, 0.16, 0.33), headlamp)
		_detail_box(root, Vector3(2.075, 0.72, side * 0.57), Vector3(0.04, 0.17, 0.28), tail_lamp)
	# mirrors add a distinct silhouette without adding physics.
	for side in [-1.0, 1.0]:
		_detail_box(root, Vector3(-0.58, 1.08, side * 0.82), Vector3(0.22, 0.1, 0.16), body_mat)


func _build_outdoors() -> void:
	var asphalt := Props.tex_mat("asphalt", Color(0.16, 0.16, 0.17), 0.05, 21, 0, Color.BLACK, 0.3, 1.0)
	var fence := Props.tex_mat("fence_wall", Color(0.25, 0.26, 0.27), 0.05, 22, 0, Color.BLACK, 0.3)
	Props.box(self, Vector3(13, -0.1, -7), Vector3(42, 0.2, 14), asphalt)
	Props.box(self, Vector3(-4, -0.1, 12.5), Vector3(8, 0.2, 25), asphalt)
	var h := 5.0
	wall_x(-14.0, -8, 34, [], 0.0, h, fence)
	wall_z(-8.0, -14, 25, [], 0.0, h, fence)
	wall_z(34.0, -14, 0, [], 0.0, h, fence)
	wall_x(25.0, -8, 0, [], 0.0, h, fence)
	wall_x(0.0, 28, 34, [], 0.0, h, fence)
	# Araçlar: basit blok yerine gövde, cam, tampon, lastik ve aydınlatma parçaları.
	_car(Vector3(8.0, 0.0, -8.0), 0.0, Color(0.12, 0.16, 0.19))
	_car(Vector3(20.0, 0.0, -9.0), 0.0, Color(0.23, 0.075, 0.07))
	_car(Vector3(27.0, 0.0, -5.0), PI * 0.5, Color(0.17, 0.18, 0.17))
	# Çöp konteynerleri
	var dump := Props.color_mat("dumpster", Color(0.1, 0.25, 0.12), 0.7)
	Props.box(self, Vector3(-6.2, 0.6, 18), Vector3(1.8, 1.2, 1.1), dump)
	Props.box(self, Vector3(-6.2, 0.6, 21), Vector3(1.8, 1.2, 1.1), dump)
	Props.box(self, Vector3(-2.5, 0.4, 23.5), Vector3(1.0, 0.8, 1.0), dump)
	# Vitrin camları ve metal doğramalar (vitrin boşlukları _build_walls içinde açıldı).
	var glass := Props.color_mat("front_store_glass", Color(0.12, 0.17, 0.19, 0.56), 0.14)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.metallic = 0.22
	glass.roughness = 0.18
	var frame := Props.color_mat("store_frame", Color(0.12, 0.14, 0.15), 0.5)
	for cx in [4.2, 9.0, 19.0, 23.8]:
		Props.box(self, Vector3(cx, 1.22, -0.015), Vector3(3.54, 1.78, 0.055), glass, 1, true)
		for edge_x in [cx - 1.82, cx + 1.82]:
			Props.box(self, Vector3(edge_x, 1.23, -0.07), Vector3(0.09, 2.02, 0.12), frame, 1, false)
		Props.box(self, Vector3(cx, 2.25, -0.07), Vector3(3.72, 0.09, 0.12), frame, 1, false)
		Props.box(self, Vector3(cx, 0.25, -0.07), Vector3(3.72, 0.12, 0.12), frame, 1, false)
		Props.box(self, Vector3(cx, 1.2, -0.075), Vector3(3.55, 0.045, 0.11), frame, 1, false)
	# Giriş saçağı, ışıklı marka tabelası ve kırmızı neon çizgisi.
	var sign_back := Props.color_mat("sign_back", Color(0.035, 0.045, 0.05), 0.55)
	var neon := Props.color_mat("sign_neon", Color(0.65, 0.025, 0.035), 0.32, 1.8)
	Props.box(self, Vector3(14.0, 2.68, -0.18), Vector3(6.4, 0.52, 0.16), sign_back, 1, false)
	Props.box(self, Vector3(14.0, 2.39, -0.27), Vector3(6.1, 0.025, 0.025), neon, 1, false)
	_label("NIGHTFALL  •  MARKET", Vector3(14.0, 2.66, -0.29), 0.0, Color(0.82, 0.09, 0.09))
	Props.box(self, Vector3(14.0, 2.28, -0.56), Vector3(5.0, 0.12, 1.05), frame, 1, false)
	Props.box(self, Vector3(14.0, 2.19, -0.56), Vector3(4.85, 0.025, 0.96), Props.color_mat("awning_top", Color(0.13, 0.16, 0.17), 0.48), 1, false)
	for x in [11.65, 12.45, 13.25, 14.05, 14.85, 15.65, 16.45]:
		Props.box(self, Vector3(x, 2.18, -0.56), Vector3(0.025, 0.028, 0.94), Props.color_mat("awning_seam", Color(0.28, 0.3, 0.3), 0.62), 1, false)
	# Otopark çizgileri tek MultiMesh ile çizilir.
	var parking_positions: Array[Vector3] = []
	for x in [-4.0, 2.0, 8.0, 14.0, 20.0, 26.0, 32.0]:
		parking_positions.append(Vector3(x, 0.008, -9.8))
	var parking_mat := Props.color_mat("parking_paint", Color(0.57, 0.54, 0.44), 0.9)
	_multi_box("ParkingMarkings", Vector3(0.055, 0.012, 6.6), parking_positions, parking_mat)
	# Sokak lambaları
	_light(Vector3(6, 4.0, -6), 0.9, 14.0, Color(0.85, 0.9, 1.0), 1, false)
	_light(Vector3(24, 4.0, -6), 0.9, 14.0, Color(0.85, 0.9, 1.0), 2, false)
	_light(Vector3(-4, 4.0, 18), 0.7, 11.0, Color(0.95, 0.85, 0.6), 1, false)
	_label("OTOPARK", Vector3(14, 3.5, -13.8), 0.0, Color(0.7, 0.7, 0.75))
	_label("ÇÖP ALANI", Vector3(-4, 3.5, 24.8), PI, Color(0.7, 0.7, 0.75))


func _build_underground() -> void:
	var conc := Props.tex_mat("ug_wall", Color(0.3, 0.32, 0.32), 0.08, 31, 0, Color.BLACK, 0.4)
	var ug_floor := Props.tex_mat("ug_floor", Color(0.28, 0.3, 0.31), 0.06, 32, 4, Color(0.1, 0.12, 0.12), 0.5, 0.5)
	var theta := atan2(5.0, 14.0)
	var length := sqrt(14.0 * 14.0 + 5.0 * 5.0)
	var normal := Vector3(0.0, cos(theta), sin(theta))
	var mid := Vector3(4.0, -2.5, 32.0)
	var ramp := Props.box(self, mid - normal * 0.2, Vector3(2.4, 0.4, length), ug_floor)
	ramp.rotation.x = theta
	var ceil_b := Props.box(self, mid + normal * 2.6, Vector3(2.4, 0.4, length), conc, 1, false)
	ceil_b.rotation.x = theta
	Props.box(self, Vector3(2.7, -1.5, 32), Vector3(0.2, 9.0, 14), conc)
	Props.box(self, Vector3(5.3, -1.5, 32), Vector3(0.2, 9.0, 14), conc)
	# Laboratuvar
	Props.box(self, Vector3(5, -5.1, 47), Vector3(22, 0.2, 16), ug_floor)
	Props.box(self, Vector3(5, -1.9, 47), Vector3(22, 0.2, 16), conc, 1, false)
	wall_z(-6.0, 39, 55, [], -5.0, 3.1, conc)
	wall_z(16.0, 39, 55, [], -5.0, 3.1, conc)
	wall_x(55.0, -6, 16, [], -5.0, 3.1, conc)
	wall_x(39.0, -6, 16, [Vector2(4, 2.4)], -5.0, 3.1, conc)
	# Aydınlatma
	_light(Vector3(4, 0.9, 29), 0.8, 7.0, Color(0.8, 0.9, 0.9), 1)
	_light(Vector3(4, -1.6, 35), 0.8, 7.0, Color(0.8, 0.9, 0.9), 2)
	_light(Vector3(-1, -2.2, 44), 1.0, 10.0, Color(0.7, 0.95, 1.0), 1)
	_light(Vector3(8, -2.2, 44), 1.0, 10.0, Color(0.7, 0.95, 1.0), 2)
	_light(Vector3(4, -2.2, 51), 1.0, 11.0, Color(0.7, 0.95, 1.0), 1)


func _build_main_store() -> void:
	var counter_mat := Props.tex_mat("counter", Color(0.35, 0.28, 0.22), 0.06, 41, 0, Color.BLACK, 0.7, 0.6)
	# Işıklar: 6 lamba (mobil limit: nesne başına 8 ışık)
	var idx := 0
	for z in [3.0, 7.5, 12.0]:
		for x in [7.0, 21.0]:
			var mode := 0
			if idx == 1: mode = 1
			if idx == 4: mode = 2
			_light(Vector3(x, 2.75, z), 1.08, 9.5, Color(1.0, 0.96, 0.88), mode, true, idx == 0 or idx == 3)
			idx += 1
	# Kasa tezgâhları
	var reg := Props.box(self, Vector3(6, 0.5, 2.2), Vector3(2.4, 1.0, 0.9), counter_mat)
	Props.box(reg, Vector3(0.5, 0.65, 0), Vector3(0.5, 0.3, 0.4), Props.color_mat("register", Color(0.1, 0.1, 0.12), 0.4))
	Props.box(self, Vector3(11, 0.5, 2.2), Vector3(2.4, 1.0, 0.9), counter_mat)
	_point("register", "register", Vector3(5.2, 1.25, 2.2), Vector3(0.8, 0.5, 0.8), "Kasayı kontrol et",
		"Kasa sayımı tamam. Çekmecede bir ofis anahtarı buldun.", "Kasa zaten kontrol edildi.")
	_pickup("note_vardiya", "not_vardiya", Vector3(11.4, 1.07, 2.2))
	# Raflar
	var row_z := [6.0, 9.0, 12.0]
	var col_x := [5.0, 10.5, 16.0, 21.5]
	for z in row_z:
		for x in col_x:
			shelves.append(Props.shelf(self, Vector3(x, 0, z), 0.0, 4.4, rng, MOVING_SHELVES.has(shelves.size())))
	# Soğutucu dolaplar (doğu duvarı boyunca)
	var fridge := Props.tex_mat("fridge", Color(0.38, 0.42, 0.44), 0.025, 83, 0, Color.BLACK, 0.9, 0.32)
	var glass := Props.color_mat("fridge_glass", Color(0.16, 0.22, 0.24, 0.42), 0.16)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.metallic = 0.18
	var handle := Props.color_mat("fridge_handle", Color(0.68, 0.7, 0.68), 0.28)
	var fridge_can_positions: Array[Vector3] = []
	var fridge_can_colors: Array[Color] = []
	var can_palette: Array[Color] = [Color(0.34, 0.43, 0.39), Color(0.47, 0.29, 0.23), Color(0.34, 0.42, 0.5), Color(0.65, 0.56, 0.38)]
	_light(Vector3(26.25, 1.65, 7.1), 0.48, 4.8, Color(0.55, 0.72, 0.9), 1, false, false)
	for z in [6.0, 8.2]:
		# Invisible cabinet collision keeps the player from walking through the refrigerator.
		var fridge_body := StaticBody3D.new()
		fridge_body.position = Vector3(27.35, 1.0, z)
		fridge_body.collision_layer = 1
		fridge_body.collision_mask = 0
		var fridge_shape_node := CollisionShape3D.new()
		var fridge_shape := BoxShape3D.new()
		fridge_shape.size = Vector3(0.95, 1.92, 1.95)
		fridge_shape_node.shape = fridge_shape
		fridge_body.add_child(fridge_shape_node)
		add_child(fridge_body)
		# Back, side rails, top and bottom create a hollow cabinet interior.
		Props.box(self, Vector3(27.78, 1.0, z), Vector3(0.12, 1.92, 1.88), fridge, 1, false)
		for side in [-1.0, 1.0]:
			Props.box(self, Vector3(27.34, 1.0, z + side * 0.92), Vector3(0.88, 1.92, 0.12), fridge, 1, false)
		Props.box(self, Vector3(27.34, 0.08, z), Vector3(0.88, 0.12, 1.88), fridge, 1, false)
		Props.box(self, Vector3(27.34, 1.92, z), Vector3(0.88, 0.12, 1.88), fridge, 1, false)
		for level in [0.48, 0.94, 1.40]:
			Props.box(self, Vector3(27.29, level, z), Vector3(0.72, 0.035, 1.67), handle, 1, false)
			for ci in 6:
				fridge_can_positions.append(Vector3(27.02, level + 0.17, z - 0.62 + float(ci) * 0.245))
				fridge_can_colors.append(can_palette[(ci + int(z)) % can_palette.size()])
		Props.box(self, Vector3(26.82, 1.0, z), Vector3(0.035, 1.78, 1.78), glass, 1, false)
		Props.box(self, Vector3(26.78, 1.0, z - 0.72), Vector3(0.045, 0.72, 0.035), handle, 1, false)
		Props.box(self, Vector3(26.78, 1.0, z + 0.72), Vector3(0.045, 0.72, 0.035), handle, 1, false)
		Props.box(self, Vector3(26.79, 1.82, z), Vector3(0.04, 0.035, 1.8), handle, 1, false)
	# All beverages share one MultiMesh across both refrigerator units.
	var fridge_cans := MultiMesh.new()
	fridge_cans.transform_format = MultiMesh.TRANSFORM_3D
	fridge_cans.use_colors = true
	var fridge_can_mesh := CylinderMesh.new()
	fridge_can_mesh.top_radius = 0.065
	fridge_can_mesh.bottom_radius = 0.065
	fridge_can_mesh.height = 0.31
	fridge_can_mesh.radial_segments = 8
	fridge_cans.mesh = fridge_can_mesh
	fridge_cans.instance_count = fridge_can_positions.size()
	for i in fridge_can_positions.size():
		fridge_cans.set_instance_transform(i, Transform3D(Basis.IDENTITY, fridge_can_positions[i]))
		fridge_cans.set_instance_color(i, fridge_can_colors[i])
	var fridge_cans_instance := MultiMeshInstance3D.new()
	fridge_cans_instance.multimesh = fridge_cans
	var fridge_drink_mat := StandardMaterial3D.new()
	fridge_drink_mat.albedo_texture = load("res://assets/textures/can_label.png") as Texture2D
	fridge_drink_mat.vertex_color_use_as_albedo = true
	fridge_drink_mat.roughness = 0.52
	fridge_drink_mat.metallic = 0.16
	fridge_drink_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	fridge_cans_instance.material_override = fridge_drink_mat
	fridge_cans_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(fridge_cans_instance)
	# Raf kontrol noktaları
	_point("shelf1", "shelves", Vector3(5.0, 1.0, 7.5), Vector3(1.2, 1.2, 0.6), "Rafı kontrol et",
		"Raf düzenli. Etiketler yerinde.", "Bu rafı zaten kontrol ettin.")
	_point("shelf2", "shelves", Vector3(16.0, 1.0, 10.5), Vector3(1.2, 1.2, 0.6), "Rafı kontrol et",
		"Stok eksiksiz. Son kullanma tarihleri geçmemiş.", "Bu rafı zaten kontrol ettin.")
	_point("shelf3", "shelves", Vector3(21.5, 1.0, 7.5), Vector3(1.2, 1.2, 0.6), "Rafı kontrol et",
		"Raflar tamam. Her şey yerli yerinde.", "Bu rafı zaten kontrol ettin.")
	# Pil
	_pickup("bat_main", "pil", Vector3(24.5, 0.15, 13.2))
	# Saklanma: kasa arkası
	_hide("hide_counter", Vector3(11, 0.8, 1.1), Vector3(1.8, 1.6, 0.7), Vector3(11, 0, 1.1),
		Vector3(11, 0, 3.4), PI)
	# Kapı A önündeki tetik için konum
	player_spawn = Vector3(14, 0.1, 3.5)


func _build_back_rooms() -> void:
	var crate := Props.tex_mat("crate", Color(0.45, 0.33, 0.2), 0.08, 51, 0, Color.BLACK, 0.8, 0.8)
	var metal := Props.color_mat("shelf_metal", Color(0.32, 0.34, 0.37), 0.5)
	# Koridor ışıkları
	_light(Vector3(5, 2.75, 15.5), 0.8, 8.0, Color(1.0, 0.95, 0.85), 1)
	_light(Vector3(14, 2.75, 15.5), 0.8, 8.0, Color(1.0, 0.95, 0.85), 0)
	_light(Vector3(23, 2.75, 15.5), 0.8, 8.0, Color(1.0, 0.95, 0.85), 2)
	var em := OmniLight3D.new()
	em.position = Vector3(14, 2.6, 15.5)
	em.light_color = Color(1.0, 0.1, 0.05)
	em.light_energy = 0.0
	em.omni_range = 7.0
	add_child(em)
	emergency_lights.append(em)

	# --- Depo ---
	_light(Vector3(2.5, 2.75, 21), 0.9, 8.0)
	_light(Vector3(6.0, 2.75, 21), 0.9, 8.0, Color(1.0, 0.93, 0.8), 1)
	for z in [19.0, 22.5]:
		shelves.append(Props.shelf(self, Vector3(1.6, 0, z), PI * 0.5, 2.8, rng, false))
	Props.box(self, Vector3(7.2, 0.5, 19.3), Vector3(1.0, 1.0, 1.0), crate)
	Props.box(self, Vector3(7.2, 1.5, 19.3), Vector3(1.0, 1.0, 1.0), crate)
	Props.box(self, Vector3(7.2, 0.5, 18.3), Vector3(1.0, 1.0, 1.0), crate)
	Props.box(self, Vector3(1.0, 0.5, 18.4), Vector3(1.0, 1.0, 1.0), crate)
	Props.box(self, Vector3(6.8, 0.5, 23.6), Vector3(1.2, 1.0, 1.2), crate)
	Props.box(self, Vector3(6.8, 1.5, 23.6), Vector3(1.0, 1.0, 1.0), crate)
	_point("depo_check", "depo", Vector3(6.8, 1.0, 21.5), Vector3(0.7, 0.7, 0.7), "Depo sayımını kontrol et",
		"Depo sayımı tamam. Arka duvardan tuhaf bir soğukluk geliyor.", "Depoyu zaten kontrol ettin.")
	_pickup("fuse", "sigorta", Vector3(6.8, 2.05, 23.6), "fuse_find")
	_pickup("bat_depo", "pil", Vector3(1.3, 0.15, 24.2))
	_hide("hide_depo", Vector3(7.7, 0.9, 20.4), Vector3(1.0, 1.8, 1.2), Vector3(7.6, 0, 20.5),
		Vector3(6.4, 0, 20.7), PI * 0.5)

	# --- Soğuk hava deposu ---
	_light(Vector3(10.5, 2.75, 21), 0.9, 8.0, Color(0.7, 0.85, 1.0), 1)
	shelves.append(Props.shelf(self, Vector3(9.3, 0, 20.0), PI * 0.5, 2.4, rng, false))
	Props.box(self, Vector3(11.8, 0.5, 23.6), Vector3(1.1, 1.0, 1.1), crate)
	_pickup("cell", "kaynak_hucresi", Vector3(11.8, 1.15, 23.6), "cell")
	_hide("hide_cold", Vector3(12.2, 0.9, 19.2), Vector3(0.9, 1.8, 0.9), Vector3(12.2, 0, 19.2),
		Vector3(11.3, 0, 20.3), PI * 0.5)

	# --- Personel odası ---
	_light(Vector3(16, 2.75, 21), 0.9, 8.0, Color(1.0, 0.9, 0.75))
	var table := Props.tex_mat("counter", Color(0.35, 0.28, 0.22), 0.06, 41, 0, Color.BLACK, 0.7, 0.6)
	Props.box(self, Vector3(16.5, 0.45, 22.5), Vector3(2.0, 0.9, 1.0), table)
	Props.box(self, Vector3(14.0, 1.0, 24.6), Vector3(0.9, 2.0, 0.6), metal)
	Props.box(self, Vector3(15.2, 1.0, 24.6), Vector3(0.9, 2.0, 0.6), metal)
	_pickup("key_staff", "personel_anahtari", Vector3(16.5, 0.95, 22.5))
	_pickup("bat_staff", "pil", Vector3(18.3, 0.15, 18.0))

	# --- Elektrik odası ---
	_light(Vector3(21.5, 2.75, 21), 0.8, 7.5, Color(1.0, 0.92, 0.7), 1)
	var em2 := OmniLight3D.new()
	em2.position = Vector3(21.5, 2.5, 18.0)
	em2.light_color = Color(1.0, 0.1, 0.05)
	em2.light_energy = 0.0
	em2.omni_range = 6.0
	add_child(em2)
	emergency_lights.append(em2)
	var panel_mat := Props.color_mat("panel", Color(0.35, 0.37, 0.4), 0.5)
	Props.box(self, Vector3(22.5, 1.3, 24.75), Vector3(1.0, 1.4, 0.3), panel_mat)
	Props.box(self, Vector3(20.5, 1.3, 24.75), Vector3(0.8, 1.0, 0.3), Props.color_mat("fusebox", Color(0.5, 0.15, 0.1), 0.5))
	Props.box(self, Vector3(23.1, 0.5, 20.3), Vector3(1.4, 1.0, 1.0), Props.color_mat("gen", Color(0.65, 0.5, 0.12), 0.6))
	_point("panel", "power_check", Vector3(22.5, 1.4, 24.5), Vector3(1.2, 1.4, 0.5), "Elektrik panosunu kontrol et",
		"Pano normal görünüyor... ama sayaç kendi kendine dönüyor.", "Elektrik panosu kontrol edildi.")
	_point("fusebox", "fuse_place", Vector3(20.5, 1.4, 24.5), Vector3(0.9, 1.2, 0.5), "Sigorta kutusu",
		"Sigortayı taktın. Kutu hafifçe uğuldamaya başladı.", "Sigorta kutusunun sigortası yanmış.")
	(points["fusebox"] as InteractPoint).requires_item = "sigorta"
	(points["fusebox"] as InteractPoint).consume_item = true
	(points["fusebox"] as InteractPoint).missing_message = "Sigorta kutusunun sigortası yanmış. Yeni bir sigorta lazım."
	_point("generator", "generator", Vector3(23.1, 1.1, 20.3), Vector3(1.5, 1.2, 1.1), "Jeneratörü çalıştır",
		"Jeneratör homurdanarak çalıştı. Işıklar geri geliyor...", "Jeneratör çalışmıyor.")
	_hide("hide_elec", Vector3(23.6, 1.0, 18.3), Vector3(0.8, 2.0, 0.8), Vector3(23.6, 0, 18.4),
		Vector3(22.7, 0, 18.8), PI * 0.5)
	Props.box(self, Vector3(23.6, 1.0, 18.3), Vector3(0.8, 2.0, 0.8), metal)

	# --- Tuvalet ---
	_light(Vector3(26, 2.75, 21), 0.8, 7.0, Color(0.9, 0.95, 0.85), 2)
	for z in [18.5, 20.5, 22.5]:
		Props.box(self, Vector3(27.5, 1.0, z), Vector3(1.4, 2.0, 1.6), Props.color_mat("stall", Color(0.4, 0.45, 0.45), 0.6))
	_pickup("note_wc", "not_tuvalet", Vector3(24.8, 0.15, 24.0))
	_hide("hide_wc", Vector3(27.0, 1.0, 18.5), Vector3(0.8, 2.0, 1.4), Vector3(27.2, 0, 18.5),
		Vector3(25.6, 0, 18.7), PI * 0.5)


func _build_security_office() -> void:
	var table := Props.tex_mat("counter", Color(0.35, 0.28, 0.22), 0.06, 41, 0, Color.BLACK, 0.7, 0.6)
	# Güvenlik odası
	_light(Vector3(31, 2.75, 3.5), 0.9, 8.0, Color(0.85, 0.95, 1.0), 1)
	Props.box(self, Vector3(32.8, 0.45, 2.5), Vector3(1.0, 0.9, 3.0), table)
	var mon := Props.color_mat("monitor", Color(0.2, 0.9, 0.5), 0.3, 1.5)
	Props.box(self, Vector3(32.8, 1.15, 1.8), Vector3(0.1, 0.5, 0.7), mon, 1, false)
	Props.box(self, Vector3(32.8, 1.15, 3.2), Vector3(0.1, 0.5, 0.7), mon, 1, false)
	var monitor := _point("monitor", "cameras", Vector3(32.3, 1.2, 2.5), Vector3(0.8, 0.9, 2.0), "Kameraları izle",
		"", "Monitörlerde sadece statik görüntü var.")
	monitor.idle_message = "Monitörlerde sadece statik görüntü var."
	_pickup("bat_sec", "pil", Vector3(32.7, 0.97, 4.4))
	# Ofis
	_light(Vector3(31, 2.75, 10.5), 0.9, 8.0, Color(1.0, 0.9, 0.75))
	Props.box(self, Vector3(31.0, 0.45, 11.8), Vector3(2.2, 0.9, 1.0), table)
	_pickup("note_ofis", "not_ofis", Vector3(31.0, 0.95, 11.8))
	_pickup("bat_office", "pil", Vector3(29.0, 0.15, 8.0))
	_hide("hide_office", Vector3(31.0, 0.5, 12.5), Vector3(2.0, 1.0, 0.5), Vector3(31.0, 0, 11.8),
		Vector3(31.0, 0, 9.6), 0.0)
	# Kameralar
	var cam_mat := Props.color_mat("cam_body", Color(0.08, 0.08, 0.09), 0.5)
	var cam_defs := [
		{"name": "KAM 1 - ANA MARKET", "pos": Vector3(14, 2.8, 0.5), "look": Vector3(14, 0.8, 10)},
		{"name": "KAM 2 - DEPO", "pos": Vector3(0.6, 2.8, 17.6), "look": Vector3(5, 0.8, 23)},
		{"name": "KAM 3 - ARKA KORİDOR", "pos": Vector3(0.6, 2.8, 14.4), "look": Vector3(22, 0.8, 15.5)},
	]
	for c in cam_defs:
		cams.append(c)
		Props.box(self, c.pos, Vector3(0.25, 0.2, 0.3), cam_mat, 1, false)


func _build_lab_props() -> void:
	var metal := Props.color_mat("lab_metal", Color(0.55, 0.58, 0.6), 0.4)
	var table := Props.color_mat("lab_table", Color(0.7, 0.72, 0.72), 0.5)
	# Terminal masası
	Props.box(self, Vector3(-4, -4.55, 44), Vector3(1.4, 0.9, 2.4), table)
	Props.box(self, Vector3(-4.3, -3.85, 44), Vector3(0.1, 0.6, 1.0), Props.color_mat("monitor", Color(0.2, 0.9, 0.5), 0.3, 1.5), 1, false)
	var term := _point("terminal", "terminal", Vector3(-3.7, -3.9, 44), Vector3(1.0, 1.0, 1.4), "Terminali kullan",
		"Kartı okuttun. Terminal sana kayıtları açtı.", "Terminal bir erişim kartı istiyor.")
	term.requires_item = "erisim_karti"
	term.missing_message = "Terminal bir erişim kartı istiyor."
	term.read_title = "VOID — Kayıt Terminali"
	term.read_text = "PROJE VOID / SEVİYE 3\n\nSüpermarket, laboratuvarın üstünü kapatmak için kuruldu.\nGece vardiyası personeli 'besleme programı' kapsamında seçiliyor.\n\nDenek 7, bir zamanlar bu mağazanın ilk gece bekçisiydi.\nKaynak Hücresi onu hayatta tutuyor ve uyandırıyor.\n\nHücre soğuk hava deposunda saklanıyor. Reaktöre geri takılırsa\nsistem kapanır ve Denek 7 durur.\n\nUYARI: Hücre çıkarıldığında Denek 7 senin yerini bilecek."
	# Kart masası
	Props.box(self, Vector3(0, -4.55, 52), Vector3(2.4, 0.9, 1.0), table)
	_pickup("keycard", "erisim_karti", Vector3(0, -4.05, 52), "keycard")
	_pickup("note_lab", "not_lab", Vector3(13.0, -4.4, 41.5))
	_pickup("bat_lab", "pil", Vector3(8.0, -4.85, 52.5))
	# Reaktör
	var glow := Props.color_mat("reactor_glow", Color(0.2, 0.85, 1.0), 0.2, 2.2)
	Props.cylinder(self, Vector3(11, -3.75, 49), 1.1, 2.5, glow)
	Props.cylinder(self, Vector3(11, -4.8, 49), 1.5, 0.4, metal)
	var reactor := _point("reactor", "reactor", Vector3(11, -3.9, 47.6), Vector3(1.6, 1.4, 0.8), "Hücreyi yerleştir",
		"Hücreyi yerleştirdin. Reaktör titremeye başladı!", "Reaktörün ortasında boş bir yuva var.")
	reactor.requires_item = "kaynak_hucresi"
	reactor.consume_item = true
	reactor.missing_message = "Reaktörde boş bir yuva var. Kaynak Hücresi lazım."
	# Tanklar ve masa
	var tank := Props.color_mat("tank", Color(0.3, 0.7, 0.5, 0.45), 0.1, 0.4)
	tank.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	for z in [42.0, 46.0, 50.0]:
		Props.cylinder(self, Vector3(-4.8, -3.7, z + 4.0), 0.6, 2.6, tank)
	Props.box(self, Vector3(-3, -4.55, 50), Vector3(3.0, 0.9, 1.4), table)
	_hide("hide_lab", Vector3(-3, -4.5, 50.9), Vector3(2.6, 1.0, 0.5), Vector3(-3, -5, 50),
		Vector3(-3, -5, 48.4), 0.0)
	_label("VOID / SEVİYE 3", Vector3(4, -2.7, 38.85), PI, Color(0.5, 0.95, 1.0))


func _build_quality_details() -> void:
	# Acoustic ceiling panels and their frame share three MultiMeshes (low draw-call cost).
	var panels: Array[Vector3] = []
	var long_grid: Array[Vector3] = []
	var cross_grid: Array[Vector3] = []
	for ix in 10:
		var x := 1.45 + float(ix) * 2.72
		for iz in 10:
			var z := 0.7 + float(iz) * 1.34
			panels.append(Vector3(x, 2.963, z))
			long_grid.append(Vector3(x, 2.985, z - 0.67))
			long_grid.append(Vector3(x, 2.985, z + 0.67))
			cross_grid.append(Vector3(x - 1.36, 2.985, z))
			cross_grid.append(Vector3(x + 1.36, 2.985, z))
	var panel_mat := Props.color_mat("ceiling_panel_satin", Color(0.37, 0.39, 0.39), 0.86)
	var grid_mat := Props.color_mat("ceiling_grid_metal", Color(0.16, 0.18, 0.18), 0.58)
	_multi_box("AcousticCeilingPanels", Vector3(2.68, 0.025, 1.29), panels, panel_mat)
	_multi_box("CeilingLongRails", Vector3(2.68, 0.025, 0.022), long_grid, grid_mat)
	_multi_box("CeilingCrossRails", Vector3(0.022, 0.025, 1.29), cross_grid, grid_mat)

	# Retail aisle signs with real backing panels instead of floating text.
	var sign_mat := Props.color_mat("aisle_sign", Color(0.035, 0.065, 0.07), 0.46)
	for entry in [
		{"x": 5.0, "text": "ATIŞTIRMALIK"},
		{"x": 10.5, "text": "KAHVE  /  ÇAY"},
		{"x": 16.0, "text": "KONSERVE"},
		{"x": 21.5, "text": "EV ÜRÜNLERİ"}
	]:
		var sx: float = float(entry["x"])
		Props.box(self, Vector3(sx, 2.56, 4.35), Vector3(2.1, 0.34, 0.09), sign_mat, 1, false)
		_label(String(entry["text"]), Vector3(sx, 2.53, 4.295), PI, Color(0.78, 0.78, 0.69))

	# Hygienic wall skirting and protective corner strips.
	var skirting := Props.color_mat("wall_skirting", Color(0.16, 0.18, 0.18), 0.72)
	# One box per wall side is enough: no collision nodes and no repeated tiny meshes.
	_detail_box(self, Vector3(6.6, 0.105, 0.115), Vector3(13.2, 0.16, 0.06), skirting)
	_detail_box(self, Vector3(21.4, 0.105, 0.115), Vector3(13.2, 0.16, 0.06), skirting)
	_detail_box(self, Vector3(0.115, 0.105, 7.0), Vector3(0.06, 0.16, 14.0), skirting)
	_detail_box(self, Vector3(27.885, 0.105, 7.0), Vector3(0.06, 0.16, 14.0), skirting)

	# Damp glossy patches: a few translucent planes, no physics or real-time reflection cost.
	var wet := StandardMaterial3D.new()
	wet.albedo_color = Color(0.025, 0.035, 0.04, 0.32)
	wet.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wet.roughness = 0.16
	wet.metallic = 0.28
	wet.cull_mode = BaseMaterial3D.CULL_DISABLED

	var puddle_defs := [
		[Vector3(3.1, 0.008, 4.8), Vector2(1.4, 0.62), 0.28],
		[Vector3(18.5, 0.009, 8.3), Vector2(1.7, 0.72), -0.37],
		[Vector3(23.2, 0.008, 12.8), Vector2(1.0, 0.44), 0.8],
		[Vector3(5.7, 0.008, 15.8), Vector2(1.4, 0.42), -0.22],
		[Vector3(18.6, 0.008, 15.3), Vector2(1.6, 0.5), 0.2],
		[Vector3(4.1, 0.008, 23.2), Vector2(1.5, 0.72), 0.12],
		[Vector3(10.2, -4.988, 45.2), Vector2(1.3, 0.56), -0.5]
	]
	for puddle in puddle_defs:
		var plane := MeshInstance3D.new()
		var plane_mesh := PlaneMesh.new()
		plane_mesh.size = puddle[1]
		plane.mesh = plane_mesh
		plane.material_override = wet
		plane.position = puddle[0]
		plane.rotation.y = float(puddle[2])
		plane.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(plane)

	# A few low-cost clutter pieces break up clean, empty floor areas.
	var debris_mat := Props.tex_mat("crate", Color(0.45, 0.33, 0.2), 0.08, 51, 0, Color.BLACK, 0.8, 0.8)
	var debris_positions: Array[Vector3] = []
	for d in [Vector3(3.5, 0.018, 11.5), Vector3(17.2, 0.018, 5.4), Vector3(22.9, 0.018, 10.1), Vector3(6.0, 0.018, 24.1)]:
		debris_positions.append(d)
	_multi_box("FloorDebris", Vector3(0.24, 0.025, 0.12), debris_positions, debris_mat)


func _build_indie_dressing() -> void:
	# Industrial services add believable visual scale while staying cheap on mobile.
	var duct_mat := Props.tex_mat("fridge", Color(0.24, 0.27, 0.28), 0.02, 91, 0, Color.BLACK, 1.1, 0.62)
	var pipe_mat := Props.color_mat("ceiling_pipe", Color(0.17, 0.19, 0.19), 0.48)
	var cable_mat := Props.color_mat("ceiling_cable", Color(0.035, 0.04, 0.043), 0.92)
	var steel_mat := Props.color_mat("brushed_steel", Color(0.43, 0.46, 0.46), 0.38)
	var black_mat := Props.color_mat("security_hardware", Color(0.035, 0.044, 0.048), 0.56)
	var lens_mat := Props.color_mat("security_lens", Color(0.11, 0.24, 0.25), 0.18, 0.32)
	var warning_mat := Props.color_mat("warning_yellow", Color(0.73, 0.47, 0.07), 0.7)
	var warning_dark := Props.color_mat("warning_black", Color(0.045, 0.045, 0.04), 0.85)
	var led_red := Props.color_mat("small_red_led", Color(0.65, 0.018, 0.012), 0.3, 1.4)

	# Galvanised ventilation ducts and utility pipework across the ceiling.
	for x in [2.1, 25.8]:
		_detail_box(self, Vector3(x, 2.72, 7.2), Vector3(0.38, 0.19, 10.7), duct_mat)
		_detail_box(self, Vector3(x, 2.60, 7.2), Vector3(0.24, 0.025, 10.4), steel_mat)
	_detail_cylinder(self, Vector3(14.0, 2.72, 7.0), 0.038, 12.5, pipe_mat, Vector3(PI * 0.5, 0.0, 0.0))
	_detail_cylinder(self, Vector3(14.65, 2.78, 7.0), 0.019, 12.2, cable_mat, Vector3(PI * 0.5, 0.0, 0.0))
	_detail_cylinder(self, Vector3(7.0, 2.74, 7.1), 0.026, 12.0, pipe_mat, Vector3(0.0, 0.0, PI * 0.5))

	# HVAC vent frames and blades use two batched draw calls.
	var vent_positions: Array[Vector3] = []
	for vx in [3.0, 12.0, 24.5]:
		for vz in [2.4, 11.6]:
			vent_positions.append(Vector3(vx, 2.83, vz))
	_multi_box("HVACVentFrames", Vector3(0.9, 0.04, 0.55), vent_positions, black_mat)
	var blade_positions: Array[Vector3] = []
	for vp in vent_positions:
		for i in 5:
			blade_positions.append(Vector3(vp.x - 0.32 + float(i) * 0.16, 2.855, vp.z))
	_multi_box("HVACVentBlades", Vector3(0.025, 0.018, 0.47), blade_positions, steel_mat)

	# CCTV cameras have an actual lens and a fault LED instead of an untextured cube.
	for cp in [Vector3(0.34, 2.56, 1.0), Vector3(27.58, 2.56, 13.0), Vector3(0.42, 2.56, 13.0)]:
		_detail_box(self, cp, Vector3(0.26, 0.13, 0.22), black_mat)
		_detail_box(self, cp + Vector3(0.0, -0.035, -0.09), Vector3(0.19, 0.055, 0.10), steel_mat)
		_detail_cylinder(self, cp + Vector3(0.0, -0.015, -0.155), 0.035, 0.055, lens_mat, Vector3(PI * 0.5, 0.0, 0.0))
		_detail_box(self, cp + Vector3(0.07, 0.06, -0.10), Vector3(0.025, 0.025, 0.025), led_red)

	# Checkout belts, card terminals and scanner glass.
	var belt_mat := Props.color_mat("checkout_belt", Color(0.055, 0.06, 0.06), 0.72)
	var terminal_mat := Props.color_mat("card_terminal", Color(0.035, 0.045, 0.05), 0.44)
	var terminal_screen := Props.color_mat("card_terminal_screen", Color(0.12, 0.29, 0.27), 0.26, 0.2)
	for cx in [6.0, 11.0]:
		_detail_box(self, Vector3(cx, 1.015, 2.22), Vector3(1.48, 0.035, 0.48), belt_mat)
		_detail_box(self, Vector3(cx + 0.63, 1.12, 2.17), Vector3(0.22, 0.18, 0.19), terminal_mat)
		_detail_box(self, Vector3(cx + 0.63, 1.205, 2.075), Vector3(0.15, 0.012, 0.09), terminal_screen)
		_detail_cylinder(self, Vector3(cx - 0.84, 1.09, 2.48), 0.075, 0.12, steel_mat, Vector3(PI * 0.5, 0.0, 0.0))

	# A custom imported wire cart uses rounded rods, a tapered basket, real wheels,
	# a lower rack and grocery cartons.  Keep the old procedural version as fallback.
	var cart_scene: PackedScene = null
	if ResourceLoader.exists("res://assets/models/shopping_cart.glb"):
		cart_scene = load("res://assets/models/shopping_cart.glb") as PackedScene
	if cart_scene != null:
		var cart_model := cart_scene.instantiate()
		cart_model.name = "WireShoppingCart"
		cart_model.position = Vector3(2.55, 0.0, 4.2)
		cart_model.rotation.y = -0.12
		add_child(cart_model)
	else:
		# A small wire shopping cart, tucked beside the first aisle.
		var cart := Node3D.new()
		cart.position = Vector3(2.55, 0.0, 4.2)
		cart.rotation.y = -0.12
		add_child(cart)
		var wire := Props.color_mat("cart_wire", Color(0.28, 0.31, 0.31), 0.42)
		for y in [0.60, 0.80, 0.98]:
			for x in [-0.31, 0.31]:
				_detail_box(cart, Vector3(x, y, 0.02), Vector3(0.025, 0.025, 0.62), wire)
			for z in [-0.28, 0.32]:
				_detail_box(cart, Vector3(0.0, y, z), Vector3(0.62, 0.025, 0.025), wire)
		for x in [-0.29, 0.29]:
			for z in [-0.23, -0.08, 0.07, 0.22]:
				_detail_box(cart, Vector3(x, 0.79, z), Vector3(0.022, 0.36, 0.022), wire)
		for z in [-0.23, -0.08, 0.07, 0.22]:
			_detail_box(cart, Vector3(0.0, 0.79, z), Vector3(0.6, 0.022, 0.022), wire)
		_detail_box(cart, Vector3(0.0, 0.45, 0.28), Vector3(0.48, 0.045, 0.06), wire)
		var cart_handle_left := _detail_box(cart, Vector3(-0.26, 0.69, 0.42), Vector3(0.035, 0.48, 0.035), wire)
		cart_handle_left.rotation.x = -0.2
		var cart_handle_right := _detail_box(cart, Vector3(0.26, 0.69, 0.42), Vector3(0.035, 0.48, 0.035), wire)
		cart_handle_right.rotation.x = -0.2
		_detail_box(cart, Vector3(0.0, 0.91, 0.54), Vector3(0.56, 0.055, 0.045), black_mat)
		for x in [-0.25, 0.25]:
			for z in [-0.28, 0.36]:
				_detail_cylinder(cart, Vector3(x, 0.12, z), 0.075, 0.045, black_mat, Vector3(PI * 0.5, 0.0, 0.0))
		for i in 3:
			var gm := Props.color_mat("cart_goods_%d" % i, [Color(0.32, 0.25, 0.18), Color(0.18, 0.28, 0.25), Color(0.38, 0.34, 0.25)][i], 0.9)
			_detail_box(cart, [Vector3(-0.14, 0.75, -0.02), Vector3(0.08, 0.75, 0.08), Vector3(0.16, 0.78, -0.13)][i], Vector3(0.14, 0.16, 0.13), gm)

	# Yellow wet-floor warning sign in front of the cold-drink case.
	var caution := Node3D.new()
	caution.position = Vector3(24.7, 0.0, 11.2)
	caution.rotation.y = -0.2
	add_child(caution)
	var caution_face := _detail_box(caution, Vector3(0.0, 0.42, 0.0), Vector3(0.42, 0.65, 0.035), warning_mat)
	caution_face.rotation.z = -0.12
	var caution_label := _detail_box(caution, Vector3(0.0, 0.42, -0.035), Vector3(0.24, 0.43, 0.012), warning_dark)
	caution_label.rotation.z = -0.12
	var caution_leg_l := _detail_box(caution, Vector3(-0.04, 0.1, 0.0), Vector3(0.05, 0.2, 0.05), black_mat)
	caution_leg_l.rotation.z = -0.14
	var caution_leg_r := _detail_box(caution, Vector3(0.04, 0.1, 0.0), Vector3(0.05, 0.2, 0.05), black_mat)
	caution_leg_r.rotation.z = 0.14
	_detail_box(caution, Vector3(0.0, 0.75, 0.0), Vector3(0.26, 0.025, 0.025), warning_mat)

	# Small red fault indicators make the power room readable in low light.
	_detail_box(self, Vector3(20.5, 1.47, 24.54), Vector3(0.12, 0.035, 0.018), led_red)
	_detail_box(self, Vector3(22.53, 1.68, 24.54), Vector3(0.16, 0.025, 0.018), led_red)

	# Transparent, hand-authored decals break up large flat surfaces without extra physics.
	var drag_mat := StandardMaterial3D.new()
	drag_mat.albedo_texture = load("res://assets/textures/decal_drag.png") as Texture2D
	drag_mat.albedo_color = Color(0.78, 0.72, 0.7, 0.82)
	drag_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	drag_mat.roughness = 0.94
	drag_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var oil_mat := StandardMaterial3D.new()
	oil_mat.albedo_texture = load("res://assets/textures/decal_oil.png") as Texture2D
	oil_mat.albedo_color = Color(0.8, 0.86, 0.88, 0.72)
	oil_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	oil_mat.roughness = 0.22
	oil_mat.metallic = 0.12
	oil_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	for mark in [
		[Vector3(19.0, 0.012, 12.7), Vector2(1.5, 0.7), -0.2],
		[Vector3(18.1, 0.012, 14.45), Vector2(1.1, 0.5), 0.38],
		[Vector3(8.3, 0.012, 23.1), Vector2(1.0, 0.46), -0.5],
		[Vector3(9.2, -4.988, 48.0), Vector2(1.5, 0.72), 0.25]
	]:
		_decal_plane(self, mark[0], mark[1], drag_mat, Vector3(0.0, float(mark[2]), 0.0))
	for mark in [
		[Vector3(5.5, 0.013, 5.5), Vector2(1.4, 0.66), 0.3],
		[Vector3(21.8, 0.013, 9.7), Vector2(1.5, 0.6), -0.5],
		[Vector3(24.2, 0.013, 12.7), Vector2(1.1, 0.48), 0.2],
		[Vector3(2.8, 0.013, 18.8), Vector2(1.0, 0.5), -0.4]
	]:
		_decal_plane(self, mark[0], mark[1], oil_mat, Vector3(0.0, float(mark[2]), 0.0))

	var grime_mat := StandardMaterial3D.new()
	grime_mat.albedo_texture = load("res://assets/textures/decal_wall_grime.png") as Texture2D
	grime_mat.albedo_color = Color(0.76, 0.78, 0.76, 0.58)
	grime_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	grime_mat.roughness = 0.98
	grime_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_decal_plane(self, Vector3(0.106, 1.55, 10.2), Vector2(1.0, 2.0), grime_mat, Vector3(0.0, 0.0, -PI * 0.5))
	_decal_plane(self, Vector3(27.894, 1.45, 11.5), Vector2(1.1, 2.0), grime_mat, Vector3(0.0, 0.0, PI * 0.5))
	_decal_plane(self, Vector3(-5.894, -2.75, 47.3), Vector2(1.4, 2.1), grime_mat, Vector3(0.0, 0.0, -PI * 0.5))


func _decal_plane(parent: Node, pos: Vector3, size: Vector2, material: Material,
		rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var plane_mesh := PlaneMesh.new()
	plane_mesh.size = size
	mi.mesh = plane_mesh
	mi.material_override = material
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _build_waypoints() -> void:
	waypoints = []
	var gap_x := [7.75, 13.25, 18.75, 24.5]
	# Ana market: raf aralıklarının tam ortasından geçen ızgara
	waypoints.append(Vector3(4, 0, 4))
	for z in [4.0, 7.5, 10.5, 13.2]:
		for x in gap_x:
			waypoints.append(Vector3(x, 0, z))
	waypoints.append(Vector3(1.4, 0, 7.5))
	waypoints.append(Vector3(1.4, 0, 10.5))
	waypoints.append(Vector3(26.6, 0, 3.5))
	waypoints.append(Vector3(26.6, 0, 10.5))
	waypoints.append(Vector3(20, 0, 13.2))
	# Güvenlik / ofis
	waypoints.append(Vector3(31, 0, 3.5))
	waypoints.append(Vector3(31, 0, 10.5))
	# Arka koridor (kapı eksenlerinde)
	for x in [1.5, 4.0, 10.5, 16.0, 20.0, 21.5, 26.0]:
		waypoints.append(Vector3(x, 0, 15.5))
	# Oda içleri
	for x in [4.0, 10.5, 16.0, 21.5, 26.0]:
		waypoints.append(Vector3(x, 0, 18.5))
		waypoints.append(Vector3(x, 0, 21.5))
	waypoints.append(Vector3(4, 0, 23.5))
	# Dış alan
	waypoints.append(Vector3(-1.5, 0, 15.5))
	waypoints.append(Vector3(-4, 0, 15.5))
	waypoints.append(Vector3(-4, 0, 6))
	waypoints.append(Vector3(-4, 0, -5))
	waypoints.append(Vector3(3, 0, -7))
	waypoints.append(Vector3(3, 0, -3.5))
	waypoints.append(Vector3(8, 0, -3.5))
	waypoints.append(Vector3(14, 0, -3.5))
	waypoints.append(Vector3(24, 0, -3.5))
	waypoints.append(Vector3(14, 0, -7))
	waypoints.append(Vector3(24, 0, -7))
	# Yeraltı
	waypoints.append(Vector3(4, -0.7, 27))
	waypoints.append(Vector3(4, -2.5, 32))
	waypoints.append(Vector3(4, -4.3, 37))
	waypoints.append(Vector3(4, -5, 41.5))
	waypoints.append(Vector3(4, -5, 47))
	waypoints.append(Vector3(-2, -5, 47))
	waypoints.append(Vector3(11, -5, 44))
	waypoints.append(Vector3(7, -5, 52))
	waypoints.append(Vector3(-2, -5, 52))
	waypoints.append(Vector3(4, -5, 52))


func _build_triggers() -> void:
	_trigger("security", Vector3(31, 1.0, 3.5), Vector3(4.5, 2.0, 5.0))
	_trigger("descend", Vector3(4, -4.0, 42), Vector3(3.0, 2.5, 3.0))
	_trigger("escape", Vector3(14, 1.0, -8), Vector3(16, 3.0, 10.0))
	_trigger("main_enter", Vector3(20, 1.0, 12.3), Vector3(2.4, 2.0, 1.4))
	_trigger("depo_enter", Vector3(4, 1.0, 21.5), Vector3(6.0, 2.0, 6.0))


func _trigger(id: String, pos: Vector3, size: Vector3) -> void:
	var a := Area3D.new()
	a.position = pos
	a.collision_layer = 0
	a.collision_mask = 16
	a.monitoring = true
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	a.add_child(cs)
	a.body_entered.connect(func(_b: Node3D) -> void: trigger_entered.emit(id))
	add_child(a)


# --------------------------------------------------------------------------
# Dünya durumu
# --------------------------------------------------------------------------

func set_power(on: bool) -> void:
	for l in lights:
		l.set_powered(on)
	_lamp_mat.emission_energy_multiplier = 2.0 if on else 0.0


func set_emergency(on: bool) -> void:
	for e in emergency_lights:
		e.light_energy = 0.7 if on else 0.0


func burst_lights(duration: float) -> void:
	for l in lights:
		l.burst(duration)


## Kesintiden sonra market "değişir": raflar kayar, ürünler düşer.
func apply_changes() -> void:
	if changes_applied:
		return
	changes_applied = true
	if shelves.size() > 9:
		shelves[1].rotation.y += 0.38
		shelves[5].position.z -= 1.2
		shelves[8].position.x += 1.4
		shelves[10].rotation.y -= 0.5
	var mat := Props.color_mat("fallen", Color(0.7, 0.2, 0.15), 0.7)
	var r := RandomNumberGenerator.new()
	r.seed = 99
	for i in 22:
		var p := Props.box(self, Vector3(r.randf_range(3, 25), 0.1, r.randf_range(4.5, 12.5)),
			Vector3(0.2, 0.2, 0.2), mat, 1, false)
		p.rotation = Vector3(r.randf() * 3.0, r.randf() * 3.0, r.randf() * 3.0)
		_fallen.append(p)
