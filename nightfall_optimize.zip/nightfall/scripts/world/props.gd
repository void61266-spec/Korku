class_name Props
extends RefCounted
## Prosedürel materyal ve prop üreticileri (harici asset gerektirmez).
## Collision katmanları: 1 = dünya, 2 = kapılar, 4 = etkileşim, 16 = oyuncu

static var _mats: Dictionary = {}
static var _package_cache: Texture2D
static var _shelf_scene: PackedScene

const PRODUCT_COLORS: Array[Color] = [
	Color(0.82, 0.78, 0.68), Color(0.67, 0.73, 0.61), Color(0.73, 0.57, 0.48),
	Color(0.62, 0.68, 0.73), Color(0.85, 0.82, 0.74), Color(0.67, 0.61, 0.48),
	Color(0.76, 0.69, 0.55), Color(0.65, 0.62, 0.67),
]


static func _make_tex(base: Color, amt: float, seed_: int, grid: int, grout: Color) -> ImageTexture:
	var size := 128
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var n := FastNoiseLite.new()
	n.seed = seed_
	n.frequency = 0.045
	var fine := FastNoiseLite.new()
	fine.seed = seed_ * 31 + 7
	fine.frequency = 0.22
	var stains := FastNoiseLite.new()
	stains.seed = seed_ * 13 + 91
	stains.frequency = 0.018
	for y in size:
		for x in size:
			var broad: float = n.get_noise_2d(x, y) * amt
			var detail: float = fine.get_noise_2d(x, y) * amt * 0.28
			var stain: float = maxf(0.0, stains.get_noise_2d(x, y) - 0.28) * amt * 0.8
			var v: float = broad + detail - stain
			var c := Color(clampf(base.r + v, 0.0, 1.0), clampf(base.g + v, 0.0, 1.0), clampf(base.b + v, 0.0, 1.0))
			if grid > 0:
				var cell: int = size / grid
				var edge_x: int = x % cell
				var edge_y: int = y % cell
				if edge_x < 2 or edge_y < 2:
					c = grout
				elif edge_x < 4 or edge_y < 4:
					c = c.darkened(0.10)
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


static func _make_normal(seed_: int) -> ImageTexture:
	var size := 128
	var height_img := Image.create(size, size, false, Image.FORMAT_RF)
	var n := FastNoiseLite.new()
	n.seed = seed_ * 17 + 3
	n.frequency = 0.13
	for y in size:
		for x in size:
			height_img.set_pixel(x, y, Color(0.5 + n.get_noise_2d(x, y) * 0.14, 0, 0))
	var normal_img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in size:
		for x in size:
			var left: float = height_img.get_pixel(maxi(0, x - 1), y).r
			var right: float = height_img.get_pixel(mini(size - 1, x + 1), y).r
			var up: float = height_img.get_pixel(x, maxi(0, y - 1)).r
			var down: float = height_img.get_pixel(x, mini(size - 1, y + 1)).r
			var normal := Vector3((left - right) * 3.0, (up - down) * 3.0, 1.0).normalized()
			normal_img.set_pixel(x, y, Color(normal.x * 0.5 + 0.5, normal.y * 0.5 + 0.5, normal.z * 0.5 + 0.5))
	normal_img.generate_mipmaps()
	return ImageTexture.create_from_image(normal_img)


static func _make_package_texture() -> Texture2D:
	if _package_cache != null:
		return _package_cache
	if ResourceLoader.exists("res://assets/textures/package.png"):
		_package_cache = load("res://assets/textures/package.png") as Texture2D
		return _package_cache
	var size := 128
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in size:
		for x in size:
			var c := Color(0.82, 0.79, 0.68)
			if y < 18 or y > 108:
				c = Color(0.12, 0.13, 0.14)
			elif y > 34 and y < 76:
				c = Color(0.68, 0.12, 0.08) if x < 64 else Color(0.08, 0.20, 0.24)
			elif y > 84 and x % 13 < 4:
				c = Color(0.12, 0.12, 0.11)
			if (x + y) % 17 == 0:
				c = c.darkened(0.06)
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	_package_cache = ImageTexture.create_from_image(img)
	return _package_cache


static func tex_mat(key: String, base: Color, amt: float = 0.06, seed_: int = 1, grid: int = 0,
		grout: Color = Color(0.05, 0.05, 0.05), tile: float = 0.5, rough: float = 0.9) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	var albedo_path := "res://assets/textures/%s.png" % key
	var normal_path := "res://assets/textures/%s_normal.png" % key
	if ResourceLoader.exists(albedo_path):
		m.albedo_texture = load(albedo_path) as Texture2D
	else:
		# Fallback for materials introduced by mods or new rooms.
		m.albedo_texture = _make_tex(base, amt, seed_, grid, grout)
	if ResourceLoader.exists(normal_path):
		m.normal_enabled = true
		m.normal_texture = load(normal_path) as Texture2D
		m.normal_scale = 0.32
	else:
		m.normal_enabled = true
		m.normal_texture = _make_normal(seed_)
		m.normal_scale = 0.22
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(tile, tile, tile)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	m.roughness = rough
	_mats[key] = m
	return m


static func color_mat(key: String, color: Color, rough: float = 0.8, emission: float = 0.0) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	_mats[key] = m
	return m


static func box(parent: Node, center: Vector3, size: Vector3, material: Material,
		layer: int = 1, collide: bool = true) -> Node3D:
	var bm := BoxMesh.new()
	bm.size = size
	if not collide:
		# Decorative geometry does not need an empty StaticBody in the physics server.
		# A plain MeshInstance saves many nodes and disables costly shadow casting on mobile.
		var visual := MeshInstance3D.new()
		visual.position = center
		visual.mesh = bm
		visual.material_override = material
		visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(visual)
		return visual
	var body := StaticBody3D.new()
	body.position = center
	body.collision_layer = layer
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = material
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	parent.add_child(body)
	return body


static func cylinder(parent: Node, center: Vector3, radius: float, height: float,
		material: Material, collide: bool = true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = center
	body.collision_layer = 1 if collide else 0
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 12
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = material
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = radius
		shape.height = height
		cs.shape = shape
		body.add_child(cs)
	parent.add_child(body)
	return body


## Çift taraflı market rafı. Uzunluk x ekseni boyunca; yaw ile döndürülür.
static func shelf(parent: Node, pos: Vector3, yaw: float, length: float, rng: RandomNumberGenerator,
		dynamic: bool = true) -> Node3D:
	var metal := color_mat("shelf_metal", Color(0.32, 0.34, 0.37), 0.5)
	var depth := 0.9
	var height := 2.0
	var levels := [0.12, 0.62, 1.12, 1.62, 1.98]
	var root := StaticBody3D.new()
	root.position = pos
	root.rotation.y = yaw
	root.collision_layer = 1
	root.collision_mask = 0
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(length, height, depth)
	cs.shape = shape
	cs.position.y = height * 0.5
	root.add_child(cs)

	# The shelf body is imported from a hand-authored, five-material GLB.  It has
	# folded steel shelves, upright posts, rivets and perforated back panels.
	# A primitive fallback remains for projects where the imported asset is absent.
	if _shelf_scene == null and ResourceLoader.exists("res://assets/models/supermarket_shelf.glb"):
		_shelf_scene = load("res://assets/models/supermarket_shelf.glb") as PackedScene
	if _shelf_scene != null:
		var detailed_rack := _shelf_scene.instantiate()
		detailed_rack.name = "DetailedMetalRack"
		root.add_child(detailed_rack)
		# LOD: yakında detaylı GLB (~11k üçgen), uzakta ucuz iskelet (~150 üçgen).
		for mi in detailed_rack.find_children("*", "MeshInstance3D", true, false):
			var gi := mi as MeshInstance3D
			gi.visibility_range_end = RACK_LOD_DIST
			gi.visibility_range_end_margin = 1.5
			gi.add_to_group(&"rack_high")
		var low := MeshInstance3D.new()
		low.name = "LowRack"
		low.mesh = _low_rack_mesh(length, depth, height, levels)
		low.material_override = metal
		low.visibility_range_begin = RACK_LOD_DIST
		low.visibility_range_begin_margin = 1.5
		low.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		low.add_to_group(&"rack_low")
		root.add_child(low)
	else:
		# Raf iskeleti: tekrar eden parçalar MultiMesh ile gruplanır; mobilde draw-call sayısı düşer.
		var back := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(length, height, 0.04)
		back.mesh = bm
		back.material_override = metal
		back.position.y = height * 0.5
		back.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(back)
		var plank_multi := MultiMesh.new()
		plank_multi.transform_format = MultiMesh.TRANSFORM_3D
		var plank_mesh := BoxMesh.new()
		plank_mesh.size = Vector3(length, 0.04, depth)
		plank_multi.mesh = plank_mesh
		plank_multi.instance_count = levels.size()
		for i in levels.size():
			plank_multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(0.0, float(levels[i]), 0.0)))
		var planks := MultiMeshInstance3D.new()
		planks.multimesh = plank_multi
		planks.material_override = metal
		planks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(planks)
		var supports_multi := MultiMesh.new()
		supports_multi.transform_format = MultiMesh.TRANSFORM_3D
		var support_mesh := BoxMesh.new()
		support_mesh.size = Vector3(0.055, height, 0.075)
		supports_multi.mesh = support_mesh
		var support_positions: Array[Vector3] = []
		for px in [-length * 0.5 + 0.035, 0.0, length * 0.5 - 0.035]:
			for pz in [-depth * 0.5 + 0.025, depth * 0.5 - 0.025]:
				support_positions.append(Vector3(px, height * 0.5, pz))
		supports_multi.instance_count = support_positions.size()
		for i in support_positions.size():
			supports_multi.set_instance_transform(i, Transform3D(Basis.IDENTITY, support_positions[i]))
		var supports := MultiMeshInstance3D.new()
		supports.multimesh = supports_multi
		supports.material_override = metal
		supports.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(supports)

	# Ürünler: tüm raflar aynı mesh/materyali paylaşır. Hareket etmeyen raflar bölge başına
	# tek MultiMesh'e birleşir (flush_products); hareketli raflar kendi MultiMesh'ini taşır.
	var per_row: int = int(length / 0.26)
	var box_xf: Array[Transform3D] = []
	var box_col: Array[Color] = []
	var can_xf: Array[Transform3D] = []
	var can_col: Array[Color] = []
	var global_idx := 0
	for li in 4:
		var base_y: float = float(levels[li]) + 0.02 + 0.15
		for side in [-1, 1]:
			for i in per_row:
				var x: float = -length * 0.5 + 0.18 + i * 0.26
				var is_can := global_idx % 4 == 0
				var scale_box := Vector3(rng.randf_range(0.8, 1.15), rng.randf_range(0.7, 1.2), rng.randf_range(0.8, 1.1))
				var p := Vector3(x, base_y, float(side) * 0.22)
				var product_color := PRODUCT_COLORS[rng.randi() % PRODUCT_COLORS.size()]
				if is_can:
					can_xf.append(Transform3D(Basis.from_scale(Vector3(rng.randf_range(0.9, 1.08), rng.randf_range(0.85, 1.15), 1.0)), p))
					can_col.append(product_color)
				else:
					box_xf.append(Transform3D(Basis.from_scale(scale_box), p))
					box_col.append(product_color)
				global_idx += 1
	var price_xf: Array[Transform3D] = []
	for li in 4:
		for side in [-1.0, 1.0]:
			price_xf.append(Transform3D(Basis.from_scale(Vector3(length, 1.0, 1.0)),
				Vector3(0.0, float(levels[li]) + 0.055, side * (depth * 0.5 + 0.015))))
	if dynamic:
		_spawn_multimesh(root, "Products", "box", box_xf, box_col)
		_spawn_multimesh(root, "Cans", "can", can_xf, can_col)
		_spawn_multimesh(root, "Prices", "price", price_xf, [])
	else:
		var to_world := Transform3D(Basis(Vector3.UP, yaw), pos)
		var zone := Vector2i(floori(pos.x / PRODUCT_ZONE), floori(pos.z / PRODUCT_ZONE))
		_accumulate("box", zone, to_world, box_xf, box_col)
		_accumulate("can", zone, to_world, can_xf, can_col)
		_accumulate("price", zone, to_world, price_xf, [])

	parent.add_child(root)
	return root


static func make_label3d(text: String, pos: Vector3, size: float, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.pixel_size = size
	l.modulate = color
	l.outline_size = 5
	l.outline_modulate = Color(0.015, 0.018, 0.02, 0.96)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.no_depth_test = false
	return l


# --------------------------------------------------------------------------
# Paylaşılan ürün kaynakları ve toplu MultiMesh biriktirici
# --------------------------------------------------------------------------

const PRODUCT_ZONE := 10.0
const RACK_LOD_DIST := 12.0
static var _shared_meshes: Dictionary = {}
static var _shared_mats: Dictionary = {}
static var _acc: Dictionary = {}


static func _kind_mesh(kind: String) -> Mesh:
	if _shared_meshes.has(kind):
		return _shared_meshes[kind]
	var m: Mesh
	if kind == "box":
		var bm := BoxMesh.new()
		bm.size = Vector3(0.2, 0.3, 0.2)
		m = bm
	elif kind == "can":
		var cm := CylinderMesh.new()
		cm.top_radius = 0.085
		cm.bottom_radius = 0.085
		cm.height = 0.28
		cm.radial_segments = 8
		cm.rings = 1
		m = cm
	else:
		var pm := BoxMesh.new()
		pm.size = Vector3(1.0, 0.055, 0.025)
		m = pm
	_shared_meshes[kind] = m
	return m


static func _kind_material(kind: String) -> Material:
	if _shared_mats.has(kind):
		return _shared_mats[kind]
	var mat: StandardMaterial3D
	if kind == "box":
		mat = StandardMaterial3D.new()
		mat.albedo_texture = _make_package_texture()
		mat.vertex_color_use_as_albedo = true
		mat.roughness = 0.82
		mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	elif kind == "can":
		mat = StandardMaterial3D.new()
		mat.albedo_texture = load("res://assets/textures/can_label.png") as Texture2D
		mat.vertex_color_use_as_albedo = true
		mat.roughness = 0.56
		mat.metallic = 0.18
		mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	else:
		mat = color_mat("price_strip", Color(0.68, 0.66, 0.59), 0.88)
	_shared_mats[kind] = mat
	return mat


static func _make_multimesh(kind: String, xfs: Array, cols: Array) -> MultiMesh:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = not cols.is_empty()
	mm.mesh = _kind_mesh(kind)
	mm.instance_count = xfs.size()
	for i in xfs.size():
		mm.set_instance_transform(i, xfs[i])
		if mm.use_colors:
			mm.set_instance_color(i, cols[i])
	return mm


static func _spawn_multimesh(parent: Node3D, node_name: String, kind: String, xfs: Array, cols: Array) -> void:
	if xfs.is_empty():
		return
	var mmi := MultiMeshInstance3D.new()
	mmi.name = node_name
	mmi.multimesh = _make_multimesh(kind, xfs, cols)
	mmi.material_override = _kind_material(kind)
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.add_to_group(&"product_mm")
	parent.add_child(mmi)


static func _accumulate(kind: String, zone: Vector2i, to_world: Transform3D, xfs: Array, cols: Array) -> void:
	var key := "%s_%d_%d" % [kind, zone.x, zone.y]
	if not _acc.has(key):
		_acc[key] = {"kind": kind, "xf": [], "col": []}
	var entry: Dictionary = _acc[key]
	for i in xfs.size():
		entry.xf.append(to_world * xfs[i])
	if not cols.is_empty():
		entry.col.append_array(cols)


## Biriken statik raf ürünlerini bölge başına tek MultiMeshInstance3D olarak oluşturur.
static func flush_products(parent: Node3D) -> int:
	var made := 0
	for key in _acc:
		var e: Dictionary = _acc[key]
		_spawn_multimesh(parent, "Batch_" + String(key), String(e.kind), e.xf, e.col)
		made += 1
	_acc.clear()
	return made


static var _low_rack_cache: Dictionary = {}


## Raf iskeletinin düşük detaylı hâli: arka panel + 5 tabla + 6 direk, tek mesh.
static func _low_rack_mesh(length: float, depth: float, height: float, levels: Array) -> Mesh:
	var key := "%.2f" % length
	if _low_rack_cache.has(key):
		return _low_rack_cache[key]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var parts: Array = [[Vector3(length, height, 0.04), Vector3(0, height * 0.5, -depth * 0.5 + 0.02)]]
	for ly in levels:
		parts.append([Vector3(length, 0.04, depth), Vector3(0, float(ly), 0)])
	for px in [-length * 0.5 + 0.035, 0.0, length * 0.5 - 0.035]:
		for pz in [-depth * 0.5 + 0.025, depth * 0.5 - 0.025]:
			parts.append([Vector3(0.055, height, 0.075), Vector3(px, height * 0.5, pz)])
	for part in parts:
		var bm := BoxMesh.new()
		bm.size = part[0]
		st.append_from(bm, 0, Transform3D(Basis.IDENTITY, part[1]))
	var m := st.commit()
	_low_rack_cache[key] = m
	return m
