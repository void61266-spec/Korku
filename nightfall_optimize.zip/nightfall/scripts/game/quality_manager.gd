class_name QualityManager
extends Node
## Grafik kalite ön ayarları (Düşük / Orta / Yüksek) ve ışık bütçesi.
## Mobilde pahalı olan her şey buradan ayarlanır: çizim mesafesi, LOD mesafeleri,
## aktif dinamik ışık sayısı, MSAA, gölge, glow.

const PROFILES: Array[Dictionary] = [
	# Düşük: düşük/orta Android için
	{"name": "Düşük", "far": 32.0, "detail_vr": 14.0, "rack_vr": 8.0, "product_vr": 18.0,
		"max_lights": 5, "msaa": 0, "flash_shadow": false, "glow": false, "fog_density": 0.02},
	# Orta: varsayılan mobil
	{"name": "Orta", "far": 45.0, "detail_vr": 22.0, "rack_vr": 12.0, "product_vr": 26.0,
		"max_lights": 8, "msaa": 0, "flash_shadow": false, "glow": false, "fog_density": 0.014},
	# Yüksek: PC / güçlü cihazlar
	{"name": "Yüksek", "far": 60.0, "detail_vr": 38.0, "rack_vr": 18.0, "product_vr": 45.0,
		"max_lights": 14, "msaa": 2, "flash_shadow": true, "glow": true, "fog_density": 0.014},
]

var player: Player
var world_env: Environment
var applied := -1
var current: Dictionary = {}
var _timer := 0.0
var _lights: Array = []
var _light_count := -1


func setup(p_player: Player, env: Environment) -> void:
	player = p_player
	world_env = env
	apply(true)


func apply(force: bool = false) -> void:
	var q := clampi(Settings.graphics_quality, 0, PROFILES.size() - 1)
	if q == applied and not force:
		return
	applied = q
	current = PROFILES[q]
	if player != null:
		player.camera.far = float(current.far)
		player.apply_graphics_quality()
	if world_env != null:
		world_env.fog_enabled = true
		world_env.fog_density = float(current.fog_density)
		world_env.glow_enabled = bool(current.glow)
	if is_inside_tree():
		var msaa := Viewport.MSAA_DISABLED
		if int(current.msaa) == 2:
			msaa = Viewport.MSAA_2X if OS.has_feature("mobile") else Viewport.MSAA_4X
		get_viewport().msaa_3d = msaa
	_apply_ranges()
	_light_count = -1
	_timer = 0.0


func _apply_ranges() -> void:
	var tree := get_tree()
	if tree == null:
		return
	for n in tree.get_nodes_in_group(StaticBatcher.DETAIL_GROUP):
		(n as GeometryInstance3D).visibility_range_end = float(current.detail_vr)
		(n as GeometryInstance3D).visibility_range_end_margin = 2.0
	for n in tree.get_nodes_in_group(&"rack_high"):
		(n as GeometryInstance3D).visibility_range_end = float(current.rack_vr)
	for n in tree.get_nodes_in_group(&"rack_low"):
		(n as GeometryInstance3D).visibility_range_begin = float(current.rack_vr)
	for n in tree.get_nodes_in_group(&"product_mm"):
		(n as GeometryInstance3D).visibility_range_end = float(current.product_vr)
		(n as GeometryInstance3D).visibility_range_end_margin = 2.0


func _process(delta: float) -> void:
	_timer -= delta
	if _timer > 0.0 or player == null:
		return
	_timer = 0.25
	_budget_lights()


## En yakın N ışığı açık tutar; menzili dışındakileri ve bütçe aşanları kapatır.
func _budget_lights() -> void:
	var tree := get_tree()
	var group := tree.get_nodes_in_group(&"store_lights")
	if group.size() != _light_count:
		_light_count = group.size()
		_lights = group
	var pos := player.global_position + Vector3(0, 1.5, 0)
	var scored: Array = []
	for l in _lights:
		var fl := l as FlickerLight
		if fl == null or not fl.powered:
			continue
		var d := pos.distance_to(fl.global_position)
		if d > fl.omni_range + 6.0:
			fl.set_culled(true)
		else:
			scored.append([d, fl])
	scored.sort_custom(func(a: Array, b: Array) -> bool: return a[0] < b[0])
	var budget: int = int(current.max_lights)
	for i in scored.size():
		(scored[i][1] as FlickerLight).set_culled(i >= budget)
