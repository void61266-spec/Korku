class_name Player
extends CharacterBody3D
## Birinci şahıs oyuncu: hareket, bakış, fener, etkileşim, saklanma.

signal message(text: String)
signal noise(pos: Vector3, radius: float)
signal prompt_changed(text: String)
signal hide_changed(hiding: bool)
signal battery_changed(value: float)
signal stamina_changed(value: float)
signal interacted_with(target: Node)

const WALK_SPEED := 3.0
const SPRINT_SPEED := 5.2
const CROUCH_SPEED := 1.6
const GRAVITY := 18.0
const STAND_HEIGHT := 1.7
const CROUCH_HEIGHT := 1.1
const EYE_STAND := 1.6
const EYE_CROUCH := 1.0
const INTERACT_RANGE := 2.7

var inventory := Inventory.new()
var move_input := Vector2.ZERO
var sprint_held := false
var crouching := false
var frozen := false
var dead := false
var stamina := 100.0
var battery := 100.0
var flashlight_on := false
var hiding_in: HidingSpot = null

var camera: Camera3D
var _head: Node3D
var _flash: SpotLight3D
var _shape: CollisionShape3D
var _capsule: CapsuleShape3D
var _pitch := 0.0
var _look_accum := Vector2.ZERO
var _step_dist := 0.0
var _bob_t := 0.0
var _exhausted := false
var _target: Interactable = null
var _ray_timer := 0.0
var _last_prompt := ""
var _flash_flicker := 0.0
var _flick_mul := 1.0
var _battery_msg_20 := false
var _battery_msg_0 := false
var _hide_return := Vector3.ZERO


func _ready() -> void:
	collision_layer = 16
	collision_mask = 1 | 2
	floor_snap_length = 0.4
	_capsule = CapsuleShape3D.new()
	_capsule.radius = 0.35
	_capsule.height = STAND_HEIGHT
	_shape = CollisionShape3D.new()
	_shape.shape = _capsule
	_shape.position.y = STAND_HEIGHT * 0.5
	add_child(_shape)

	_head = Node3D.new()
	_head.position.y = EYE_STAND
	add_child(_head)
	camera = Camera3D.new()
	camera.fov = 75.0
	camera.near = 0.05
	camera.far = 60.0
	_head.add_child(camera)
	camera.current = true

	_flash = SpotLight3D.new()
	_flash.spot_range = 20.0
	_flash.spot_angle = 34.0
	_flash.spot_angle_attenuation = 0.6
	_flash.light_energy = 0.0
	_flash.light_color = Color(1.0, 0.95, 0.8)
	_flash.visible = false
	_flash.shadow_enabled = Settings.graphics_quality >= 2
	_head.add_child(_flash)

	if DisplayServer.is_touchscreen_available():
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func add_look(delta_px: Vector2) -> void:
	_look_accum += delta_px


func _unhandled_input(event: InputEvent) -> void:
	if frozen or dead:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		add_look((event as InputEventMouseMotion).relative * 1.2)
	if event.is_action_pressed("interact"):
		interact()
	elif event.is_action_pressed("flashlight"):
		toggle_flashlight()
	elif event.is_action_pressed("crouch"):
		toggle_crouch()


func _physics_process(delta: float) -> void:
	_apply_look(delta)
	if dead:
		return
	if hiding_in != null or frozen:
		velocity = Vector3.ZERO
		_update_flashlight(delta)
		return

	var kb := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var inp := move_input if move_input.length() > 0.05 else kb
	var wants_sprint := (sprint_held or Input.is_action_pressed("sprint")) and inp.length() > 0.2 and not crouching
	if _exhausted and stamina > 30.0:
		_exhausted = false
	var sprinting := wants_sprint and not _exhausted and stamina > 0.0
	if sprinting:
		stamina = maxf(0.0, stamina - 22.0 * delta)
		if stamina <= 0.0:
			_exhausted = true
	else:
		stamina = minf(100.0, stamina + 14.0 * delta)
	stamina_changed.emit(stamina)

	var speed := CROUCH_SPEED if crouching else (SPRINT_SPEED if sprinting else WALK_SPEED)
	var dir := (global_transform.basis * Vector3(inp.x, 0.0, inp.y))
	dir.y = 0.0
	if dir.length() > 1.0:
		dir = dir.normalized()
	var target := dir * speed
	var accel := 14.0 if inp.length() > 0.05 else 18.0
	velocity.x = move_toward(velocity.x, target.x, accel * delta)
	velocity.z = move_toward(velocity.z, target.z, accel * delta)
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	var hspeed := Vector2(velocity.x, velocity.z).length()
	_footsteps(hspeed, sprinting, delta)
	_update_crouch(delta)
	_update_bob(hspeed, delta)
	_update_flashlight(delta)

	_ray_timer -= delta
	if _ray_timer <= 0.0:
		_ray_timer = 0.08
		_update_target()


func _apply_look(delta: float) -> void:
	if _look_accum.length_squared() < 0.0001:
		return
	var k := 1.0 - exp(-delta * 28.0)
	var step := _look_accum * k
	_look_accum -= step
	var sens := 0.0032 * Settings.sensitivity
	rotation.y -= step.x * sens
	_pitch = clampf(_pitch - step.y * sens, -1.45, 1.45)
	_head.rotation.x = _pitch


func _footsteps(hspeed: float, sprinting: bool, delta: float) -> void:
	if hspeed < 0.6 or not is_on_floor():
		return
	_step_dist += hspeed * delta
	var stride := 1.5 if sprinting else (2.6 if crouching else 2.0)
	if _step_dist >= stride:
		_step_dist = 0.0
		var vol := -2.0 if sprinting else (-12.0 if crouching else -6.0)
		AudioManager.play(&"step", vol, randf_range(0.85, 1.1))
		var radius := 14.0 if sprinting else (2.5 if crouching else 7.0)
		noise.emit(global_position, radius)


func _update_crouch(delta: float) -> void:
	var th := CROUCH_HEIGHT if crouching else STAND_HEIGHT
	_capsule.height = lerpf(_capsule.height, th, minf(1.0, delta * 10.0))
	_shape.position.y = _capsule.height * 0.5


func _update_bob(hspeed: float, delta: float) -> void:
	var eye := EYE_CROUCH if crouching else EYE_STAND
	var bob := 0.0
	if hspeed > 0.6:
		_bob_t += delta * hspeed * 2.6
		bob = sin(_bob_t) * 0.035
	_head.position.y = lerpf(_head.position.y, eye + bob, minf(1.0, delta * 12.0))


func toggle_crouch() -> void:
	if hiding_in != null or frozen:
		return
	crouching = not crouching


func toggle_flashlight() -> void:
	if frozen or dead:
		return
	if not flashlight_on and battery <= 0.0:
		message.emit("Fenerin pili bitmiş.")
		AudioManager.play(&"locked", -6.0)
		return
	flashlight_on = not flashlight_on
	AudioManager.play(&"click", -4.0, 0.8)
	_flash.visible = flashlight_on


func add_battery(amount: float) -> void:
	battery = minf(100.0, battery + amount)
	_battery_msg_20 = false
	_battery_msg_0 = false
	battery_changed.emit(battery)


func use_battery_item() -> bool:
	if battery >= 99.0:
		message.emit("Fener zaten dolu.")
		return false
	if inventory.remove("pil", 1):
		add_battery(60.0)
		AudioManager.play(&"pickup", -4.0, 0.7)
		message.emit("Fenerin pili değiştirildi.")
		return true
	return false


func _update_flashlight(delta: float) -> void:
	# Fener hafif gecikmeyle kamerayı takip eder (daha doğal his).
	var cam_q := camera.global_transform.basis.get_rotation_quaternion()
	var fl_q := _flash.global_transform.basis.get_rotation_quaternion()
	var blended := fl_q.slerp(cam_q, minf(1.0, delta * 14.0))
	_flash.global_transform = Transform3D(Basis(blended), camera.global_position)

	if not flashlight_on:
		return
	battery = maxf(0.0, battery - 0.30 * delta)
	battery_changed.emit(battery)
	if battery <= 20.0 and not _battery_msg_20:
		_battery_msg_20 = true
		message.emit("Fenerin pili azalıyor...")
	var e := 2.6 * clampf(battery / 35.0, 0.18, 1.0)
	if battery < 12.0:
		_flash_flicker -= delta
		if _flash_flicker <= 0.0:
			_flash_flicker = randf_range(0.05, 0.4)
			_flick_mul = 0.15 if randf() < 0.5 else 1.0
		e *= _flick_mul
	_flash.light_energy = e
	_flash.spot_range = lerpf(7.0, 20.0, clampf(battery / 50.0, 0.0, 1.0))
	if battery <= 0.0:
		flashlight_on = false
		_flash.visible = false
		if not _battery_msg_0:
			_battery_msg_0 = true
			message.emit("Fener söndü!")


func _update_target() -> void:
	var from := camera.global_position
	var to := from + (-camera.global_transform.basis.z) * INTERACT_RANGE
	var q := PhysicsRayQueryParameters3D.create(from, to, 4)
	q.collide_with_areas = false
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var t: Interactable = null
	if not hit.is_empty() and hit.collider is Interactable:
		t = hit.collider
		if not t.enabled:
			t = null
	_target = t
	var txt := ""
	if hiding_in != null:
		txt = "Saklanmaktan çık"
	elif t != null:
		txt = t.get_prompt()
	if txt != _last_prompt:
		_last_prompt = txt
		prompt_changed.emit(txt)


func interact() -> void:
	if frozen or dead:
		return
	if hiding_in != null:
		exit_hide()
		return
	if _target != null:
		AudioManager.play(&"click", -8.0)
		Settings.vibrate(15)
		interacted_with.emit(_target)
		_target.interact(self)


func enter_hide(spot: HidingSpot) -> void:
	hiding_in = spot
	_hide_return = global_position
	global_position = spot.hide_position
	rotation.y = spot.look_yaw
	_pitch = 0.0
	_head.rotation.x = 0.0
	velocity = Vector3.ZERO
	_shape.disabled = true
	crouching = false
	_head.position.y = EYE_CROUCH
	if flashlight_on:
		toggle_flashlight()
	_last_prompt = "Saklanmaktan çık"
	prompt_changed.emit(_last_prompt)
	hide_changed.emit(true)


func exit_hide() -> void:
	if hiding_in == null:
		return
	var spot := hiding_in
	hiding_in = null
	global_position = spot.exit_position if spot.exit_position != Vector3.ZERO else _hide_return
	_shape.disabled = false
	_last_prompt = ""
	prompt_changed.emit("")
	hide_changed.emit(false)


func head_position() -> Vector3:
	return _head.global_position


func is_hidden() -> bool:
	return hiding_in != null


func die() -> void:
	dead = true
	frozen = true
	velocity = Vector3.ZERO
	if hiding_in != null:
		_shape.disabled = false
		hiding_in = null
		hide_changed.emit(false)


func to_dict() -> Dictionary:
	return {
		"pos": [global_position.x, global_position.y, global_position.z],
		"yaw": rotation.y,
		"battery": battery,
		"inventory": inventory.to_dict(),
	}


func from_dict(d: Dictionary) -> void:
	var p: Array = d.get("pos", [])
	if p.size() == 3:
		global_position = Vector3(float(p[0]), float(p[1]) + 0.1, float(p[2]))
	rotation.y = float(d.get("yaw", 0.0))
	battery = float(d.get("battery", 100.0))
	inventory.from_dict(d.get("inventory", {}))
	battery_changed.emit(battery)
