class_name MissionSystem
extends RefCounted
## Doğrusal görev zinciri. Her adım `need` kadar olay bekler.

signal step_started(index: int)
signal step_completed(step_id: String)
signal progress_changed
signal all_completed

const STEPS: Array[Dictionary] = [
	{"id": "shelves", "text": "Rafları kontrol et", "need": 3},
	{"id": "register", "text": "Kasayı kontrol et", "need": 1},
	{"id": "frontdoor", "text": "Mağazanın ön kapısını kontrol et", "need": 1},
	{"id": "key", "text": "Personel odasından elektrik odası anahtarını bul", "need": 1},
	{"id": "depo", "text": "Depoyu kontrol et", "need": 1},
	{"id": "power_check", "text": "Elektrik sistemini kontrol et", "need": 1},
	{"id": "fuse_find", "text": "Karanlıkta depodaki sigortayı bul", "need": 1},
	{"id": "fuse_place", "text": "Sigortayı elektrik odasındaki sigorta kutusuna tak", "need": 1},
	{"id": "generator", "text": "Jeneratörü çalıştır", "need": 1},
	{"id": "security", "text": "Güvenlik odasına git", "need": 1},
	{"id": "cameras", "text": "Güvenlik kameralarını incele", "need": 3},
	{"id": "hidden", "text": "Depoda gizli geçidi bul", "need": 1},
	{"id": "descend", "text": "Yeraltına in", "need": 1},
	{"id": "keycard", "text": "Laboratuvarda erişim kartını bul", "need": 1},
	{"id": "terminal", "text": "Laboratuvar terminalini kullan", "need": 1},
	{"id": "cell", "text": "Soğuk hava deposundan Kaynak Hücresini al", "need": 1},
	{"id": "reactor", "text": "Hücreyi laboratuvardaki reaktöre yerleştir", "need": 1},
	{"id": "escape", "text": "Otoparka kaç!", "need": 1},
]

var index: int = 0
var progress: int = 0
var finished: bool = false


func current_id() -> String:
	if finished or index >= STEPS.size():
		return ""
	return String(STEPS[index].id)


func index_of(step_id: String) -> int:
	for i in STEPS.size():
		if STEPS[i].id == step_id:
			return i
	return -1


## Verilen adıma ulaşıldı mı (şu an o adımda veya sonrasında)?
func reached(step_id: String) -> bool:
	if finished:
		return true
	return index >= index_of(step_id)


## Verilen adım tamamen bitti mi?
func done(step_id: String) -> bool:
	if finished:
		return true
	return index > index_of(step_id)


func text() -> String:
	if finished:
		return ""
	var s: Dictionary = STEPS[index]
	var t: String = String(s.text)
	if int(s.need) > 1:
		t += " (%d/%d)" % [progress, int(s.need)]
	return t


func start() -> void:
	step_started.emit(index)
	progress_changed.emit()


## Olayı bildirir; mevcut adımsa ilerletir. Ilerleme olduysa true döner.
func event(step_id: String) -> bool:
	if finished or current_id() != step_id:
		return false
	progress += 1
	if progress >= int(STEPS[index].need):
		var done_id := step_id
		index += 1
		progress = 0
		step_completed.emit(done_id)
		if index >= STEPS.size():
			finished = true
			all_completed.emit()
		else:
			step_started.emit(index)
	progress_changed.emit()
	return true


func to_dict() -> Dictionary:
	return {"index": index, "progress": progress, "finished": finished}


func from_dict(d: Dictionary) -> void:
	index = clampi(int(d.get("index", 0)), 0, STEPS.size() - 1)
	progress = int(d.get("progress", 0))
	finished = bool(d.get("finished", false))
