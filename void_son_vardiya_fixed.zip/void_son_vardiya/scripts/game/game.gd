extends Node3D
## Oyun yönetmeni: dünyayı kurar, hikâye olaylarını, saati, korku atmosferini ve kayıt sistemini yürütür.

const ITEM_EVENTS := {
	"personel_anahtari": "key",
	"sigorta": "fuse_find",
	"erisim_karti": "keycard",
	"kaynak_hucresi": "cell",
}

var market: MarketBuilder
var player: Player
var creature: Creature
var mission := MissionSystem.new()
var hud: HUD
var touch: TouchControls
var inv_ui: InventoryUI
var note_ui: NotePanel
var cam_view: CameraView
var overlay: OverlayScreen

var clock_min := 23.0 * 60.0 + 35.0
var play_time := 0.0
var used_points: Array = []
var collected: Array = []
var viewed_cams: Array = []
var slammed := false
var hinted_depo := false
var game_over := false
var ambient_t := 60.0
var heart_t := 0.0
var shake_t := 0.0
var shake_amp := 0.0
var _pause_overlay: OverlayScreen
var _ready_done := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	_build_environment()
	market = MarketBuilder.new()
	add_child(market)
	market.build()

	player = Player.new()
	add_child(player)
	player.global_position = market.player_spawn
	player.rotation.y = PI

	creature = Creature.new()
	creature.player = player
	creature.builder = market
	add_child(creature)

	_build_ui()
	_connect_signals()

	var restored := false
	if GameManager.continue_save:
		restored = _load_game()
	if not restored:
		hud.toast("Gece vardiyası başladı. Görevlerini yap.", 4.0)
	mission.start()
	_apply_world_state()
	_refresh_hud()
	AudioManager.start_ambient()

	await get_tree().physics_frame
	await get_tree().physics_frame
	creature.build_graph()
	if mission.done("cameras"):
		creature.activate(_far_waypoint())
	_ready_done = true


func _build_environment() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0, 0, 0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.09, 0.1, 0.13)
	env.ambient_light_energy = 0.55
	env.fog_enabled = Settings.graphics_quality >= 1
	env.fog_light_color = Color(0.05, 0.055, 0.06)
	env.fog_density = 0.03
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	add_child(we)
	get_viewport().msaa_3d = Viewport.MSAA_2X if Settings.graphics_quality >= 2 else Viewport.MSAA_DISABLED


func _build_ui() -> void:
	hud = HUD.new()
	add_child(hud)
	var tl := CanvasLayer.new()
	tl.layer = 12
	add_child(tl)
	touch = TouchControls.new()
	tl.add_child(touch)
	touch.visible = DisplayServer.is_touchscreen_available() or OS.has_feature("android") or OS.has_feature("ios") \
		or OS.get_environment("VOID_TOUCH") == "1"
	inv_ui = InventoryUI.new()
	add_child(inv_ui)
	note_ui = NotePanel.new()
	add_child(note_ui)
	cam_view = CameraView.new()
	add_child(cam_view)


func _connect_signals() -> void:
	touch.look_delta.connect(player.add_look)
	touch.interact_pressed.connect(player.interact)
	touch.flashlight_pressed.connect(player.toggle_flashlight)
	touch.crouch_pressed.connect(player.toggle_crouch)
	touch.inventory_pressed.connect(open_inventory)
	touch.pause_pressed.connect(open_pause)

	player.message.connect(func(t: String) -> void: hud.toast(t))
	player.prompt_changed.connect(hud.set_prompt)
	player.battery_changed.connect(hud.set_battery)
	player.stamina_changed.connect(hud.set_stamina)
	player.noise.connect(creature.hear)
	player.hide_changed.connect(func(h: bool) -> void:
		hud.set_hiding(h)
		creature.on_player_hide_changed(h))
	creature.caught.connect(_on_caught)
	market.trigger_entered.connect(_on_trigger)
	for id in market.points:
		(market.points[id] as InteractPoint).activated.connect(_on_point)
	for p in market.pickups:
		p.collected.connect(_on_pickup)
	(market.doors["hidden"] as Door).opened_changed.connect(_on_hidden_door)
	mission.step_started.connect(_on_step_started)
	mission.step_completed.connect(_on_step_completed)
	mission.progress_changed.connect(_refresh_hud)
	mission.all_completed.connect(_on_ending)
	player.inventory.changed.connect(inv_ui.refresh)
	inv_ui.closed.connect(_resume_from_ui)
	inv_ui.read_requested.connect(_read_inventory_note)
	inv_ui.battery_requested.connect(func() -> void: player.use_battery_item())
	note_ui.closed.connect(_resume_from_ui)
	cam_view.cam_viewed.connect(_on_cam_viewed)
	cam_view.closed.connect(_on_cam_closed)
	GameManager.save_requested.connect(_save)


# --------------------------------------------------------------------------
# Döngü
# --------------------------------------------------------------------------

func _process(delta: float) -> void:
	player.move_input = touch.move_vector
	player.sprint_held = touch.sprint_held
	touch.set_toggle_state(player.crouching, player.flashlight_on)
	if game_over:
		return
	play_time += delta
	_tick_clock(delta)
	_tick_fear(delta)
	_tick_ambient_events(delta)
	_tick_shake(delta)


func _tick_clock(delta: float) -> void:
	if not mission.done("power_check"):
		clock_min = minf(clock_min + delta / 5.0, 23.0 * 60.0 + 59.0)
	else:
		clock_min += delta / 14.0
	var m := int(clock_min) % 1440
	hud.set_clock("%02d:%02d" % [m / 60, m % 60])


func _tick_fear(delta: float) -> void:
	var d := creature.distance_to_player()
	var fear := 0.0
	if creature.is_visible_now() and creature.active:
		fear = clampf(1.0 - d / 18.0, 0.0, 1.0)
		if creature.state == Creature.State.CHASE:
			fear = maxf(fear, 0.85)
	hud.set_fear(fear)
	if fear > 0.15:
		heart_t -= delta
		if heart_t <= 0.0:
			heart_t = lerpf(1.2, 0.4, fear)
			AudioManager.play(&"thump", lerpf(-14.0, 2.0, fear), 1.0)
			get_tree().create_timer(0.18).timeout.connect(func() -> void:
				AudioManager.play(&"thump", lerpf(-16.0, 0.0, fear), 0.85))
			if fear > 0.6:
				Settings.vibrate(30)


func _tick_ambient_events(delta: float) -> void:
	if play_time < 90.0 or creature.is_visible_now():
		return
	ambient_t -= delta
	if ambient_t > 0.0:
		return
	ambient_t = randf_range(28.0, 60.0)
	var roll := randi() % 5
	match roll:
		0:
			AudioManager.play(&"clang", -14.0, randf_range(0.7, 1.2))
		1:
			for i in 4:
				get_tree().create_timer(0.45 * i).timeout.connect(func() -> void:
					AudioManager.play(&"step", -10.0, randf_range(0.6, 0.75)))
		2:
			if mission.done("generator") or not mission.reached("fuse_find"):
				market.burst_lights(randf_range(0.5, 1.2))
		3:
			AudioManager.play(&"door", -12.0, 0.6)
		4:
			AudioManager.play(&"thump", -8.0, 0.6)


func _tick_shake(delta: float) -> void:
	if shake_t > 0.0:
		shake_t -= delta
		var a := shake_amp * clampf(shake_t, 0.0, 1.0)
		player.camera.h_offset = randf_range(-a, a)
		player.camera.v_offset = randf_range(-a, a)
	elif player.camera.h_offset != 0.0:
		player.camera.h_offset = 0.0
		player.camera.v_offset = 0.0


func shake(amp: float, dur: float) -> void:
	shake_amp = amp
	shake_t = dur


func jumpscare(strength: float = 1.0) -> void:
	AudioManager.play(&"scare", 2.0)
	hud.flash(Color(0.8, 0.0, 0.0, 0.6 * strength), 0.7)
	shake(0.08 * strength, 1.0)
	Settings.vibrate(int(250 * strength))


# --------------------------------------------------------------------------
# Etkileşimler
# --------------------------------------------------------------------------

func _on_point(p: InteractPoint) -> void:
	var cur := mission.current_id()
	if p.event_id == "cameras":
		if mission.reached("cameras"):
			_open_cameras()
		else:
			hud.toast(p.idle_message)
		return
	if p.event_id == cur and not p.used:
		if p.requires_item != "" and not player.inventory.has_item(p.requires_item):
			hud.toast(p.missing_message)
			AudioManager.play(&"locked")
			return
		if p.consume_item:
			player.inventory.remove(p.requires_item)
		p.used = true
		used_points.append(p.point_id)
		if p.ok_message != "":
			hud.toast(p.ok_message, 4.0)
		if p.read_text != "":
			_open_note(p.read_title, p.read_text)
		mission.event(cur)
	else:
		if p.used and p.read_text != "":
			_open_note(p.read_title, p.read_text)
		elif p.used and p.event_id != "":
			hud.toast("Burayı zaten kontrol ettin.")
		else:
			hud.toast(p.idle_message)


func _on_pickup(p: Pickup) -> void:
	collected.append(p.pickup_id)
	var def: Dictionary = Inventory.ITEMS.get(p.item_id, {})
	player.inventory.add(p.item_id, p.amount)
	if String(def.get("type", "")) == "note":
		_open_note(String(def.get("title", "Not")), String(def.get("text", "")))
	else:
		hud.toast("Aldın: %s" % String(def.get("name", p.item_id)))
	if ITEM_EVENTS.has(p.item_id):
		mission.event(String(ITEM_EVENTS[p.item_id]))


func _open_note(title: String, text: String) -> void:
	_freeze_for_ui()
	note_ui.open_panel(title, text)


func _read_inventory_note(item_id: String) -> void:
	var def: Dictionary = Inventory.ITEMS.get(item_id, {})
	inv_ui.visible = false
	note_ui.open_panel(String(def.get("title", "Not")), String(def.get("text", "")))


func _freeze_for_ui() -> void:
	player.frozen = true
	touch.enabled = false
	get_tree().paused = true


func _resume_from_ui() -> void:
	if inv_ui.visible or note_ui.visible or cam_view.visible:
		return
	player.frozen = false
	touch.enabled = true
	touch.queue_redraw()
	get_tree().paused = false


func open_inventory() -> void:
	if game_over or player.dead:
		return
	_freeze_for_ui()
	inv_ui.open_panel(player.inventory)


func open_pause() -> void:
	if game_over or player.dead or _pause_overlay != null:
		return
	_freeze_for_ui()
	_pause_overlay = OverlayScreen.new()
	add_child(_pause_overlay)
	_pause_overlay.setup("DURAKLATILDI", "", [
		{"text": "DEVAM ET", "call": _close_pause},
		{"text": "AYARLAR", "call": _open_settings},
		{"text": "KAYDET VE ANA MENÜ", "call": func() -> void:
			_save()
			GameManager.go_to_menu()},
	], Color(0.9, 0.9, 0.9))


func _close_pause() -> void:
	if _pause_overlay:
		_pause_overlay.queue_free()
		_pause_overlay = null
	_resume_from_ui()


func _open_settings() -> void:
	var s := SettingsMenu.new()
	add_child(s)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("inventory"):
		open_inventory()
	elif event.is_action_pressed("pause"):
		open_pause()


# --------------------------------------------------------------------------
# Kameralar
# --------------------------------------------------------------------------

func _open_cameras() -> void:
	_freeze_for_ui()
	get_tree().paused = false   # Monitör izlenirken dünya akmaya devam eder
	cam_view.open_panel(market.cams)


func _on_cam_viewed(i: int) -> void:
	if mission.current_id() != "cameras" or viewed_cams.has(i):
		return
	viewed_cams.append(i)
	if viewed_cams.size() >= 3:
		# Son kamerada yaratık görünür.
		var spots := [Vector3(14, 0, 8), Vector3(5.5, 0, 21.5), Vector3(20, 0, 15.5)]
		var faces := [PI, PI, PI * 0.5]
		creature.show_static(spots[i], faces[i])
		get_tree().create_timer(1.2).timeout.connect(func() -> void:
			AudioManager.play(&"scare", -2.0)
			hud.flash(Color(1, 0, 0, 0.35), 0.5))
		get_tree().create_timer(3.4).timeout.connect(func() -> void: creature.hide_static())
	mission.event("cameras")


func _on_cam_closed() -> void:
	_resume_from_ui()
	if mission.done("cameras") and not creature.active:
		_cameras_finale()


func _cameras_finale() -> void:
	creature.hide_static()
	jumpscare(0.8)
	hud.toast("Bir şey depoda hareket etti...", 4.0)
	(market.doors["door_a"] as Door).force_open(true)
	_apply_world_state()
	get_tree().create_timer(8.0).timeout.connect(func() -> void:
		if not creature.active:
			creature.activate(_far_waypoint())
			_save())


# --------------------------------------------------------------------------
# Olaylar
# --------------------------------------------------------------------------

func _on_trigger(id: String) -> void:
	match id:
		"security":
			mission.event("security")
		"descend":
			mission.event("descend")
			creature.allow_underground = true
		"escape":
			if mission.current_id() == "escape":
				mission.event("escape")
		"main_enter":
			if mission.current_id() == "security" and not slammed:
				slammed = true
				var da: Door = market.doors["door_a"]
				da.force_close(true, true)
				AudioManager.play(&"clang", 0.0, 0.6)
				jumpscare(0.5)
				hud.toast("Kapı arkandan çarparak kapandı!", 3.5)
		"depo_enter":
			if mission.current_id() == "hidden" and not hinted_depo:
				hinted_depo = true
				AudioManager.play(&"clang", -6.0, 0.5)
				hud.toast("Soldaki raf diğerlerinden farklı... Arkasından soğuk hava geliyor.", 5.0)


func _on_hidden_door(d: Door) -> void:
	if d.is_open and mission.current_id() == "hidden":
		mission.event("hidden")


func _on_step_started(index: int) -> void:
	_refresh_hud()
	# Zaten envanterde olan eşyalar adımı otomatik tamamlar.
	var cur := mission.current_id()
	for item in ITEM_EVENTS:
		if ITEM_EVENTS[item] == cur and player.inventory.has_item(item):
			mission.event.call_deferred(cur)
			return
	if _ready_done and not game_over:
		_save.call_deferred()


func _on_step_completed(step_id: String) -> void:
	match step_id:
		"register":
			player.inventory.add("ofis_anahtari")
			hud.toast("Aldın: Ofis Anahtarı")
		"power_check":
			clock_min = 24.0 * 60.0
			_blackout()
		"fuse_place":
			AudioManager.play(&"clang", -4.0, 1.4)
			_apply_world_state()
		"generator":
			_power_on()
		"reactor":
			_finale_start()
	_apply_world_state()


func _blackout() -> void:
	AudioManager.play(&"thump", 4.0, 0.5)
	market.set_power(false)
	market.set_emergency(true)
	shake(0.04, 1.0)
	hud.toast("Elektrikler kesildi!", 3.0)
	get_tree().create_timer(2.5).timeout.connect(func() -> void:
		AudioManager.play(&"door", -4.0, 0.5)
		hud.toast("Marketin içinde bir şeyler değişti...", 4.0))


func _power_on() -> void:
	market.set_power(true)
	market.set_emergency(false)
	market.burst_lights(2.0)
	AudioManager.play(&"clang", -2.0, 0.8)


func _finale_start() -> void:
	creature.rage = true
	creature.allow_underground = true
	creature.allow_outdoors = true
	creature.chase_speed = 4.7
	creature.active = true
	market.set_emergency(true)
	market.burst_lights(3.0)
	jumpscare(1.0)
	(market.doors["back"] as Door).locked = false
	hud.toast("Reaktör kapanıyor! Yaratık uyandı — dışarı çık!", 5.0)
	if not creature.is_visible_now():
		creature.activate(_far_waypoint())
	creature.alert(player.global_position)


func _on_ending() -> void:
	game_over = true
	SaveSystem.delete_save()
	player.frozen = true
	touch.enabled = false
	creature.deactivate()
	AudioManager.stop_ambient()
	var o := OverlayScreen.new()
	add_child(o)
	o.setup("SABAH OLDU", "Vardiya bitti. Güneş doğarken market sessizce kapandı.\nAma VOID gerçekten bitti mi?",
		[{"text": "ANA MENÜ", "call": GameManager.go_to_menu}], Color(0.9, 0.85, 0.6))
	get_tree().paused = true


func _on_caught() -> void:
	if game_over or player.dead:
		return
	game_over = true
	player.die()
	touch.enabled = false
	var to := creature.global_position + Vector3(0, 1.9, 0) - player.camera.global_position
	player.rotation.y = atan2(-to.x, -to.z)
	jumpscare(1.5)
	await get_tree().create_timer(1.3).timeout
	var o := OverlayScreen.new()
	add_child(o)
	var buttons: Array = []
	if SaveSystem.has_save():
		buttons.append({"text": "SON KAYITTAN DEVAM ET", "call": func() -> void: GameManager.start_single(true)})
	buttons.append({"text": "YENİDEN BAŞLA", "call": func() -> void: GameManager.start_single(false)})
	buttons.append({"text": "ANA MENÜ", "call": GameManager.go_to_menu})
	o.setup("YAKALANDIN", "Karanlıkta yalnız değildin.", buttons)
	get_tree().paused = true


# --------------------------------------------------------------------------
# Dünya durumu (görev adımından türetilir; kayıttan yüklemede de çalışır)
# --------------------------------------------------------------------------

func _apply_world_state() -> void:
	var blackout := mission.reached("fuse_find")
	var power_on := mission.done("generator")
	market.set_power((not blackout) or power_on)
	market.set_emergency(blackout and not power_on)
	if blackout:
		market.apply_changes()
		for id in ["personel", "toilet"]:
			var d: Door = market.doors[id]
			if not d.jammed:
				d.jammed = true
				d.force_close(false, false)
				d.jammed = true
	var da: Door = market.doors["door_a"]
	if slammed and not mission.done("cameras"):
		if not da.locked:
			da.force_close(true, false)
	elif mission.done("cameras"):
		da.locked = false
	var hid: Door = market.doors["hidden"]
	hid.locked = not mission.done("cameras")
	(market.doors["back"] as Door).locked = not mission.done("reactor")
	creature.allow_underground = mission.reached("descend")
	creature.allow_outdoors = mission.done("reactor")
	for p in market.pickups:
		var avail := p.available_from == "" or mission.reached(p.available_from)
		var gone := collected.has(p.pickup_id)
		p.set_active(avail and not gone)
		p.taken = gone
	for pid in used_points:
		if market.points.has(pid):
			(market.points[pid] as InteractPoint).used = true


func _refresh_hud() -> void:
	hud.set_objective(mission.text())
	hud.set_battery(player.battery)


func _far_waypoint() -> Vector3:
	var best := market.waypoints[0]
	var best_d := -1.0
	for w in market.waypoints:
		var underground := w.y < -0.5 or w.z > 25.5
		var outdoors := w.x < 0.5 or w.z < 0.5
		if (underground and not creature.allow_underground) or (outdoors and not creature.allow_outdoors):
			continue
		var d := w.distance_to(player.global_position)
		if d > best_d:
			best_d = d
			best = w
	return best


# --------------------------------------------------------------------------
# Kayıt
# --------------------------------------------------------------------------

func _save() -> void:
	if game_over or player == null or player.dead or not _ready_done:
		return
	var d := {
		"version": 1,
		"mission": mission.to_dict(),
		"player": player.to_dict(),
		"used_points": used_points,
		"collected": collected,
		"viewed_cams": viewed_cams,
		"slammed": slammed,
		"clock": clock_min,
		"play_time": play_time,
	}
	SaveSystem.write(d)


func _load_game() -> bool:
	var d := SaveSystem.read()
	if d.is_empty():
		return false
	mission.from_dict(d.get("mission", {}))
	player.from_dict(d.get("player", {}))
	used_points = d.get("used_points", [])
	collected = d.get("collected", [])
	viewed_cams = d.get("viewed_cams", [])
	slammed = bool(d.get("slammed", false))
	clock_min = float(d.get("clock", clock_min))
	play_time = float(d.get("play_time", 0.0))
	hud.toast("Kayıt yüklendi.", 2.5)
	return true
