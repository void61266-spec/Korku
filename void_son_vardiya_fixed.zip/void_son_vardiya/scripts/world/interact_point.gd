class_name InteractPoint
extends Interactable
## Görev olayı tetikleyen genel etkileşim noktası (kasa, terminal, jeneratör...).
## Mantığı GameDirector yürütür; bu sınıf sadece veriyi taşır.

signal activated(point: InteractPoint)

var event_id: String = ""
var used: bool = false
var ok_message: String = ""
var idle_message: String = "Şimdilik buna gerek yok."
var requires_item: String = ""
var missing_message: String = ""
var consume_item: bool = false
var read_title: String = ""
var read_text: String = ""
var hit_size: Vector3 = Vector3(0.6, 0.6, 0.6)
var point_id: String = ""


func _ready() -> void:
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = hit_size
	cs.shape = shape
	add_child(cs)


func _on_interact(_player: Node) -> void:
	activated.emit(self)
