class_name FlickerLight
extends OmniLight3D
## Titreyen / kesilebilen market lambası.

var base_energy: float = 1.0
var mode: int = 0          # 0 sabit, 1 hafif titreme, 2 bozuk (rastgele kesilir)
var powered: bool = true
var _burst_left: float = 0.0
var _t: float = 0.0
var _off_left: float = 0.0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.randomize()
	_t = _rng.randf() * 10.0
	add_to_group("store_lights")
	_refresh()


func set_powered(value: bool) -> void:
	powered = value
	_refresh()


func burst(duration: float) -> void:
	_burst_left = duration


func _refresh() -> void:
	light_energy = base_energy if powered else 0.0
	visible = powered
	set_process(powered and (mode > 0 or _burst_left > 0.0))


func _process(delta: float) -> void:
	_t += delta
	if _burst_left > 0.0:
		_burst_left -= delta
		light_energy = base_energy * (1.0 if _rng.randf() > 0.45 else 0.05)
		if _burst_left <= 0.0:
			_refresh()
		return
	if mode == 1:
		light_energy = base_energy * (0.9 + 0.1 * sin(_t * 43.0) * sin(_t * 7.0))
	elif mode == 2:
		if _off_left > 0.0:
			_off_left -= delta
			light_energy = base_energy * (0.05 if _rng.randf() > 0.3 else 0.8)
		else:
			light_energy = base_energy
			if _rng.randf() < delta * 0.35:
				_off_left = _rng.randf_range(0.15, 0.9)


func _process_toggle() -> void:
	set_process(powered and (mode > 0 or _burst_left > 0.0))
