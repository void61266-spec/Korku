class_name HUD
extends CanvasLayer
## Oyun içi arayüz: saat, görev, fener pili, etkileşim yazısı, mesajlar, korku efekti.

var _clock: Label
var _objective: Label
var _battery: ProgressBar
var _stamina: ProgressBar
var _prompt: Label
var _toast: Label
var _vignette: TextureRect
var _hide_overlay: ColorRect
var _flash: ColorRect
var _toast_tween: Tween
var _fear := 0.0


func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# Korku vinyeti (radyal gradyan)
	var grad := Gradient.new()
	grad.set_color(0, Color(0, 0, 0, 0))
	grad.set_color(1, Color(0, 0, 0, 1))
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 256
	gt.height = 256
	_vignette = TextureRect.new()
	_vignette.texture = gt
	_vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	_vignette.stretch_mode = TextureRect.STRETCH_SCALE
	_vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vignette.modulate.a = 0.35
	root.add_child(_vignette)

	_hide_overlay = ColorRect.new()
	_hide_overlay.color = Color(0, 0, 0, 0.82)
	_hide_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_hide_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hide_overlay.visible = false
	root.add_child(_hide_overlay)
	# Dolap aralığı: ortada ince yatay yarık
	var slit := ColorRect.new()
	slit.color = Color(0.02, 0.02, 0.03, 0.0)
	slit.set_anchors_preset(Control.PRESET_CENTER)
	slit.size = Vector2(600, 24)
	slit.position = Vector2(-300, -12)
	_hide_overlay.add_child(slit)

	var top := VBoxContainer.new()
	top.position = Vector2(24, 18)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)
	_clock = UIStyle.label("23:35", 34, Color(0.85, 0.2, 0.15))
	top.add_child(_clock)
	_objective = UIStyle.label("", 22)
	_objective.custom_minimum_size = Vector2(420, 0)
	_objective.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	top.add_child(_objective)
	var bl := UIStyle.label("FENER", 16, Color(0.8, 0.8, 0.7))
	top.add_child(bl)
	_battery = _make_bar(Color(0.95, 0.85, 0.3))
	top.add_child(_battery)
	var sl := UIStyle.label("DAYANIKLILIK", 14, Color(0.7, 0.8, 0.7))
	top.add_child(sl)
	_stamina = _make_bar(Color(0.4, 0.8, 0.5))
	top.add_child(_stamina)

	# Artı işareti
	var dot := ColorRect.new()
	dot.color = Color(1, 1, 1, 0.5)
	dot.set_anchors_preset(Control.PRESET_CENTER)
	dot.size = Vector2(6, 6)
	dot.position = Vector2(-3, -3)
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dot)

	_prompt = UIStyle.label("", 28, Color(1, 0.95, 0.8))
	_prompt.set_anchors_preset(Control.PRESET_CENTER)
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.size = Vector2(700, 40)
	_prompt.position = Vector2(-350, 60)
	root.add_child(_prompt)

	_toast = UIStyle.label("", 28, Color(1, 1, 1))
	_toast.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast.size = Vector2(800, 80)
	_toast.position = Vector2(-400, 120)
	_toast.modulate.a = 0.0
	root.add_child(_toast)

	_flash = ColorRect.new()
	_flash.color = Color(1, 0, 0, 0)
	_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_flash)


func _make_bar(col: Color) -> ProgressBar:
	var b := ProgressBar.new()
	b.custom_minimum_size = Vector2(220, 12)
	b.max_value = 100.0
	b.value = 100.0
	b.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = col
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.55)
	b.add_theme_stylebox_override("fill", fill)
	b.add_theme_stylebox_override("background", bg)
	return b


func set_clock(text: String) -> void:
	_clock.text = text


func set_objective(text: String) -> void:
	_objective.text = ("▸ " + text) if text != "" else ""


func set_battery(v: float) -> void:
	_battery.value = v
	var fill := _battery.get_theme_stylebox("fill") as StyleBoxFlat
	if fill:
		fill.bg_color = Color(0.9, 0.2, 0.15) if v < 20.0 else Color(0.95, 0.85, 0.3)


func set_stamina(v: float) -> void:
	_stamina.value = v


func set_prompt(text: String) -> void:
	_prompt.text = text


func set_hiding(on: bool) -> void:
	_hide_overlay.visible = on


func set_fear(f: float) -> void:
	_fear = clampf(f, 0.0, 1.0)
	_vignette.modulate.a = 0.3 + 0.6 * _fear
	_vignette.modulate.r = 1.0
	_vignette.modulate.g = 1.0 - 0.6 * _fear
	_vignette.modulate.b = 1.0 - 0.6 * _fear


func toast(text: String, duration: float = 3.2) -> void:
	_toast.text = text
	if _toast_tween and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(duration)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.6)


func flash(color: Color, duration: float = 0.5) -> void:
	_flash.color = Color(color.r, color.g, color.b, color.a)
	var tw := create_tween()
	tw.tween_property(_flash, "color:a", 0.0, duration)
