class_name UIStyle
extends RefCounted
## Ortak koyu tema yardımcıları.

const BG := Color(0.04, 0.04, 0.05, 0.92)
const ACCENT := Color(0.75, 0.12, 0.1)
const TEXT := Color(0.9, 0.9, 0.88)


static func _flat(bg: Color, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(4)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


static func style_button(b: Button, font_size: int = 26, accent: bool = false) -> void:
	var base := Color(0.1, 0.1, 0.11, 0.85)
	var border := ACCENT if accent else Color(0.45, 0.45, 0.45, 0.6)
	b.add_theme_stylebox_override("normal", _flat(base, border, 2))
	b.add_theme_stylebox_override("hover", _flat(Color(0.2, 0.06, 0.06, 0.9), ACCENT, 2))
	b.add_theme_stylebox_override("pressed", _flat(Color(0.4, 0.08, 0.07, 0.95), ACCENT, 2))
	b.add_theme_stylebox_override("disabled", _flat(Color(0.08, 0.08, 0.08, 0.6), Color(0.3, 0.3, 0.3, 0.4), 1))
	b.add_theme_stylebox_override("focus", _flat(Color(0, 0, 0, 0), ACCENT, 2))
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_disabled_color", Color(0.5, 0.5, 0.5))
	b.add_theme_font_size_override("font_size", font_size)
	b.custom_minimum_size = Vector2(0, 62)


static func panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _flat(BG, Color(0.5, 0.1, 0.1, 0.8), 2))
	return p


static func label(text: String, size: int = 24, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 4)
	return l
