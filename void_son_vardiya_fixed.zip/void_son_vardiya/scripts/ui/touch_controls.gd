class_name TouchControls
extends Control
## Çok parmaklı dokunmatik kontrol: sol joystick, sağ bakış alanı, aksiyon butonları.
## Butonlar elle çizilir ve ham dokunuş olaylarıyla yönetilir (çoklu dokunuş güvenli).

signal look_delta(delta: Vector2)
signal interact_pressed
signal flashlight_pressed
signal inventory_pressed
signal crouch_pressed
signal pause_pressed

var move_vector := Vector2.ZERO
var sprint_held := false
var enabled := true

var _stick_finger := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _look_finger := -1
var _btn_fingers: Dictionary = {}   # finger -> button name
var _buttons: Dictionary = {}       # name -> {pos, radius, label}
var _stick_radius := 90.0
var _look_last := Vector2.ZERO
var _crouch_on := false
var _flash_on := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	Settings.changed.connect(_layout)
	_layout()


func set_toggle_state(crouch: bool, flash: bool) -> void:
	if crouch != _crouch_on or flash != _flash_on:
		_crouch_on = crouch
		_flash_on = flash
		queue_redraw()


func _layout() -> void:
	var s := Settings.control_scale
	var sz := size
	var r := 52.0 * s
	var right := Settings.swap_hands
	var base_x := sz.x - 120.0 * s if not right else 120.0 * s
	var base_y := sz.y - 110.0 * s
	var dir := -1.0 if not right else 1.0
	_stick_radius = 88.0 * s
	_buttons = {
		"interact": {"pos": Vector2(base_x, base_y), "radius": r * 1.25, "label": "E"},
		"sprint": {"pos": Vector2(base_x + dir * 125.0 * s, base_y + 10.0 * s), "radius": r, "label": "KOŞ"},
		"crouch": {"pos": Vector2(base_x, base_y - 125.0 * s), "radius": r * 0.9, "label": "EĞİL"},
		"flash": {"pos": Vector2(base_x + dir * 125.0 * s, base_y - 105.0 * s), "radius": r * 0.9, "label": "FENER"},
		"inventory": {"pos": Vector2(sz.x * 0.5 + 0.0, sz.y - 50.0 * s), "radius": r * 0.7, "label": "ENV"},
		"pause": {"pos": Vector2(sz.x - 46.0 * s if not right else 46.0 * s, 46.0 * s), "radius": r * 0.6, "label": "II"},
	}
	queue_redraw()


func _stick_zone() -> Rect2:
	# Joystick için ekranın sahip olduğu yarı (varsayılan sol).
	if Settings.swap_hands:
		return Rect2(size.x * 0.5, size.y * 0.25, size.x * 0.5, size.y * 0.75)
	return Rect2(0.0, size.y * 0.25, size.x * 0.5, size.y * 0.75)


func _button_at(p: Vector2) -> String:
	for n in _buttons:
		var b: Dictionary = _buttons[n]
		if p.distance_to(b.pos) <= float(b.radius) * 1.15:
			return n
	return ""


func _input(event: InputEvent) -> void:
	if not enabled or not is_visible_in_tree():
		_release_all()
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_on_down(t.index, t.position)
		else:
			_on_up(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_on_drag(d.index, d.position, d.relative)


func _on_down(finger: int, p: Vector2) -> void:
	var b := _button_at(p)
	if b != "":
		_btn_fingers[finger] = b
		match b:
			"interact": interact_pressed.emit()
			"sprint": sprint_held = true
			"crouch": crouch_pressed.emit()
			"flash": flashlight_pressed.emit()
			"inventory": inventory_pressed.emit()
			"pause": pause_pressed.emit()
		Settings.vibrate(10)
		queue_redraw()
		return
	if _stick_finger == -1 and _stick_zone().has_point(p):
		_stick_finger = finger
		_stick_origin = p
		_stick_pos = p
		move_vector = Vector2.ZERO
	elif _look_finger == -1 and not _stick_zone().has_point(p):
		_look_finger = finger
		_look_last = p
	elif _look_finger == -1:
		_look_finger = finger
		_look_last = p
	queue_redraw()


func _on_drag(finger: int, p: Vector2, rel: Vector2) -> void:
	if finger == _stick_finger:
		var off := p - _stick_origin
		if off.length() > _stick_radius:
			# Kaymış joystick: merkezi parmağı izleyecek şekilde taşı.
			_stick_origin = p - off.normalized() * _stick_radius
			off = p - _stick_origin
		_stick_pos = p
		var v := off / _stick_radius
		move_vector = Vector2(v.x, v.y)
		queue_redraw()
	elif finger == _look_finger:
		look_delta.emit(rel)


func _on_up(finger: int) -> void:
	if finger == _stick_finger:
		_stick_finger = -1
		move_vector = Vector2.ZERO
	elif finger == _look_finger:
		_look_finger = -1
	elif _btn_fingers.has(finger):
		if _btn_fingers[finger] == "sprint":
			sprint_held = false
		_btn_fingers.erase(finger)
	queue_redraw()


func _release_all() -> void:
	if _stick_finger != -1 or _look_finger != -1 or not _btn_fingers.is_empty():
		_stick_finger = -1
		_look_finger = -1
		_btn_fingers.clear()
		move_vector = Vector2.ZERO
		sprint_held = false
		queue_redraw()


func _draw() -> void:
	if not enabled:
		return
	var font := ThemeDB.fallback_font
	# Joystick
	var base := _stick_origin if _stick_finger != -1 else _default_stick_pos()
	draw_circle(base, _stick_radius, Color(1, 1, 1, 0.07))
	draw_arc(base, _stick_radius, 0.0, TAU, 40, Color(1, 1, 1, 0.25), 2.0)
	var knob := base
	if _stick_finger != -1:
		knob = base + (_stick_pos - base).limit_length(_stick_radius)
	draw_circle(knob, _stick_radius * 0.42, Color(1, 1, 1, 0.22))
	# Butonlar
	for n in _buttons:
		var b: Dictionary = _buttons[n]
		var pressed: bool = _btn_fingers.values().has(n)
		var active: bool = (n == "crouch" and _crouch_on) or (n == "flash" and _flash_on)
		var alpha := 0.38 if (pressed or active) else 0.16
		var col := Color(0.85, 0.2, 0.15, alpha + 0.1) if n == "interact" else Color(1, 1, 1, alpha)
		draw_circle(b.pos, b.radius, col)
		draw_arc(b.pos, b.radius, 0.0, TAU, 32, Color(1, 1, 1, 0.35), 2.0)
		var fs := int(float(b.radius) * 0.5)
		var ts := font.get_string_size(String(b.label), HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
		draw_string(font, b.pos + Vector2(-ts.x * 0.5, ts.y * 0.3), String(b.label),
			HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.85))


func _default_stick_pos() -> Vector2:
	var s := Settings.control_scale
	if Settings.swap_hands:
		return Vector2(size.x - 150.0 * s, size.y - 130.0 * s)
	return Vector2(150.0 * s, size.y - 130.0 * s)
